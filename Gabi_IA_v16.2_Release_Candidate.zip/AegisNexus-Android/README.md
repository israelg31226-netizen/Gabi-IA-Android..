# Gabi I.A. — v16.2 Neural Core

Assistente Android em Kotlin, com interface neural animada, entrada por texto/voz, síntese de fala, memória local, planejamento de tarefas e cliente multimodelo configurável.

## Estado do release

Este pacote é uma **versão candidata para validação**, não um release de produção certificado. O código-fonte e a configuração foram revisados estaticamente e o ZIP foi validado; a compilação Android e os testes em dispositivo precisam ser concluídos em um ambiente com acesso ao Gradle e Android SDK.

## Recursos

- UI Android nativa com visualização neural animada e central de configurações.
- Provedores configuráveis: Google Gemini, OpenAI API e xAI Grok API.
- Modelo e chave configuráveis por provedor.
- Chaves API criptografadas em repouso usando AES/GCM e Android Keystore, com migração de chaves locais antigas em texto simples quando forem lidas.
- Memória local, objetivos, planos, tarefas, bloqueios e histórico de resultados.
- Recursos de voz, lembretes, rotinas e iniciativa opcional usando APIs do Android/WorkManager.
- Controle de aplicativos opcional por serviço de Acessibilidade do Android, que requer ativação explícita no sistema.
- Workflow GitHub Actions para compilar APK debug e publicar o artefato da execução.

## Compilar

Requisitos: JDK 17, Android SDK 35, acesso à internet para baixar dependências Gradle/Maven.

```bash
chmod +x gradlew
./gradlew assembleDebug
```

APK debug: `app/build/outputs/apk/debug/app-debug.apk`.

No GitHub: envie o conteúdo do repositório, abra **Actions**, execute **Build Gabi IA v16.2 APK** e baixe o artefato `Gabi-IA-v16.2-debug-apk`.

## Configuração de IA

Abra o ícone de engrenagem, escolha o provedor, informe um ID de modelo disponível para sua conta e cole a chave correspondente. O acesso à API e a cobrança são independentes das assinaturas de consumo dos provedores. Não inclua chaves no código-fonte, em issues, capturas de tela ou commits.

## Limites importantes

- A Gabi não é um modelo treinado do zero. Ela usa modelos remotos escolhidos pelo usuário e lógica local para tarefas auxiliares.
- “Aprender” significa guardar memórias/feedback local e adaptar regras limitadas; não significa retreinar os pesos do modelo.
- As rotinas Android são sujeitas às políticas de bateria e execução em segundo plano do sistema.
- A palavra de ativação é experimental e não garante escuta contínua em todos os aparelhos.
- O serviço de Acessibilidade é poderoso e deve ficar desligado até que o usuário o habilite conscientemente.
- A criptografia local protege as chaves em repouso, mas não substitui um backend seguro para distribuição pública. A chave ainda precisa ser usada pelo aplicativo para fazer chamadas diretas à API.
- Não há garantia de execução autônoma ilimitada, consciência, pesquisa web independente ou integração automática com a sessão do ChatGPT. Cada ação depende de código, ferramentas e permissões realmente disponíveis.

## Checklist de release

Consulte [`docs/RELEASE-CHECKLIST.md`](docs/RELEASE-CHECKLIST.md) e [`docs/ARCHITECTURE-AND-SAFETY.md`](docs/ARCHITECTURE-AND-SAFETY.md) antes de distribuir.
