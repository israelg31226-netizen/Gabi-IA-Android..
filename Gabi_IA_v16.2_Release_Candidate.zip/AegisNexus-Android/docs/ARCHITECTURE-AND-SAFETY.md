# Arquitetura e segurança — Gabi I.A. v16.2

## Componentes

- `MainActivity`: interface, fluxo de conversa, permissões Android e acesso às ações do assistente.
- `AegisAiClient`: chamadas HTTP para Gemini, OpenAI e xAI; seleção de provedor/modelo.
- `AegisSecretStore`: criptografia AES/GCM das chaves API com chave mantida pelo Android Keystore.
- `AegisMemory`: memórias que o usuário opta por salvar localmente.
- `AegisAutonomy`: objetivos, planos, tarefas, bloqueios, resultados e priorização local.
- `GabiBrain`, `GabiEvolution`, `GabiSelfMod`: reflexão, registro de lições e propostas/regras de comportamento.
- `WorkManager` workers: rotinas e notificações agendadas, sujeitas ao agendamento do Android.
- `GabiAccessibilityService`: ações limitadas sobre a interface do aparelho, somente se ativado pelo usuário nas configurações do sistema.

## Segurança por padrão

1. Não executar ações externas sensíveis sem confirmação explícita.
2. Não afirmar que uma tarefa externa foi concluída sem evidência verificável.
3. Manter a iniciativa e a escuta por palavra-chave opcionais.
4. Tratar texto vindo de modelos como conteúdo não confiável, nunca como autorização para ignorar permissões.
5. Manter as chaves fora do repositório e cifradas no armazenamento local.
6. Para distribuição pública, preferir um backend autenticado com limites de uso, rotação de credenciais e monitoramento, em vez de compartilhar uma chave de API dentro do APK.

## Limites

A autonomia atual é uma orquestração limitada pelo código implementado. Não existe acesso geral ao sistema operacional, nem aprendizado dos pesos do modelo. A visualização neural é um elemento de interface, não um sensor da atividade interna do modelo. As APIs remotas dependem de internet, validade da chave, modelo disponível e cotas da conta.
