# Checklist de validação antes de distribuir

## Compilação e instalação
- [ ] Executar `./gradlew clean assembleDebug` em ambiente com JDK 17 e Android SDK 35.
- [ ] Confirmar que o workflow `Build Gabi IA v16.2 APK` terminou com sucesso.
- [ ] Instalar o APK em pelo menos um dispositivo Android API 26+ e verificar inicialização/rotação/rolagem.
- [ ] Confirmar que o ícone de engrenagem abre a central de controle e salva provedor, modelo e chave.

## IA e privacidade
- [ ] Testar cada provedor com uma chave válida e modelo acessível.
- [ ] Testar chave inválida, ausência de rede, HTTP 429, modelo inválido e resposta vazia.
- [ ] Verificar migração de uma chave salva por versão antiga e confirmar que o valor salvo passa a usar `enc:v1:`.
- [ ] Confirmar que apagar chave remove o valor local.
- [ ] Não enviar chaves reais em logs, capturas de tela ou repositório.

## Autonomia e permissões
- [ ] Testar criação/listagem/conclusão de tarefas, planos, bloqueios e registro de resultados.
- [ ] Verificar que lembretes, rotinas, notificações e palavra de ativação podem ser desligados.
- [ ] Manter Acessibilidade desativada por padrão e confirmar que ações de interface pedem confirmação.
- [ ] Confirmar que erros e ações não executadas são descritos como tal.

## Publicação
- [ ] Definir política de privacidade e canal de suporte.
- [ ] Considerar backend para proteger credenciais e limitar abuso de API.
- [ ] Gerar assinatura de release própria; o APK de debug do CI não é um artefato de produção.
