# Gabi I.A. v16.0 — autonomia e central multimodelo

## Mudanças desta atualização
- Central de configurações acessível por botão de engrenagem na tela principal.
- Seleção do provedor de IA: Google Gemini, OpenAI API (modelos GPT) ou xAI Grok.
- Modelo e chave de API configuráveis por provedor, guardados localmente nas preferências do aplicativo.
- Modelo padrão Gemini `gemini-3-flash-preview`; confirme a disponibilidade na conta Google AI Studio. O ID do modelo pode ser alterado nas configurações.
- Cliente de API adaptado para o formato Gemini `generateContent` e para o formato compatível com OpenAI Chat Completions usado pelas APIs OpenAI e xAI.
- Prompt de sistema reforça o ciclo perceber, raciocinar, planejar, agir com permissões, verificar e aprender, sem alegar ações que não ocorreram.
- Número da versão atualizado para 16.0 (versionCode 16).

## Configuração
1. Abra a Gabi I.A. e toque na engrenagem no canto superior da tela ou em “Configurações”.
2. Escolha Gemini, OpenAI / ChatGPT ou Grok.
3. Confira o ID do modelo e cole a chave de API do provedor escolhido.
4. Toque em “Salvar configuração”. A chave é guardada localmente neste aparelho.

## Importante sobre a integração com ChatGPT
A opção OpenAI conecta à **API da OpenAI**, não à sessão, memória ou assinatura do aplicativo ChatGPT. É necessária uma chave de API OpenAI, e a cobrança da API é separada da assinatura ChatGPT. Para usar modelos OpenAI, escolha o provedor OpenAI e configure a chave e o modelo desejado.

## Segurança e autonomia
A Gabi pode raciocinar e planejar usando o provedor configurado e usar as ferramentas implementadas no aplicativo. A seleção de um modelo não dá acesso automático a internet arbitrária, arquivos, outros apps ou serviços. Ações externas devem ter integração real e confirmação adequada. Para distribuir o app, recomenda-se mover chaves de API para um backend próprio, pois chaves guardadas no aparelho podem ser extraídas de um dispositivo comprometido.

## Verificação desta entrega
- O ZIP original foi extraído e os arquivos-fonte foram atualizados.
- A compilação Android foi tentada com `./gradlew assembleDebug --offline`, mas não iniciou porque o Gradle 8.9 não estava em cache e o ambiente não conseguiu acessar `services.gradle.org` (UnknownHostException).
- Portanto, o APK **não foi compilado nem testado em dispositivo** nesta sessão. A compilação precisa ser executada num ambiente com internet ou Gradle 8.9 já instalado, além do Android SDK e dependências disponíveis.
