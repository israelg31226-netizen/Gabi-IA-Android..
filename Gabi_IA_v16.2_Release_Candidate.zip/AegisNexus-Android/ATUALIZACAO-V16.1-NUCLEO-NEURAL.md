# Gabi.Ia v16.1 — Núcleo Neural

## Objetivo desta revisão
Elevar a qualidade visual da tela inicial e tornar a experiência mais próxima de um painel profissional de assistente cognitivo, mantendo a estrutura Android existente.

## Alterações
- Substituída a esfera decorativa por uma visualização vetorial de rede neural com dois hemisférios, conexões e pulsos animados.
- Adicionada legenda de núcleo cognitivo e status em português. A animação é visual e não representa uma medição real de inteligência ou carga do modelo.
- Barra superior refinada com marca GABI / I.A. e botão de engrenagem dedicado.
- Campos de mensagem e ações receberam contraste, cantos arredondados, hierarquia visual e espaçamento consistentes.
- Tela principal agora rola verticalmente para caber em celulares menores.
- Atualizado versionCode para 17 e versionName para 16.1.
- Mantido o seletor de provedores Gemini, OpenAI e Grok e o modelo padrão Gemini `gemini-3-flash-preview`. A disponibilidade desse modelo depende do acesso concedido pela API do Google.

## Segurança e autonomia
- Ações externas devem continuar exigindo confirmação do usuário.
- A visualização neural é apenas interface; não prova que o aplicativo está pensando em segundo plano.
- As chamadas online dependem de chaves de API fornecidas pelo usuário e podem gerar cobranças próprias.

## Verificação desta entrega
- Integridade do ZIP: verificada após empacotamento.
- Manifesto Android e arquivos XML: verificados por parser XML.
- Compilação APK: não concluída neste ambiente porque `services.gradle.org` não pôde ser resolvido (erro de rede/DNS). A compilação precisa ser executada em ambiente com Gradle e Android SDK disponíveis.
- Testes em dispositivo: pendentes.
