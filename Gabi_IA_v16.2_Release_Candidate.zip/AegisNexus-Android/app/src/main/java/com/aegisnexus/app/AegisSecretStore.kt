package com.aegisnexus.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Small Android-Keystore-backed store for provider API keys.
 * Values are encrypted at rest with AES/GCM; keys never leave Android Keystore.
 */
internal class AegisSecretStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("gabi_ai_settings", Context.MODE_PRIVATE)

    @Synchronized
    fun get(name: String): String? {
        val stored = prefs.getString(name, null)?.takeIf { it.isNotBlank() } ?: return null
        if (!stored.startsWith(PREFIX)) {
            // One-time migration of keys saved by older versions in plaintext preferences.
            return try {
                val encrypted = encrypt(stored)
                prefs.edit().putString(name, encrypted).apply()
                stored
            } catch (_: Exception) {
                // Do not keep a legacy plaintext key if secure migration fails.
                prefs.edit().remove(name).apply()
                null
            }
        }
        return runCatching { decrypt(stored.removePrefix(PREFIX)) }.getOrElse {
            // Fail closed: don't return corrupted data or silently fall back to plaintext.
            prefs.edit().remove(name).apply()
            null
        }
    }

    @Synchronized
    fun put(name: String, value: String) {
        if (value.isBlank()) {
            remove(name)
            return
        }
        prefs.edit().putString(name, PREFIX + encrypt(value)).apply()
    }

    @Synchronized
    fun remove(name: String) { prefs.edit().remove(name).apply() }

    private fun encrypt(plainText: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        val iv = Base64.encodeToString(cipher.iv, Base64.NO_WRAP)
        val data = Base64.encodeToString(encrypted, Base64.NO_WRAP)
        return "$iv:$data"
    }

    private fun decrypt(payload: String): String {
        val parts = payload.split(':', limit = 2)
        require(parts.size == 2) { "Invalid encrypted secret" }
        val iv = Base64.decode(parts[0], Base64.NO_WRAP)
        val data = Base64.decode(parts[1], Base64.NO_WRAP)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(data), Charsets.UTF_8)
    }

    private fun secretKey(): SecretKey {
        val store = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private companion object {
        const val PREFIX = "enc:v1:"
        const val KEY_ALIAS = "gabi.provider.api.keys.v1"
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
    }
}
