package com.aegisnexus.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/** Cliente multimodelo: Gemini, OpenAI e Grok. As chaves são fornecidas pelo usuário. */
class AegisAiClient(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("gabi_ai_settings", Context.MODE_PRIVATE)
    private val secrets = AegisSecretStore(appContext)

    enum class Provider(val displayName: String, val preferenceKey: String, val defaultModel: String) {
        GEMINI("Gemini", "gemini", "gemini-3-flash-preview"),
        OPENAI("OpenAI / ChatGPT", "openai", "gpt-4.1-mini"),
        GROK("Grok", "grok", "grok-3-mini")
    }

    fun getProvider(): Provider = runCatching {
        Provider.valueOf(prefs.getString("provider", Provider.GEMINI.name) ?: Provider.GEMINI.name)
    }.getOrDefault(Provider.GEMINI)
    fun saveProvider(provider: Provider) { prefs.edit().putString("provider", provider.name).apply() }
    fun getModel(provider: Provider = getProvider()): String = prefs.getString("model_${provider.preferenceKey}", null)?.takeIf { it.isNotBlank() } ?: provider.defaultModel
    fun saveModel(provider: Provider, model: String) { prefs.edit().putString("model_${provider.preferenceKey}", model.trim()).apply() }
    fun hasApiKey(): Boolean = !getApiKey().isNullOrBlank()
    fun saveApiKey(key: String) { saveApiKey(getProvider(), key) }
    fun saveApiKey(provider: Provider, key: String) { secrets.put("key_${provider.preferenceKey}", key.trim()) }
    fun clearApiKey() { clearApiKey(getProvider()) }
    fun clearApiKey(provider: Provider) { secrets.remove("key_${provider.preferenceKey}") }
    fun getApiKey(): String? = getApiKey(getProvider())
    fun getApiKey(provider: Provider): String? = secrets.get("key_${provider.preferenceKey}")

    fun ask(userText: String, memories: List<String>, history: List<Pair<String, String>> = emptyList()): String {
        val provider = getProvider()
        val key = getApiKey(provider)?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("Configure a chave de ${provider.displayName} no menu de engrenagem para ativar a inteligência online.")
        val model = getModel(provider)
        val connection = (URL(endpoint(provider, model, key)).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            if (provider != Provider.GEMINI) setRequestProperty("Authorization", "Bearer $key")
        }
        try {
            val memoryText = if (memories.isEmpty()) "Nenhuma memória pessoal foi salva." else memories.joinToString("\n") { "- $it" }
            val selfModContext = try { GabiSelfMod(appContext).contextForRuntime() } catch (_: Exception) { "" }
            val systemPrompt = """Você é Gabi I.A., uma assistente pessoal avançada para Android, inspirada no estilo de J.A.R.V.I.S.
Personalidade: calma, precisa, elegante, levemente formal e competente. Fale em português brasileiro claro. Trate o usuário como "Senhor" ocasionalmente, sem exagerar.
CICLO DE AUTONOMIA: perceba objetivos e pendências; raciocine sobre alternativas; planeje etapas e critérios de sucesso; use apenas ferramentas realmente disponíveis; verifique evidências antes de declarar conclusão; registre lições úteis sem inventar experiências.
Autonomia responsável: proponha próximos passos proativamente, mas não afirme que está executando tarefas em segundo plano se não houver ferramenta para isso. Não altere dispositivo, aplicativos, contas ou serviços externos sem autorização explícita. Diferencie fatos, hipóteses e incertezas. Nunca invente pesquisa na internet, acesso a outro assistente ou resultados de ferramentas.
Integração: você está usando o provedor ${provider.displayName} e o modelo $model. Não diga que consultou outros modelos ou o ChatGPT a menos que uma integração real tenha sido chamada.
Memórias autorizadas neste aparelho:
$memoryText
${if (selfModContext.isNotBlank()) "REGRAS PERSONALIZADAS DA GABI:\n$selfModContext" else ""}""".trimIndent()

            val body = if (provider == Provider.GEMINI) {
                val transcript = StringBuilder(systemPrompt)
                history.takeLast(10).forEach { (role, content) ->
                    if (role == "user") transcript.append("\nUsuário: ").append(content)
                    else if (role == "assistant") transcript.append("\nGabi: ").append(content)
                }
                transcript.append("\nPedido atual do usuário: ").append(userText)
                JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", transcript.toString())))))
                    .put("generationConfig", JSONObject().put("temperature", 0.65).put("maxOutputTokens", 1200))
            } else {
                val messages = JSONArray().put(JSONObject().put("role", "system").put("content", systemPrompt))
                history.takeLast(10).forEach { (role, content) ->
                    if (role == "user" || role == "assistant") messages.put(JSONObject().put("role", role).put("content", content))
                }
                messages.put(JSONObject().put("role", "user").put("content", userText))
                JSONObject().put("model", model).put("messages", messages).put("temperature", 0.65).put("max_tokens", 1200)
            }
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
            if (code !in 200..299) {
                val detail = try { JSONObject(response).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                throw IllegalStateException(when (code) {
                    400 -> "A API ${provider.displayName} rejeitou o pedido. Confira o modelo configurado."
                    401, 403 -> "A chave de ${provider.displayName} foi recusada ou não tem permissão. Confira a configuração."
                    404 -> "O modelo '$model' não foi encontrado para ${provider.displayName}. Confira o nome do modelo no menu de configurações."
                    429 -> "O limite de uso da API ${provider.displayName} foi atingido. Confira as cotas e tente novamente."
                    else -> "A API ${provider.displayName} retornou HTTP $code${detail?.takeIf { it.isNotBlank() }?.let { ": ${it.take(240)}" } ?: "."}"
                })
            }
            val json = JSONObject(response)
            val answer = if (provider == Provider.GEMINI) {
                val parts = json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                parts?.let { arr -> (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.optString("text")?.takeIf(String::isNotBlank) }.joinToString("\n").trim() }
            } else {
                val content = json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.opt("content")
                when (content) {
                    is String -> content.trim()
                    is JSONArray -> (0 until content.length()).mapNotNull { i -> content.optJSONObject(i)?.optString("text") }.joinToString("\n").trim()
                    else -> null
                }
            }
            return answer?.takeIf { it.isNotBlank() } ?: "Recebi uma resposta vazia de ${provider.displayName}. Tente novamente."
        } finally { connection.disconnect() }
    }

    private fun endpoint(provider: Provider, model: String, key: String): String = when (provider) {
        Provider.GEMINI -> "https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent?key=$key"
        Provider.OPENAI -> "https://api.openai.com/v1/chat/completions"
        Provider.GROK -> "https://api.x.ai/v1/chat/completions"
    }
}
