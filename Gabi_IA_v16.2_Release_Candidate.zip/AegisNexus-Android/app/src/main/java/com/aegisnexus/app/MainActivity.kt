package com.aegisnexus.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Path
import android.graphics.LinearGradient
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.ArrayAdapter
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.sin

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private lateinit var status: TextView
    private lateinit var talkButton: Button
    private var readyToSpeak = false
    private lateinit var replyEngine: AegisReplyEngine
    private lateinit var aiClient: AegisAiClient
    private lateinit var autonomy: AegisAutonomy
    private lateinit var wakeButton: Button
    private lateinit var initiativeButton: Button
    private lateinit var initiativeManager: GabiInitiativeManager
    private lateinit var appControlButton: Button
    private lateinit var reminderButton: Button
    private lateinit var reminderManager: GabiReminderManager
    private lateinit var routineButton: Button
    private lateinit var routineManager: GabiRoutineManager
    private val networkExecutor = Executors.newSingleThreadExecutor()
    private val conversationHistory = mutableListOf<Pair<String, String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(3, 9, 24)
        window.navigationBarColor = android.graphics.Color.rgb(3, 9, 24)
        tts = TextToSpeech(this, this)
        replyEngine = AegisReplyEngine(applicationContext)
        aiClient = AegisAiClient(applicationContext)
        autonomy = AegisAutonomy(applicationContext)
        initiativeManager = GabiInitiativeManager(applicationContext)
        reminderManager = GabiReminderManager(applicationContext)
        routineManager = GabiRoutineManager(applicationContext)
        routineManager.ensureScheduled()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(22, 22, 22, 26)
            setBackgroundColor(android.graphics.Color.rgb(3, 9, 24))
        }
        val title = TextView(this).apply {
            text = "GABI  /  I.A."
            textSize = 25f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            letterSpacing = 0.18f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(99, 226, 255))
        }
        val subtitle = TextView(this).apply {
            text = "NÚCLEO COGNITIVO AUTÔNOMO"
            textSize = 11f
            letterSpacing = 0.12f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(134, 164, 195))
        }
        val brainLabel = TextView(this).apply {
            text = "NÚCLEO NEURAL  /  ESTADO VISUAL DO SISTEMA"
            textSize = 10f
            letterSpacing = 0.11f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(89, 177, 211))
            setPadding(0, 22, 0, 2)
        }
        val brain = BrainView(this)
        status = TextView(this).apply {
            text = "NÚCLEO PRONTO  •  AGUARDANDO COMANDO"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            setPadding(14, 15, 14, 15)
            background = roundedBackground(android.graphics.Color.rgb(10, 26, 45), 18, android.graphics.Color.rgb(28, 91, 122))
        }
        val messageInput = EditText(this).apply {
            hint = "Digite uma mensagem para a Gabi…"
            setTextColor(android.graphics.Color.WHITE)
            setHintTextColor(android.graphics.Color.rgb(134, 164, 195))
            textSize = 16f
            setSingleLine(false)
            minLines = 1
            maxLines = 3
            setPadding(18, 12, 18, 12)
            background = roundedBackground(android.graphics.Color.rgb(12, 28, 47), 16, android.graphics.Color.rgb(29, 66, 94))
        }
        val sendButton = Button(this).apply {
            text = "ENVIAR MENSAGEM"
            isAllCaps = false
            setOnClickListener {
                val message = messageInput.text.toString().trim()
                if (message.isNotBlank()) {
                    messageInput.text.clear()
                    handleUserMessage(message)
                } else {
                    status.text = "Digite uma mensagem primeiro."
                }
            }
        }
        talkButton = Button(this).apply {
            text = "FALAR COM A GABI"
            isAllCaps = false
            textSize = 16f
            setOnClickListener { startListening() }
        }
        wakeButton = Button(this).apply {
            text = "ATIVAR ESCUTA: HEY GABI"
            isAllCaps = false
            textSize = 14f
            setOnClickListener { toggleWakeListening() }
        }
        initiativeButton = Button(this).apply {
            text = if (initiativeManager.isEnabled()) "DESATIVAR CÉREBRO AUTÔNOMO" else "ATIVAR CÉREBRO AUTÔNOMO"
            isAllCaps = false
            textSize = 14f
            setOnClickListener {
                if (initiativeManager.isEnabled()) {
                    initiativeManager.disable()
                    text = "ATIVAR CÉREBRO AUTÔNOMO"
                    status.text = "Cérebro autônomo desativado. A Gabi só pensará quando o Senhor pedir."
                } else if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 45)
                } else {
                    activateInitiativeMode()
                }
            }
        }
        val reflectNowButton = Button(this).apply {
            text = "PEDIR UMA REFLEXÃO AGORA"
            isAllCaps = false
            textSize = 14f
            setOnClickListener {
                if (!aiClient.hasApiKey()) {
                    status.text = "Configure uma chave de API no menu de engrenagem para a Gabi refletir com IA online."
                } else {
                    initiativeManager.reflectNow()
                    status.text = "Solicitei uma reflexão imediata (online ou offline). Se houver algo relevante, a Gabi registrará o pensamento e poderá notificar."
                }
            }
        }
        val prioritizeButton = Button(this).apply {
            text = "PRIORIZAR TAREFAS E PRÓXIMO PASSO"
            isAllCaps = false
            textSize = 14f
            setOnClickListener {
                val reply = autonomy.prioritizeTasks()
                status.text = reply
                speak(reply)
            }
        }
        appControlButton = Button(this).apply {
            text = if (GabiAccessibilityService.isEnabled(this@MainActivity)) "CONTROLE DE APPS: ATIVO" else "CONTROLE DE APPS: OPCIONAL"
            isAllCaps = false
            textSize = 14f
            setOnClickListener { showAppControlOptions() }
        }
        reminderButton = Button(this).apply {
            text = if (reminderManager.isEnabled()) "LEMBRETES: ATIVOS" else "ATIVAR LEMBRETES E NOTIFICAÇÕES"
            isAllCaps = false
            textSize = 14f
            setOnClickListener {
                if (reminderManager.isEnabled()) {
                    reminderManager.disable()
                    text = "ATIVAR LEMBRETES E NOTIFICAÇÕES"
                    status.text = "Lembretes desativados. Os lembretes pendentes foram cancelados."
                } else if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 46)
                } else {
                    activateReminders()
                }
            }
        }
        routineButton = Button(this).apply {
            text = if (routineManager.isEnabled()) "ROTINAS PESSOAIS: ATIVAS" else "ATIVAR ROTINAS PESSOAIS"
            isAllCaps = false
            textSize = 14f
            setOnClickListener {
                if (routineManager.isEnabled()) {
                    routineManager.disable()
                    text = "ATIVAR ROTINAS PESSOAIS"
                    status.text = "Rotinas pessoais desativadas. A revisão diária não será mais agendada."
                } else if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 47)
                } else {
                    activatePersonalRoutines()
                }
            }
        }
        val configureAiButton = Button(this).apply {
            text = "⚙  CONFIGURAÇÕES • IA, MODELOS E AUTONOMIA"
            isAllCaps = false
            textSize = 13f
            setOnClickListener { showSettingsMenu() }
        }
        val titleBlock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            addView(title, LinearLayout.LayoutParams(-1, -2))
            addView(subtitle, LinearLayout.LayoutParams(-1, -2))
        }
        val gearButton = Button(this).apply {
            text = "⚙"
            textSize = 24f
            isAllCaps = false
            contentDescription = "Abrir configurações da Gabi"
            setTextColor(android.graphics.Color.rgb(99, 226, 255))
            setBackgroundColor(android.graphics.Color.rgb(14, 38, 62))
            setOnClickListener { showSettingsMenu() }
        }
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(titleBlock, LinearLayout.LayoutParams(0, -2, 1f))
            addView(gearButton, LinearLayout.LayoutParams(58, 54))
        }
        val footer = TextView(this).apply {
            text = "GABI I.A. • TEXTO, VOZ E MEMÓRIA LOCAL"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(100, 129, 159))
            setPadding(0, 22, 0, 0)
        }
        root.addView(topBar, LinearLayout.LayoutParams(-1, -2))
        root.addView(brainLabel, LinearLayout.LayoutParams(-1, -2))
        root.addView(brain, LinearLayout.LayoutParams(-1, dp(250)))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(messageInput, LinearLayout.LayoutParams(-1, -2))
        root.addView(sendButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(talkButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(wakeButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(initiativeButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(reflectNowButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(prioritizeButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(appControlButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(reminderButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(routineButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(configureAiButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(footer, LinearLayout.LayoutParams(-1, -2))
        // Visual system-wide styling: consistent spacing, contrast and clear action hierarchy.
        for (i in 0 until root.childCount) {
            val child = root.getChildAt(i)
            if (child is Button && child !== gearButton) {
                child.setTextColor(if (child === sendButton || child === talkButton) Color.rgb(3, 17, 31) else Color.rgb(205, 229, 245))
                child.textSize = if (child === sendButton || child === talkButton) 14f else 12.5f
                child.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                child.background = roundedBackground(
                    if (child === sendButton || child === talkButton) Color.rgb(76, 219, 255) else Color.rgb(12, 30, 51),
                    14,
                    if (child === sendButton || child === talkButton) Color.rgb(76, 219, 255) else Color.rgb(35, 83, 113)
                )
                child.minimumHeight = dp(48)
                val lp = child.layoutParams as? LinearLayout.LayoutParams
                lp?.setMargins(0, dp(5), 0, dp(3))
                if (lp != null) child.layoutParams = lp
            }
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setBackgroundColor(Color.rgb(3, 9, 24))
            addView(root, ScrollView.LayoutParams(-1, -2))
        }
        setContentView(scroll)
        if (intent?.getBooleanExtra(WakeWordService.EXTRA_WAKE, false) == true) {
            getSharedPreferences("gabi_autonomy", MODE_PRIVATE).edit().putBoolean("wake_enabled", false).apply()
            wakeButton.text = "ATIVAR ESCUTA: HEY GABI"
            status.postDelayed({ startListening() }, 700L)
        } else {
            val wakeEnabled = getSharedPreferences("gabi_autonomy", MODE_PRIVATE).getBoolean("wake_enabled", false)
            if (wakeEnabled) wakeButton.text = "DESATIVAR ESCUTA GABI"
            status.text = autonomy.proactiveOpening()
        }
    }

    override fun onResume() {
        super.onResume()
        if (::appControlButton.isInitialized) {
            appControlButton.text = if (GabiAccessibilityService.isEnabled(this)) "CONTROLE DE APPS: ATIVO" else "CONTROLE DE APPS: OPCIONAL"
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent?.getBooleanExtra(WakeWordService.EXTRA_WAKE, false) == true) {
            getSharedPreferences("gabi_autonomy", MODE_PRIVATE).edit().putBoolean("wake_enabled", false).apply()
            wakeButton.text = "ATIVAR ESCUTA: HEY GABI"
            status.text = "Gabi ativada. Pode falar."
            status.postDelayed({ startListening() }, 500L)
        }
    }

    private fun activatePersonalRoutines() {
        routineManager.enable()
        routineButton.text = "ROTINAS PESSOAIS: ATIVAS"
        status.text = "Rotinas pessoais ativadas. A Gabi vai preparar uma revisão local dos objetivos e da agenda por volta das 9h diariamente. O Android pode atrasar a notificação."
    }

    private fun activateReminders() {
        reminderManager.enable()
        reminderButton.text = "LEMBRETES: ATIVOS"
        status.text = "Lembretes ativados. Diga: 'me lembre de estudar em 10 minutos'. Você pode listar ou cancelar lembretes por mensagem."
    }

    private fun activateInitiativeMode() {
        initiativeManager.enable()
        initiativeButton.text = "DESATIVAR NÚCLEO DE INICIATIVA"
        status.text = "Núcleo de iniciativa ativado. A Gabi revisará os dados locais e poderá preparar sugestões periódicas. O Android pode atrasar a execução; isso não equivale a pensamento contínuo nem a ações externas automáticas."
    }

    private fun toggleWakeListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 43)
            return
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 44)
            return
        }
        val prefs = getSharedPreferences("gabi_autonomy", MODE_PRIVATE)
        val active = prefs.getBoolean("wake_enabled", false)
        if (active) {
            startService(Intent(this, WakeWordService::class.java).setAction(WakeWordService.ACTION_STOP))
            prefs.edit().putBoolean("wake_enabled", false).apply()
            wakeButton.text = "ATIVAR ESCUTA: HEY GABI"
            status.text = "Escuta por palavra-chave desativada."
        } else {
            try {
                val serviceIntent = Intent(this, WakeWordService::class.java)
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
                prefs.edit().putBoolean("wake_enabled", true).apply()
                wakeButton.text = "DESATIVAR ESCUTA GABI"
                status.text = "Escuta experimental ativa. Diga: Hey Gabi."
            } catch (e: Exception) {
                status.text = "Não foi possível iniciar a escuta: ${e.message ?: "erro do Android"}"
            }
        }
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            val languageResult = tts?.setLanguage(Locale("pt", "BR"))
            readyToSpeak = languageResult != TextToSpeech.LANG_MISSING_DATA && languageResult != TextToSpeech.LANG_NOT_SUPPORTED
            if (readyToSpeak) tts?.setSpeechRate(0.96f)
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Este aparelho não disponibilizou reconhecimento de voz."
            speak("O reconhecimento de voz não está disponível neste aparelho.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 42)
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Estou ouvindo…"; talkButton.text = "OUVINDO…" }
                override fun onBeginningOfSpeech() { status.text = "Pode continuar falando." }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { talkButton.text = "FALAR COM A GABI"; status.text = "Processando sua fala…" }
                override fun onError(error: Int) { talkButton.text = "FALAR COM A GABI"; status.text = "Não consegui entender. Toque e tente novamente." }
                override fun onResults(results: Bundle?) {
                    talkButton.text = "FALAR COM A GABI"
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (words.isNullOrBlank()) { status.text = "Não recebi uma frase."; return }
                    handleUserMessage(words)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-BR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com a Gabi")
            }
            sr.startListening(intent)
        }
    }

    private fun handleUserMessage(rawText: String) {
        val words = rawText.trim()
        if (words.isBlank()) return
        val controlCommand = normalizeAccessibilityCommand(words)
        if (controlCommand != null) {
            confirmAndRunAppControl(controlCommand)
            return
        }
        val routineReply = handleRoutineCommand(words)
        if (routineReply != null) {
            status.text = routineReply
            speak(routineReply)
            return
        }
        val reminderReply = handleReminderCommand(words)
        if (reminderReply != null) {
            status.text = reminderReply
            speak(reminderReply)
            return
        }
        // Cérebro / pensamentos autônomos
        val brain = GabiBrain(applicationContext)
        val evolution = GabiEvolution(applicationContext)
        val brainReply = brain.handleThoughtCommand(words)
        if (brainReply != null) {
            status.text = brainReply
            speak(brainReply)
            return
        }
        val evolutionReply = evolution.handleEvolutionCommand(words)
        if (evolutionReply != null) {
            status.text = evolutionReply
            speak(evolutionReply)
            return
        }
        val selfMod = GabiSelfMod(applicationContext)
        val selfModReply = selfMod.handleCommand(words)
        if (selfModReply != null) {
            status.text = selfModReply
            speak(selfModReply)
            return
        }
        val lowerEvo = words.lowercase()
        if (listOf("evolua agora", "evoluir agora", "force a evolução", "forçar evolução", "forcar evolucao", "rode a evolução", "rode a evolucao").any { lowerEvo.contains(it) }) {
            status.text = "Executando ciclo de evolução, Senhor…"
            talkButton.isEnabled = false
            networkExecutor.execute {
                val result = try {
                    evolution.evolve(AegisAutonomy(applicationContext), brain, force = true)
                } catch (e: Exception) {
                    e.message ?: "Falha no ciclo de evolução."
                }
                runOnUiThread {
                    talkButton.isEnabled = true
                    status.text = result
                    speak(result)
                }
            }
            return
        }
        val lowerThought = words.lowercase()
        if (lowerThought.startsWith("pense sobre") || lowerThought.startsWith("reflita sobre") || lowerThought.startsWith("pense em")) {
            val topic = words.replace(Regex("(?i)^(pense sobre|reflita sobre|pense em)\\s*"), "").trim().trimStart(':', ' ', ',')
            if (topic.isBlank()) {
                val reply = "Sobre o que o Senhor deseja que eu reflita?"
                status.text = reply; speak(reply); return
            }
            status.text = "Estou refletindo sobre isso, Senhor…"
            talkButton.isEnabled = false
            networkExecutor.execute {
                val result = try {
                    val autonomyLocal = AegisAutonomy(applicationContext)
                    val mems = AegisMemory(applicationContext).all()
                    if (aiClient.hasApiKey()) {
                        try {
                            val prompt = brain.cognitionPrompt(
                                autonomyContext = autonomyLocal.contextForPlanning() + "\nTÓPICO SOLICITADO PELO USUÁRIO: " + topic,
                                memories = mems,
                                previousThoughts = brain.recentThoughts(5),
                                evolutionContext = GabiEvolution(applicationContext).contextForCognition()
                            )
                            val raw = aiClient.ask(prompt, mems, emptyList())
                            val thought = brain.parseCognitionResponse(raw, offline = false)
                            if (thought != null) "Reflexão concluída, Senhor.\n[${thought.type}] ${thought.content}"
                            else raw.take(800).ifBlank { "Não consegui formular um pensamento claro sobre isso no momento." }
                        } catch (_: Exception) {
                            val thought = brain.reflectOfflineOnTopic(topic, autonomyLocal, mems, evolution)
                            "Reflexão offline concluída, Senhor.\n[${thought.type}] ${thought.content}"
                        }
                    } else {
                        val thought = brain.reflectOfflineOnTopic(topic, autonomyLocal, mems, evolution)
                        "Reflexão offline concluída, Senhor.\n[${thought.type}] ${thought.content}"
                    }
                } catch (e: Exception) {
                    e.message ?: "Falha ao refletir."
                }
                runOnUiThread {
                    talkButton.isEnabled = true
                    conversationHistory.add("user" to words)
                    conversationHistory.add("assistant" to result)
                    while (conversationHistory.size > 12) conversationHistory.removeAt(0)
                    status.text = result
                    speak(result)
                }
            }
            return
        }

        val functionInfo = GabiFunctionHub.handleInfoCommand(words)
        if (functionInfo != null) {
            status.text = functionInfo
            speak(functionInfo)
            return
        }
        val functionInvocation = GabiFunctionHub.parseInvocation(words)
        if (functionInvocation != null) {
            if (!aiClient.hasApiKey()) {
                val reply = "A função ‘${functionInvocation.skill.name}’ está na biblioteca, mas precisa de uma chave de API configurada e conexão para gerar o resultado. Nenhuma ação externa foi executada."
                status.text = reply; speak(reply); return
            }
            status.text = "Gabi está usando a função: ${functionInvocation.skill.name}…"
            talkButton.isEnabled = false
            networkExecutor.execute {
                val result = try {
                    aiClient.ask(GabiFunctionHub.prompt(functionInvocation), AegisMemory(applicationContext).all(), conversationHistory.toList())
                } catch (e: Exception) { e.message ?: "Não consegui executar essa função agora. Verifique a conexão e tente novamente." }
                runOnUiThread {
                    talkButton.isEnabled = true
                    conversationHistory.add("user" to words); conversationHistory.add("assistant" to result)
                    while (conversationHistory.size > 12) conversationHistory.removeAt(0)
                    status.text = "[${functionInvocation.skill.name}]\n$result"
                    speak(result)
                }
            }
            return
        }
        val autonomyReply = autonomy.handleCommand(words)
        if (autonomyReply != null) {
            status.text = autonomyReply
            speak(autonomyReply)
            return
        }
        val planGoal = extractPlanGoal(words)
        if (planGoal != null) {
            if (!aiClient.hasApiKey()) {
                val reply = "Para montar e salvar um plano de várias etapas, configure primeiro uma chave de API no menu de engrenagem. Seu objetivo ainda não foi transformado em plano."
                status.text = reply; speak(reply); return
            }
            status.text = "Gabi está decompondo o objetivo em etapas…"
            talkButton.isEnabled = false
            networkExecutor.execute {
                val result = try {
                    val prompt = "Crie um plano prático para o objetivo: $planGoal. Considere o contexto de continuidade fornecido. Retorne somente de 4 a 8 etapas concretas, uma por linha, numeradas como 1. etapa, sem introdução nem conclusão. Não afirme que executou as etapas."
                    val raw = aiClient.ask(autonomy.planningPrompt(prompt), AegisMemory(applicationContext).all(), conversationHistory.toList())
                    val steps = raw.lines().map { it.trim().replace(Regex("^([0-9]+[.)]\\s*|[-•]\\s*)"), "").trim() }
                        .filter { it.length >= 4 && !it.endsWith(":") && !it.equals("Plano", true) }.distinct().take(8)
                    if (steps.isEmpty()) "A Gabi gerou uma resposta, mas não consegui identificar etapas para salvar. Nenhum plano foi criado. Resposta: $raw"
                    else autonomy.savePlan(planGoal, steps) + "\n\n" + steps.mapIndexed { i, step -> "${i + 1}. $step" }.joinToString("\n")
                } catch (e: Exception) { e.message ?: "Não consegui criar o plano agora. Nenhuma etapa foi salva." }
                runOnUiThread {
                    talkButton.isEnabled = true
                    conversationHistory.add("user" to words); conversationHistory.add("assistant" to result)
                    while (conversationHistory.size > 12) conversationHistory.removeAt(0)
                    status.text = result; speak(result)
                }
            }
            return
        }
        if (requestsExternalAction(words)) {
            val reply = "Essa solicitação pode alterar algo fora da Gabi. Por segurança, nenhuma ação foi executada. Esta versão ainda não tem integração conectada para agir diretamente em outros aplicativos ou serviços. Posso ajudar a preparar os passos ou o conteúdo, e qualquer futura execução precisará da sua confirmação explícita para aquela ação."
            status.text = reply
            speak(reply)
            return
        }
        if (replyEngine.isMemoryCommand(words)) {
            val reply = replyEngine.respond(words)
            status.text = reply
            speak(reply)
            return
        }
        if (!aiClient.hasApiKey()) {
            val reply = replyEngine.respond(words)
            status.text = "$reply Configure uma chave de API no menu de engrenagem para ativar a conversa inteligente completa."
            speak(status.text.toString())
            return
        }
        status.text = "Gabi está pensando…"
        talkButton.isEnabled = false
        networkExecutor.execute {
            val reply = try {
                aiClient.ask(autonomy.planningPrompt(words), AegisMemory(applicationContext).all(), conversationHistory.toList())
            } catch (e: Exception) {
                e.message ?: "Não consegui acessar a IA agora. Verifique a internet e tente novamente."
            }
            runOnUiThread {
                talkButton.isEnabled = true
                conversationHistory.add("user" to words)
                conversationHistory.add("assistant" to reply)
                while (conversationHistory.size > 12) conversationHistory.removeAt(0)
                status.text = reply
                speak(reply)
            }
        }
    }


    private fun handleRoutineCommand(input: String): String? {
        val text = input.trim()
        val lower = text.lowercase(Locale.ROOT)
        if (listOf("ativar rotina diária", "ativar rotina diaria", "ativar rotinas pessoais", "ligar rotina diária", "ligar rotina diaria").any { lower == it }) {
            if (routineManager.isEnabled()) return "As rotinas pessoais já estão ativadas. A revisão diária está programada para aproximadamente 9h."
            if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 47)
                return "O Android precisa da permissão de notificações. Autorize quando aparecer a solicitação para ativar as rotinas pessoais."
            }
            activatePersonalRoutines()
            return "Rotinas pessoais ativadas. A Gabi vai preparar uma revisão local dos objetivos e da agenda por volta das 9h diariamente."
        }
        if (listOf("desativar rotina diária", "desativar rotina diaria", "desativar rotinas pessoais", "desligar rotina diária", "desligar rotina diaria").any { lower == it }) {
            routineManager.disable()
            if (::routineButton.isInitialized) routineButton.text = "ATIVAR ROTINAS PESSOAIS"
            return "Rotinas pessoais desativadas. Nenhuma nova revisão diária será agendada."
        }
        if (listOf("agenda do dia", "preparar agenda do dia", "revisar objetivos", "revisão diária", "revisao diaria", "minha rotina diária", "minha rotina diaria").any { lower == it }) {
            val goals = autonomy.getGoals()
            val taskList = autonomy.listTasks()
            val priorities = autonomy.prioritizeTasks()
            return buildString {
                append("Revisão de hoje\n\n")
                append(if (goals.isEmpty()) "Objetivos: nenhum registrado." else "Objetivos: " + goals.take(5).joinToString("; "))
                append("\n\n").append(taskList)
                append("\n\n").append(priorities)
                if (!routineManager.isEnabled()) append("\n\nA revisão diária automática está desligada. Diga ‘ativar rotina diária’ para receber uma notificação por volta das 9h.")
            }
        }
        if (listOf("status das rotinas", "rotinas pessoais", "minhas rotinas").any { lower == it }) {
            return if (routineManager.isEnabled()) "As rotinas pessoais estão ativas. A Gabi prepara a revisão diária por volta das 9h, sujeita aos limites de execução em segundo plano do Android." else "As rotinas pessoais estão desligadas. Você pode ativá-las pelo botão na tela principal ou dizendo ‘ativar rotina diária’."
        }
        return null
    }

    private fun handleReminderCommand(input: String): String? {
        val text = input.trim()
        val lower = text.lowercase(Locale.ROOT)
        if (listOf("listar lembretes", "meus lembretes", "lembretes pendentes", "quais são meus lembretes", "quais sao meus lembretes").any { lower.contains(it) }) {
            return reminderManager.listReminders()
        }
        val cancelMatch = Regex("(?i)^cancelar lembrete\\s+([a-z0-9-]+)\\s*$").find(text)
        if (cancelMatch != null) return reminderManager.cancelReminder(cancelMatch.groupValues[1])
        val match = Regex("(?i)^(?:gabi[, ]+)?(?:me lembre de|lembre-me de|crie um lembrete para|crie um lembrete:)\\s*(.+?)\\s+em\\s+(\\d{1,4})\\s*(minutos?|mins?|horas?|hrs?)\\s*[.!]?$", RegexOption.IGNORE_CASE).find(text)
        if (match != null) {
            if (!reminderManager.isEnabled()) return "Os lembretes estão desligados. Ative 'LEMBRETES E NOTIFICAÇÕES' na tela principal primeiro."
            val title = match.groupValues[1].trim().trimEnd('.', '!')
            val amount = match.groupValues[2].toLongOrNull() ?: return "Não consegui entender o tempo do lembrete."
            val unit = match.groupValues[3].lowercase(Locale.ROOT)
            val minutes = if (unit.startsWith("h")) amount * 60 else amount
            if (title.isBlank()) return "Diga o que devo lembrar. Exemplo: me lembre de estudar em 10 minutos."
            if (minutes !in 1..10080) return "Escolha um lembrete entre 1 minuto e 7 dias."
            return reminderManager.scheduleReminder(title, minutes)
        }
        if (lower.startsWith("me lembre de ") || lower.startsWith("lembre-me de ") || lower.startsWith("crie um lembrete")) {
            return "Posso criar lembretes relativos. Exemplo: 'me lembre de estudar em 10 minutos' ou 'crie um lembrete para beber água em 2 horas'. Ative os lembretes na tela principal antes."
        }
        return null
    }

    private fun showAppControlOptions() {
        val enabled = GabiAccessibilityService.isEnabled(this)
        val message = if (enabled) {
            """O controle opcional esta habilitado pelo Android. A Gabi so executa as acoes simples reconhecidas depois de voce confirmar cada uma. Ela nao executa acoes em segundo plano por conta propria.

Comandos: voltar, tela inicial, rolar para baixo, rolar para cima e toque em [texto exato]."""
        } else {
            """Este recurso e opcional e vem desligado. Para permitir acoes simples em outros aplicativos, o Android exige que voce habilite manualmente o Servico de Acessibilidade da Gabi.

A permissao pode permitir que o servico leia textos visiveis e interaja com elementos da tela. Ative somente se confiar no aplicativo. Mesmo habilitado, a Gabi pedira confirmacao antes de cada acao reconhecida."""
        }
        AlertDialog.Builder(this)
            .setTitle(if (enabled) "Controle de aplicativos ativo" else "Ativar controle opcional")
            .setMessage(message)
            .setPositiveButton(if (enabled) "Entendi" else "Abrir permissoes do Android") { _, _ ->
                if (!enabled) {
                    startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }
            .setNeutralButton("Desativar instrucoes") { _, _ ->
                Toast.makeText(this, "Para desligar o acesso, desative Gabi I.A. nas configuracoes de Acessibilidade do Android.", Toast.LENGTH_LONG).show()
                startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun normalizeAccessibilityCommand(text: String): String? {
        val lower = text.trim().lowercase(Locale.ROOT)
        return when {
            lower in listOf("gabi, voltar", "gabi voltar", "voltar", "pressionar voltar", "volte") -> "voltar"
            lower in listOf("gabi, tela inicial", "gabi tela inicial", "ir para a tela inicial", "tela inicial") -> "tela inicial"
            lower in listOf("rolar para baixo", "descer a tela", "gabi, rolar para baixo") -> "rolar para baixo"
            lower in listOf("rolar para cima", "subir a tela", "gabi, rolar para cima") -> "rolar para cima"
            lower.startsWith("toque em ") -> "toque em " + text.trim().substringAfter("toque em ", "")
            lower.startsWith("clicar em ") -> "clicar em " + text.trim().substringAfter("clicar em ", "")
            else -> null
        }
    }

    private fun confirmAndRunAppControl(command: String) {
        if (!GabiAccessibilityService.isEnabled(this)) {
            AlertDialog.Builder(this)
                .setTitle("Controle de aplicativos desligado")
                .setMessage("Voce pediu: \"$command\". Para usar esse recurso, habilite a integracao opcional nas configuracoes de Acessibilidade do Android. Nenhuma acao foi executada.")
                .setPositiveButton("Configurar") { _, _ -> startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                .setNegativeButton("Cancelar", null)
                .show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Confirmar acao fora da Gabi")
            .setMessage("""A Gabi esta prestes a executar esta acao na tela atual:

$command

Confirme apenas se a tela e a acao estiverem corretas. Tocar em um item pode enviar, excluir ou confirmar algo dependendo do aplicativo aberto.""")
            .setPositiveButton("Confirmar e executar") { _, _ ->
                val result = GabiAccessibilityService.runApproved(command)
                val message = result ?: "O servico de acessibilidade nao esta disponivel. Nenhuma acao foi executada."
                status.text = message
                speak(message)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun requestsExternalAction(text: String): Boolean {
        val lower = text.lowercase(Locale.ROOT)
        val actionPhrases = listOf(
            "envie a mensagem", "envia a mensagem", "mande a mensagem", "manda a mensagem",
            "envie um email", "envie um e-mail", "mande um email", "mande um e-mail",
            "publique isso", "publica isso", "poste isso", "posta isso", "compre isso", "faça a compra", "faca a compra",
            "transfira o dinheiro", "faça a transferência", "faca a transferencia", "apague o arquivo", "delete o arquivo",
            "instale o aplicativo", "desinstale o aplicativo", "ligue para", "faça login", "faca login", "acesse minha conta"
        )
        return actionPhrases.any { lower.contains(it) }
    }

    private fun extractPlanGoal(text: String): String? {
        val lower = text.lowercase().trim()
        val prefixes = listOf("crie um plano para", "cria um plano para", "monte um plano para", "monta um plano para", "planeje como alcançar", "planeje como alcancar", "quero um plano para", "organize um plano para")
        val prefix = prefixes.firstOrNull { lower.startsWith(it) } ?: return null
        return text.trim().drop(prefix.length).trim().trimEnd('.', '!', '?', ' ').takeIf { it.isNotBlank() }
    }

    private fun showSettingsMenu() {
        val providers = AegisAiClient.Provider.values()
        val providerSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, providers.map { it.displayName })
        }
        providerSpinner.setSelection(providers.indexOf(aiClient.getProvider()).coerceAtLeast(0))
        val modelInput = EditText(this).apply {
            hint = "ID do modelo (ex.: gemini-3-flash-preview)"
            isSingleLine = true
            setText(aiClient.getModel())
        }
        val keyInput = EditText(this).apply {
            hint = "Chave da API do provedor selecionado"
            isSingleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(aiClient.getApiKey().orEmpty())
        }
        val providerDescription = TextView(this).apply {
            textSize = 12f
            setTextColor(android.graphics.Color.rgb(134, 164, 195))
            setPadding(0, 4, 0, 8)
        }
        fun updateProviderFields(index: Int) {
            val provider = providers[index.coerceIn(providers.indices)]
            modelInput.setText(aiClient.getModel(provider))
            keyInput.setText(aiClient.getApiKey(provider).orEmpty())
            providerDescription.text = when (provider) {
                AegisAiClient.Provider.GEMINI -> "Google Gemini. Modelo padrão: Gemini 3 Flash Preview. A disponibilidade depende da sua chave e da API Google AI."
                AegisAiClient.Provider.OPENAI -> "OpenAI API, compatível com modelos GPT. Requer uma chave da API OpenAI e cobrança separada da assinatura ChatGPT."
                AegisAiClient.Provider.GROK -> "xAI Grok API. Requer uma chave xAI e acesso/cobrança próprios."
            }
        }
        providerSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) = updateProviderFields(position)
        }
        val sectionTitle = TextView(this).apply {
            text = "NÚCLEO DE INTELIGÊNCIA"
            textSize = 12f
            letterSpacing = 0.12f
            setTextColor(android.graphics.Color.rgb(99, 226, 255))
            setPadding(0, 8, 0, 4)
        }
        val autonomyInfo = TextView(this).apply {
            text = "PERCEBER  •  RACIOCINAR  •  PLANEJAR  •  AGIR COM PERMISSÃO  •  VERIFICAR  •  APRENDER\n\nA autonomia usa os recursos implementados no aplicativo. Ela não concede acesso ilimitado nem executa ações externas sem confirmação."
            textSize = 12f
            setTextColor(android.graphics.Color.rgb(178, 199, 220))
            setPadding(0, 8, 0, 8)
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 8, 36, 0)
            addView(sectionTitle, LinearLayout.LayoutParams(-1, -2))
            addView(TextView(this@MainActivity).apply { text = "PROVEDOR DE IA"; textSize = 11f }, LinearLayout.LayoutParams(-1, -2))
            addView(providerSpinner, LinearLayout.LayoutParams(-1, -2))
            addView(providerDescription, LinearLayout.LayoutParams(-1, -2))
            addView(TextView(this@MainActivity).apply { text = "MODELO"; textSize = 11f }, LinearLayout.LayoutParams(-1, -2))
            addView(modelInput, LinearLayout.LayoutParams(-1, -2))
            addView(TextView(this@MainActivity).apply { text = "CHAVE DA API"; textSize = 11f; setPadding(0, 8, 0, 0) }, LinearLayout.LayoutParams(-1, -2))
            addView(keyInput, LinearLayout.LayoutParams(-1, -2))
            addView(autonomyInfo, LinearLayout.LayoutParams(-1, -2))
        }
        updateProviderFields(providerSpinner.selectedItemPosition)
        AlertDialog.Builder(this)
            .setTitle("GABI I.A.  |  CENTRAL DE CONTROLE")
            .setView(layout)
            .setPositiveButton("Salvar configuração") { _, _ ->
                val provider = providers[providerSpinner.selectedItemPosition.coerceIn(providers.indices)]
                val model = modelInput.text.toString().trim()
                val key = keyInput.text.toString().trim()
                if (model.isBlank()) {
                    Toast.makeText(this, "Informe o ID do modelo.", Toast.LENGTH_LONG).show()
                } else {
                    aiClient.saveProvider(provider)
                    aiClient.saveModel(provider, model)
                    if (key.isNotBlank()) aiClient.saveApiKey(provider, key) else aiClient.clearApiKey(provider)
                    status.text = if (key.isNotBlank()) "Núcleo online configurado: ${provider.displayName} / $model." else "Modelo salvo. Adicione uma chave de API para ativar a inteligência online."
                    Toast.makeText(this, "Configurações da Gabi salvas.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNeutralButton("Apagar chave") { _, _ ->
                val provider = providers[providerSpinner.selectedItemPosition.coerceIn(providers.indices)]
                aiClient.clearApiKey(provider)
                status.text = "Chave de ${provider.displayName} apagada. A Gabi usará os recursos locais até configurar outra chave."
            }
            .setNegativeButton("Fechar", null)
            .show()
    }

    private fun speak(text: String) { if (readyToSpeak) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "gabi_reply") }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if ((requestCode == 42 || requestCode == 43 || requestCode == 44 || requestCode == 45 || requestCode == 46 || requestCode == 47) && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            when (requestCode) {
                42 -> startListening()
                45 -> activateInitiativeMode()
                46 -> activateReminders()
                47 -> activatePersonalRoutines()
                else -> toggleWakeListening()
            }
        } else if (requestCode == 42 || requestCode == 43) Toast.makeText(this, "Permita o microfone para usar a voz da Gabi.", Toast.LENGTH_LONG).show()
        else if (requestCode == 44 || requestCode == 45 || requestCode == 46 || requestCode == 47) Toast.makeText(this, "Sem permissão de notificações, os avisos da Gabi podem não aparecer.", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        networkExecutor.shutdownNow()
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun roundedBackground(fill: Int, radiusDp: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radiusDp).toFloat()
        setColor(fill)
        setStroke(dp(1), stroke)
    }

    /** A live neural-core visualization, deliberately not a sphere/orb. */
    private class BrainView(context: android.content.Context) : View(context) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private var phase = 0f
        private val cyan = Color.rgb(80, 226, 255)
        private val blue = Color.rgb(58, 131, 255)
        private val nodes = listOf(
            Pair(.31f,.28f), Pair(.39f,.19f), Pair(.47f,.30f), Pair(.34f,.43f), Pair(.43f,.49f),
            Pair(.29f,.57f), Pair(.39f,.68f), Pair(.48f,.61f), Pair(.53f,.30f), Pair(.61f,.20f),
            Pair(.69f,.29f), Pair(.58f,.44f), Pair(.68f,.48f), Pair(.74f,.58f), Pair(.61f,.67f),
            Pair(.52f,.77f), Pair(.47f,.40f), Pair(.54f,.52f), Pair(.50f,.18f), Pair(.51f,.68f)
        )
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            if (w <= 0 || h <= 0) return
            phase += .018f
            val cx = w * .5f; val cy = h * .46f
            // subtle technical grid
            p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = 0x183b8ca8
            var x = w * .12f
            while (x < w * .9f) { canvas.drawLine(x, h*.08f, x, h*.84f, p); x += w*.08f }
            var y = h * .12f
            while (y < h*.84f) { canvas.drawLine(w*.1f, y, w*.9f, y, p); y += h*.1f }
            // atmospheric halo behind the neural structure
            p.style = Paint.Style.FILL
            p.shader = RadialGradient(cx, cy, w*.42f, intArrayOf(0x3024bfff, 0x1424a8ff, 0x00000000), null, Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, w*.42f, p); p.shader = null
            // brain silhouette: two hemispheres and a luminous outer contour
            val left = Path().apply {
                moveTo(cx, h*.18f)
                cubicTo(w*.39f,h*.10f,w*.25f,h*.19f,w*.25f,h*.34f)
                cubicTo(w*.18f,h*.40f,w*.23f,h*.53f,w*.30f,h*.57f)
                cubicTo(w*.28f,h*.69f,w*.39f,h*.78f,cx,h*.76f)
                close()
            }
            val right = Path().apply {
                moveTo(cx, h*.18f)
                cubicTo(w*.61f,h*.10f,w*.75f,h*.19f,w*.75f,h*.34f)
                cubicTo(w*.82f,h*.40f,w*.77f,h*.53f,w*.70f,h*.57f)
                cubicTo(w*.72f,h*.69f,w*.61f,h*.78f,cx,h*.76f)
                close()
            }
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(w*.25f,h*.15f,w*.75f,h*.78f, intArrayOf(0x1825d8ff,0x332b7cff,0x1421c4ee), null, Shader.TileMode.CLAMP)
            canvas.drawPath(left,p); canvas.drawPath(right,p); p.shader=null
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(1).toFloat(); p.color = 0xAA55DFFF
            canvas.drawPath(left,p); canvas.drawPath(right,p)
            // central corpus callosum
            p.color = 0x9955DFFF; p.strokeWidth = dp(1).toFloat()
            canvas.drawLine(cx, h*.2f, cx, h*.73f, p)
            // neuron connections
            p.strokeWidth = dp(1).toFloat()
            for (i in nodes.indices) {
                val a = nodes[i]; val b = nodes[(i*7+3)%nodes.size]
                val ax=w*a.first; val ay=h*a.second; val bx=w*b.first; val by=h*b.second
                p.color = if (i % 3 == 0) 0xAA50E2FF.toInt() else 0x4C50AFFF
                canvas.drawLine(ax,ay,bx,by,p)
            }
            // signal pulse travels through the graph
            val pulseIndex = ((phase*7).toInt() % nodes.size)
            val pulse = nodes[pulseIndex]
            p.style = Paint.Style.FILL
            p.color = cyan
            canvas.drawCircle(w*pulse.first,h*pulse.second,dp(5).toFloat()*(1f+.25f*sin(phase*3)),p)
            // neural nodes
            for (i in nodes.indices) {
                val n=nodes[i]; val r= if (i==pulseIndex) dp(4).toFloat() else dp(2).toFloat()
                p.color = if (i % 2 == 0) cyan else blue
                canvas.drawCircle(w*n.first,h*n.second,r,p)
            }
            // labels and live telemetry
            p.style = Paint.Style.FILL; p.color = 0xFF86B9D6.toInt(); p.textSize = dp(10).toFloat(); p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            canvas.drawText("NEURAL CORE", w*.08f, h*.93f, p)
            p.textAlign = Paint.Align.RIGHT; p.color = 0xFF4FE0FF.toInt()
            canvas.drawText("VISUALIZAÇÃO", w*.92f, h*.93f, p)
            p.textAlign = Paint.Align.LEFT
            postInvalidateDelayed(50)
        }
    }
}
