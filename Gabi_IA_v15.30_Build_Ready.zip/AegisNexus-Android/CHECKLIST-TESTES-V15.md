# Gabi I.A. v15.30 — Checklist de Testes no Celular

Use este checklist depois de instalar o APK. Marque cada item.  
Anote falhas com o comando exato e o que aconteceu.

---

## 1. Instalação e primeira abertura

- [ ] APK instala sem erro de assinatura / pacote
- [ ] App abre e mostra a interface escura + esfera
- [ ] Título “GABI I.A.” aparece
- [ ] Mensagem de abertura (estilo Jarvis) é falada ou mostrada
- [ ] Não trava na abertura

## 2. Configuração da IA (Gemini)

- [ ] Botão / opção “Configurar IA Gemini” existe
- [ ] Aceita a chave da API
- [ ] Após salvar, uma pergunta simples (“oi”) recebe resposta da IA
- [ ] Resposta vem em tom elegante / formal (estilo Jarvis)
- [ ] Sem chave configurada, o app avisa claramente

## 3. Voz e TTS

- [ ] Botão de microfone inicia o reconhecimento
- [ ] Fala em português é reconhecida
- [ ] A Gabi responde por texto e por voz (TTS)
- [ ] “Hey Gabi” (escuta experimental) reconhece a frase (pode falhar em alguns aparelhos)
- [ ] Notificação de escuta aparece quando ativada

## 4. Memória local

- [ ] “Lembre que meu aniversário é 10 de março” → confirma salvamento
- [ ] “O que você lembra?” → lista a memória
- [ ] “Apague minhas memórias” / comando de limpeza → limpa
- [ ] Memórias sobrevivem ao fechar e reabrir o app

## 5. Objetivos e autonomia

- [ ] “Meu objetivo é melhorar a Gabi I.A.” → registra
- [ ] “Quais são meus objetivos?” → lista
- [ ] “Crie um plano para esse objetivo” → gera etapas numeradas
- [ ] “Inicie o ciclo de trabalho” / “Revise o ciclo” → mostra resumo
- [ ] “Proponha uma ação: abrir configurações” → gera ID de proposta
- [ ] “Autorizar proposta [ID]” → registra (e executa só se for comando permitido)

## 6. Lembretes

- [ ] Ativar “LEMBRETES E NOTIFICAÇÕES”
- [ ] “Me lembre de beber água em 2 minutos”
- [ ] Notificação chega (pode atrasar um pouco por causa do WorkManager)
- [ ] “Listar lembretes” funciona
- [ ] “Cancelar lembrete [ID]” funciona

## 7. Rotinas pessoais

- [ ] Ativar “ROTINAS PESSOAIS”
- [ ] “Agenda do dia” ou “Revisar objetivos” responde com dados locais
- [ ] Desativar rotina cancela o agendamento

## 8. Biblioteca de funções (3000)

- [ ] “Listar funções” → mostra total e categorias
- [ ] “Listar funções página: 1” → mostra 20 funções
- [ ] “Buscar função: revisor” → encontra itens relevantes
- [ ] “Usar função: Revisor de texto | corrija este parágrafo: …” → chama Gemini com a habilidade
- [ ] Resposta da função vem no estilo Jarvis

## 9. Accessibility (controle de apps)

- [ ] Ativar o serviço de Acessibilidade nas configurações do Android
- [ ] Botão no app mostra “CONTROLE DE APPS: ATIVO”
- [ ] Proposta autorizada de “voltar” / “tela inicial” / “rolar” funciona
- [ ] Comandos fora da lista fechada são recusados com explicação clara

## 10. Personalidade Jarvis

- [ ] Cumprimento (“oi”, “bom dia”) → resposta no estilo “Sistemas online… Senhor”
- [ ] “Quem é você?” → apresentação elegante
- [ ] “Como você está?” / “Status” → “Todos os sistemas operacionais…”
- [ ] “Obrigado” → “Às suas ordens…”
- [ ] Conversas livres com Gemini mantêm tom formal, preciso e competente
- [ ] Não usa gíria nem tom excessivamente casual

## 11. Estabilidade e segurança

- [ ] App não trava ao girar a tela
- [ ] App não trava sem internet (mensagens de erro claras)
- [ ] Sem permissão de microfone, avisa e não quebra
- [ ] Nenhuma ação externa é executada sem autorização explícita
- [ ] Consumo de bateria da escuta experimental é aceitável (ou desligável)

## 12. Notificações

- [ ] Iniciativa proativa (se ativada) envia notificação com título “Gabi I.A. — Iniciativa”
- [ ] Lembrete chega com título “Gabi I.A. — Lembrete”
- [ ] Tocar na notificação abre o app

---


## 13. Cérebro autônomo (pensar por vontade própria)

- [ ] Ativar "CÉREBRO AUTÔNOMO" na tela principal
- [ ] Desligar Wi-Fi/dados e pedir "uma reflexão agora" → gera pensamento offline
- [ ] "Pense sobre [tema]" sem internet → responde com reflexão local
- [ ] "O que você está pensando?" mostra pensamentos marcados como offline
- [ ] Com internet + chave Gemini → usa modo online (mais rico)
- [ ] Sem chave Gemini → continua pensando só com dados locais
- [ ] "Pedir uma reflexão agora" gera um pensamento (notificação ou registro interno)
- [ ] "O que você está pensando?" lista pensamentos recentes
- [ ] "Pense sobre [tema]" força uma reflexão direcionada
- [ ] "Apague seus pensamentos" limpa a memória de trabalho
- [ ] Pensamentos de baixa prioridade NÃO geram notificação
- [ ] Pensamentos relevantes (prioridade ≥ 3) geram notificação com título adequado
- [ ] Tom dos pensamentos continua no estilo Jarvis (formal, preciso)


## 14. Evolução autônoma

- [ ] "Como você evoluiu?" / "O que você aprendeu?" mostra geração e lições
- [ ] "Evolua agora" força um ciclo de evolução
- [ ] Registrar um bloqueio ou falha e depois evoluir → nova lição aparece
- [ ] Cérebro autônomo ligado → evolução roda junto com o pensamento
- [ ] "Resetar evolução" volta à geração 1
- [ ] Pensamentos offline passam a mencionar geração / lições quando relevante


## 15. Auto-modificação

- [ ] "Status de auto-modificação" mostra versão de overrides
- [ ] "Reescreva-se: seja mais direta" altera comportamento
- [ ] "Reescreva-se: priorize bloqueios" grava regra
- [ ] Após override, nova conversa/reflexão reflete a mudança
- [ ] "Grave o módulo teste | texto de política" salva módulo
- [ ] "Liste módulos" lista o módulo
- [ ] "Proponha um patch: MainActivity.kt | descrição | trecho" grava proposta
- [ ] "Liste patches" mostra a proposta
- [ ] "Resetar comportamento" limpa overrides
- [ ] Confirma que NÃO substitui o APK sozinha (mensagem clara)

### Como reportar falhas

Para cada item que falhar, anote:

1. Comando ou ação exata
2. O que esperava
3. O que aconteceu (print ou texto da resposta)
4. Modelo do celular + versão do Android

Envie esse relatório que eu corrijo na próxima versão.

---

**Versão do checklist:** 15.30  
**Data:** 2026-10-18
