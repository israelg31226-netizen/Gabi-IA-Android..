# Gabi I.A. v15.30 — Build

## Requisitos
- JDK 17
- Android SDK 35 (ou GitHub Actions / Android Studio)

## Gerar APK (local)
```bash
chmod +x gradlew
./gradlew assembleDebug
```
Saída: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions
Push na `main`/`master` ou dispare **Build Gabi IA APK** manualmente.
Artefato: `Gabi-IA-v15.30-debug-apk`

## Estrutura mínima na raiz do repo
```
app/
.github/workflows/android.yml
gradle/wrapper/
gradlew
gradlew.bat
build.gradle.kts
settings.gradle.kts
gradle.properties
```
