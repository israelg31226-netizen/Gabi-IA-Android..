package com.aegisnexus.app

import android.content.Context
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

/** Lembretes locais agendados com WorkManager; não acessa serviços externos. */
class GabiReminderManager(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val workManager = WorkManager.getInstance(appContext)

    fun isEnabled(): Boolean = prefs.getBoolean(KEY_ENABLED, false)

    fun enable() { prefs.edit().putBoolean(KEY_ENABLED, true).apply() }

    fun disable() {
        prefs.edit().putBoolean(KEY_ENABLED, false).apply()
        val items = readItems()
        items.filter { it.optString("status") == "pending" }.forEach {
            val id = it.optString("id")
            if (id.isNotBlank()) workManager.cancelUniqueWork(workName(id))
            it.put("status", "cancelled")
        }
        saveItems(items)
    }

    @Synchronized fun scheduleReminder(title: String, delayMinutes: Long): String {
        if (!isEnabled()) return "Os lembretes estão desligados. Ative-os na tela principal antes de criar um lembrete."
        val clean = title.trim().take(180)
        if (clean.isBlank()) return "Diga o que devo lembrar."
        val id = UUID.randomUUID().toString().take(8)
        val triggerAt = System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(delayMinutes)
        val item = JSONObject()
            .put("id", id)
            .put("title", clean)
            .put("status", "pending")
            .put("created_at", now())
            .put("trigger_at", triggerAt)
        val items = readItems()
        items.add(item)
        saveItems(items.takeLast(100))
        val request = OneTimeWorkRequestBuilder<GabiReminderWorker>()
            .setInitialDelay(delayMinutes, TimeUnit.MINUTES)
            .setInputData(Data.Builder().putString(GabiReminderWorker.KEY_ID, id).putString(GabiReminderWorker.KEY_TITLE, clean).build())
            .build()
        workManager.enqueueUniqueWork(workName(id), ExistingWorkPolicy.REPLACE, request)
        return "Lembrete agendado: ‘$clean’ daqui a $delayMinutes minuto(s). ID: $id. O Android pode atrasar a notificação para economizar bateria."
    }

    @Synchronized fun listReminders(): String {
        val items = readItems().takeLast(50).reversed()
        if (items.isEmpty()) return "Você ainda não tem lembretes registrados. Exemplo: ‘me lembre de estudar em 10 minutos’."
        val visible = items.filter { it.optString("status") != "cancelled" }.take(15)
        if (visible.isEmpty()) return "Não há lembretes ativos."
        val lines = visible.map { item ->
            val id = item.optString("id")
            val title = item.optString("title")
            val state = when (item.optString("status")) {
                "pending" -> "pendente"
                "triggered" -> "notificação acionada"
                else -> item.optString("status", "desconhecido")
            }
            val time = if (item.optLong("trigger_at", 0L) > 0L) SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(item.optLong("trigger_at"))) else "horário indisponível"
            "• $title | $state | $time | ID: $id"
        }
        return "Seus lembretes recentes:\n" + lines.joinToString("\n")
    }

    @Synchronized fun cancelReminder(id: String): String {
        val items = readItems()
        val item = items.firstOrNull { it.optString("id").equals(id, ignoreCase = true) }
            ?: return "Não encontrei um lembrete com o ID $id. Diga ‘listar lembretes’ para ver os IDs."
        if (item.optString("status") != "pending") return "O lembrete ${item.optString("title")} não está pendente (estado: ${item.optString("status")})."
        workManager.cancelUniqueWork(workName(item.optString("id")))
        item.put("status", "cancelled")
        saveItems(items)
        return "Lembrete cancelado: ${item.optString("title")} (ID: ${item.optString("id")})."
    }

    @Synchronized fun markTriggered(id: String) {
        val items = readItems()
        val item = items.firstOrNull { it.optString("id") == id } ?: return
        if (item.optString("status") == "pending") {
            item.put("status", "triggered")
            item.put("triggered_at", now())
            saveItems(items)
        }
    }

    private fun readItems(): MutableList<JSONObject> = try {
        val array = JSONArray(prefs.getString(KEY_ITEMS, "[]") ?: "[]")
        (0 until array.length()).mapNotNull { array.optJSONObject(it) }.toMutableList()
    } catch (_: Exception) { mutableListOf() }

    private fun saveItems(items: List<JSONObject>) {
        prefs.edit().putString(KEY_ITEMS, JSONArray(items).toString()).apply()
    }

    private fun now(): String = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
    private fun workName(id: String) = "gabi_reminder_$id"

    companion object {
        const val PREFS = "gabi_reminders"
        const val KEY_ENABLED = "reminders_enabled"
        private const val KEY_ITEMS = "reminders_json"
    }
}
