package com.aegisnexus.app

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.Calendar
import java.util.concurrent.TimeUnit

/** Rotina pessoal diária opcional. O horário de 09:00 é aproximado, pois o Android pode adiar trabalho em segundo plano. */
class GabiRoutineManager(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val workManager = WorkManager.getInstance(appContext)

    fun isEnabled(): Boolean = prefs.getBoolean(KEY_ENABLED, false)

    fun enable() {
        prefs.edit().putBoolean(KEY_ENABLED, true).apply()
        scheduleNextDaily()
    }

    fun disable() {
        prefs.edit().putBoolean(KEY_ENABLED, false).apply()
        workManager.cancelUniqueWork(WORK_NAME)
    }

    fun ensureScheduled() {
        if (isEnabled()) scheduleNextDaily()
    }

    fun scheduleNextDaily() {
        if (!isEnabled()) return
        val now = Calendar.getInstance()
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 9)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (!after(now)) add(Calendar.DAY_OF_YEAR, 1)
        }
        val delay = (next.timeInMillis - System.currentTimeMillis()).coerceAtLeast(60_000L)
        val request = OneTimeWorkRequestBuilder<GabiDailyRoutineWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .build()
        workManager.enqueueUniqueWork(WORK_NAME, ExistingWorkPolicy.REPLACE, request)
    }

    companion object {
        const val PREFS = "gabi_personal_routines"
        const val KEY_ENABLED = "daily_routine_enabled"
        const val WORK_NAME = "gabi_daily_personal_routine"
    }
}
