package com.aegisnexus.app

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Data
import java.util.concurrent.TimeUnit

/**
 * Agenda a reflexão proativa.
 * Não exige rede: o cérebro funciona offline com raciocínio local.
 * Quando há Gemini + internet, usa o modo online automaticamente.
 */
class GabiInitiativeManager(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val workManager = WorkManager.getInstance(appContext)

    fun isEnabled(): Boolean = prefs.getBoolean(KEY_ENABLED, false)

    fun enable() {
        prefs.edit().putBoolean(KEY_ENABLED, true).apply()
        // Sem restrição de rede: o cérebro roda offline também
        val request = PeriodicWorkRequestBuilder<GabiInitiativeWorker>(1, TimeUnit.HOURS)
            .build()
        workManager.enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
    }

    fun disable() {
        prefs.edit().putBoolean(KEY_ENABLED, false).apply()
        workManager.cancelUniqueWork(WORK_NAME)
        workManager.cancelUniqueWork(ONCE_NAME)
    }

    fun reflectNow() {
        val request = OneTimeWorkRequestBuilder<GabiInitiativeWorker>()
            .setInputData(Data.Builder().putBoolean("one_shot", true).build())
            .build()
        workManager.enqueueUniqueWork(ONCE_NAME, ExistingWorkPolicy.KEEP, request)
    }

    companion object {
        const val PREFS = "gabi_autonomy"
        const val KEY_ENABLED = "initiative_enabled"
        const val WORK_NAME = "gabi_proactive_reflection"
        const val ONCE_NAME = "gabi_reflection_once"
    }
}
