package com.aegisnexus.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters

/** Prepara uma revisão local diária de objetivos e pendências; não executa ações externas. */
class GabiDailyRoutineWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences(GabiRoutineManager.PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(GabiRoutineManager.KEY_ENABLED, false)) return Result.success()
        return try {
            val autonomy = AegisAutonomy(applicationContext)
            val goals = autonomy.getGoals()
            val tasks = autonomy.listTasks()
            val priorities = autonomy.prioritizeTasks()
            val summary = buildString {
                append("Revisão diária da Gabi I.A.\n\n")
                append(if (goals.isEmpty()) "Objetivos: nenhum registrado." else "Objetivos principais: " + goals.take(3).joinToString("; "))
                append("\n\nAgenda e pendências: ")
                append(tasks.take(700))
                append("\n\nPróximo passo sugerido: ")
                append(priorities.take(650))
                append("\n\nAbra a Gabi para revisar, ajustar prioridades e registrar o que mudou.")
            }.take(3000)
            showNotification(summary)
            prefs.edit().putLong("last_daily_review_at", System.currentTimeMillis()).apply()
            GabiRoutineManager(applicationContext).scheduleNextDaily()
            Result.success()
        } catch (_: SecurityException) {
            GabiRoutineManager(applicationContext).scheduleNextDaily()
            Result.success()
        } catch (_: Exception) {
            GabiRoutineManager(applicationContext).scheduleNextDaily()
            Result.retry()
        }
    }

    private fun showNotification(summary: String) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Rotinas pessoais da Gabi", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val openApp = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(applicationContext, 1209, openApp,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_my_calendar)
            .setContentTitle("Sua agenda diária está pronta")
            .setContentText("Revise seus objetivos e tarefas pendentes com a Gabi.")
            .setStyle(NotificationCompat.BigTextStyle().bigText(summary))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build()
        manager.notify(NOTIFICATION_ID, notification)
    }

    companion object {
        private const val CHANNEL_ID = "gabi_daily_routines"
        private const val NOTIFICATION_ID = 7410
    }
}
