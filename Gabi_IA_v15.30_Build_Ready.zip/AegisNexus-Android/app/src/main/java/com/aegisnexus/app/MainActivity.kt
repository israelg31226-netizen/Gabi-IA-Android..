package com.aegisnexus.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.sin

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private lateinit var status: TextView
    private lateinit var talkButton: Button
    private var readyToSpeak = false
    private lateinit var replyEngine: AegisReplyEngine
    private lateinit var aiClient: AegisAiClient
    private lateinit var autonomy: AegisAutonomy
    private lateinit var wakeButton: Button
    private lateinit var initiativeButton: Button
    private lateinit var initiativeManager: GabiInitiativeManager
    private lateinit var appControlButton: Button
    private lateinit var reminderButton: Button
    private lateinit var reminderManager: GabiReminderManager
    private lateinit var routineButton: Button
    private lateinit var routineManager: GabiRoutineManager
    private val networkExecutor = Executors.newSingleThreadExecutor()
    private val conversationHistory = mutableListOf<Pair<String, String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(3, 9, 24)
        window.navigationBarColor = android.graphics.Color.rgb(3, 9, 24)
        tts = TextToSpeech(this, this)
        replyEngine = AegisReplyEngine(applicationContext)
        aiClient = AegisAiClient(applicationContext)
        autonomy = AegisAutonomy(applicationContext)
        initiativeManager = GabiInitiativeManager(applicationContext)
        reminderManager = GabiReminderManager(applicationContext)
        routineManager = GabiRoutineManager(applicationContext)
        routineManager.ensureScheduled()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 30, 28, 28)
            setBackgroundColor(android.graphics.Color.rgb(3, 9, 24))
        }
        val title = TextView(this).apply {
            text = "GABI I.A."
            textSize = 27f
            letterSpacing = 0.18f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(99, 226, 255))
        }
        val subtitle = TextView(this).apply {
            text = "SUA ASSISTENTE PESSOAL INTELIGENTE"
            textSize = 11f
            letterSpacing = 0.12f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(134, 164, 195))
        }
        val orb = OrbView(this)
        status = TextView(this).apply {
            text = "Sistema inicializado. Toque para falar."
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            setPadding(8, 18, 8, 18)
        }
        val messageInput = EditText(this).apply {
            hint = "Digite uma mensagem para a Gabi…"
            setTextColor(android.graphics.Color.WHITE)
            setHintTextColor(android.graphics.Color.rgb(134, 164, 195))
            textSize = 16f
            setSingleLine(false)
            minLines = 1
            maxLines = 3
            setPadding(18, 12, 18, 12)
            setBackgroundColor(android.graphics.Color.rgb(14, 29, 50))
        }
        val sendButton = Button(this).apply {
            text = "ENVIAR MENSAGEM"
            isAllCaps = false
            setOnClickListener {
                val message = messageInput.text.toString().trim()
                if (message.isNotBlank()) {
                    messageInput.text.clear()
                    handleUserMessage(message)
                } else {
                    status.text = "Digite uma mensagem primeiro."
                }
            }
        }
        talkButton = Button(this).apply {
            text = "FALAR COM A GABI"
            isAllCaps = false
            textSize = 16f
            setOnClickListener { startListening() }
        }
        wakeButton = Button(this).apply {
            text = "ATIVAR ESCUTA: HEY GABI"
            isAllCaps = false
            textSize = 14f
            setOnClickListener { toggleWakeListening() }
        }
        initiativeButton = Button(this).apply {
            text = if (initiativeManager.isEnabled()) "DESATIVAR CÉREBRO AUTÔNOMO" else "ATIVAR CÉREBRO AUTÔNOMO"
            isAllCaps = false
            textSize = 14f
            setOnClickListener {
                if (initiativeManager.isEnabled()) {
                    initiativeManager.disable()
                    text = "ATIVAR CÉREBRO AUTÔNOMO"
                    status.text = "Cérebro autônomo desativado. A Gabi só pensará quando o Senhor pedir."
                } else if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 45)
                } else {
                    activateInitiativeMode()
                }
            }
        }
        val reflectNowButton = Button(this).apply {
            text = "PEDIR UMA REFLEXÃO AGORA"
            isAllCaps = false
            textSize = 14f
            setOnClickListener {
                if (!aiClient.hasApiKey()) {
                    status.text = "Configure a chave Gemini para a Gabi poder refletir com a IA."
                } else {
                    initiativeManager.reflectNow()
                    status.text = "Solicitei uma reflexão imediata (online ou offline). Se houver algo relevante, a Gabi registrará o pensamento e poderá notificar."
                }
            }
        }
        val prioritizeButton = Button(this).apply {
            text = "PRIORIZAR TAREFAS E PRÓXIMO PASSO"
            isAllCaps = false
            textSize = 14f
            setOnClickListener {
                val reply = autonomy.prioritizeTasks()
                status.text = reply
                speak(reply)
            }
        }
        appControlButton = Button(this).apply {
            text = if (GabiAccessibilityService.isEnabled(this@MainActivity)) "CONTROLE DE APPS: ATIVO" else "CONTROLE DE APPS: OPCIONAL"
            isAllCaps = false
            textSize = 14f
            setOnClickListener { showAppControlOptions() }
        }
        reminderButton = Button(this).apply {
            text = if (reminderManager.isEnabled()) "LEMBRETES: ATIVOS" else "ATIVAR LEMBRETES E NOTIFICAÇÕES"
            isAllCaps = false
            textSize = 14f
            setOnClickListener {
                if (reminderManager.isEnabled()) {
                    reminderManager.disable()
                    text = "ATIVAR LEMBRETES E NOTIFICAÇÕES"
                    status.text = "Lembretes desativados. Os lembretes pendentes foram cancelados."
                } else if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 46)
                } else {
                    activateReminders()
                }
            }
        }
        routineButton = Button(this).apply {
            text = if (routineManager.isEnabled()) "ROTINAS PESSOAIS: ATIVAS" else "ATIVAR ROTINAS PESSOAIS"
            isAllCaps = false
            textSize = 14f
            setOnClickListener {
                if (routineManager.isEnabled()) {
                    routineManager.disable()
                    text = "ATIVAR ROTINAS PESSOAIS"
                    status.text = "Rotinas pessoais desativadas. A revisão diária não será mais agendada."
                } else if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 47)
                } else {
                    activatePersonalRoutines()
                }
            }
        }
        val configureAiButton = Button(this).apply {
            text = "CONFIGURAR IA"
            isAllCaps = false
            textSize = 14f
            setOnClickListener { showAiConfiguration() }
        }
        val footer = TextView(this).apply {
            text = "GABI I.A. • TEXTO, VOZ E MEMÓRIA LOCAL"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(100, 129, 159))
            setPadding(0, 22, 0, 0)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2))
        root.addView(orb, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(messageInput, LinearLayout.LayoutParams(-1, -2))
        root.addView(sendButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(talkButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(wakeButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(initiativeButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(reflectNowButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(prioritizeButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(appControlButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(reminderButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(routineButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(configureAiButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(footer, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        if (intent?.getBooleanExtra(WakeWordService.EXTRA_WAKE, false) == true) {
            getSharedPreferences("gabi_autonomy", MODE_PRIVATE).edit().putBoolean("wake_enabled", false).apply()
            wakeButton.text = "ATIVAR ESCUTA: HEY GABI"
            status.postDelayed({ startListening() }, 700L)
        } else {
            val wakeEnabled = getSharedPreferences("gabi_autonomy", MODE_PRIVATE).getBoolean("wake_enabled", false)
            if (wakeEnabled) wakeButton.text = "DESATIVAR ESCUTA GABI"
            status.text = autonomy.proactiveOpening()
        }
    }

    override fun onResume() {
        super.onResume()
        if (::appControlButton.isInitialized) {
            appControlButton.text = if (GabiAccessibilityService.isEnabled(this)) "CONTROLE DE APPS: ATIVO" else "CONTROLE DE APPS: OPCIONAL"
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent?.getBooleanExtra(WakeWordService.EXTRA_WAKE, false) == true) {
            getSharedPreferences("gabi_autonomy", MODE_PRIVATE).edit().putBoolean("wake_enabled", false).apply()
            wakeButton.text = "ATIVAR ESCUTA: HEY GABI"
            status.text = "Gabi ativada. Pode falar."
            status.postDelayed({ startListening() }, 500L)
        }
    }

    private fun activatePersonalRoutines() {
        routineManager.enable()
        routineButton.text = "ROTINAS PESSOAIS: ATIVAS"
        status.text = "Rotinas pessoais ativadas. A Gabi vai preparar uma revisão local dos objetivos e da agenda por volta das 9h diariamente. O Android pode atrasar a notificação."
    }

    private fun activateReminders() {
        reminderManager.enable()
        reminderButton.text = "LEMBRETES: ATIVOS"
        status.text = "Lembretes ativados. Diga: 'me lembre de estudar em 10 minutos'. Você pode listar ou cancelar lembretes por mensagem."
    }

    private fun activateInitiativeMode() {
        initiativeManager.enable()
        initiativeButton.text = "DESATIVAR NÚCLEO DE INICIATIVA"
        status.text = "Cérebro autônomo ativado, Senhor. Funciona offline. A Gabi pensa, aprende com resultados e evolui a própria priorização cerca de uma vez por hora."
    }

    private fun toggleWakeListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 43)
            return
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 44)
            return
        }
        val prefs = getSharedPreferences("gabi_autonomy", MODE_PRIVATE)
        val active = prefs.getBoolean("wake_enabled", false)
        if (active) {
            startService(Intent(this, WakeWordService::class.java).setAction(WakeWordService.ACTION_STOP))
            prefs.edit().putBoolean("wake_enabled", false).apply()
            wakeButton.text = "ATIVAR ESCUTA: HEY GABI"
            status.text = "Escuta por palavra-chave desativada."
        } else {
            try {
                val serviceIntent = Intent(this, WakeWordService::class.java)
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
                prefs.edit().putBoolean("wake_enabled", true).apply()
                wakeButton.text = "DESATIVAR ESCUTA GABI"
                status.text = "Escuta experimental ativa. Diga: Hey Gabi."
            } catch (e: Exception) {
                status.text = "Não foi possível iniciar a escuta: ${e.message ?: "erro do Android"}"
            }
        }
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            val languageResult = tts?.setLanguage(Locale("pt", "BR"))
            readyToSpeak = languageResult != TextToSpeech.LANG_MISSING_DATA && languageResult != TextToSpeech.LANG_NOT_SUPPORTED
            if (readyToSpeak) tts?.setSpeechRate(0.96f)
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Este aparelho não disponibilizou reconhecimento de voz."
            speak("O reconhecimento de voz não está disponível neste aparelho.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 42)
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Estou ouvindo…"; talkButton.text = "OUVINDO…" }
                override fun onBeginningOfSpeech() { status.text = "Pode continuar falando." }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { talkButton.text = "FALAR COM A GABI"; status.text = "Processando sua fala…" }
                override fun onError(error: Int) { talkButton.text = "FALAR COM A GABI"; status.text = "Não consegui entender. Toque e tente novamente." }
                override fun onResults(results: Bundle?) {
                    talkButton.text = "FALAR COM A GABI"
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (words.isNullOrBlank()) { status.text = "Não recebi uma frase."; return }
                    handleUserMessage(words)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-BR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com a Gabi")
            }
            sr.startListening(intent)
        }
    }

    private fun handleUserMessage(rawText: String) {
        val words = rawText.trim()
        if (words.isBlank()) return
        val controlCommand = normalizeAccessibilityCommand(words)
        if (controlCommand != null) {
            confirmAndRunAppControl(controlCommand)
            return
        }
        val routineReply = handleRoutineCommand(words)
        if (routineReply != null) {
            status.text = routineReply
            speak(routineReply)
            return
        }
        val reminderReply = handleReminderCommand(words)
        if (reminderReply != null) {
            status.text = reminderReply
            speak(reminderReply)
            return
        }
        // Cérebro / pensamentos autônomos
        val brain = GabiBrain(applicationContext)
        val evolution = GabiEvolution(applicationContext)
        val brainReply = brain.handleThoughtCommand(words)
        if (brainReply != null) {
            status.text = brainReply
            speak(brainReply)
            return
        }
        val evolutionReply = evolution.handleEvolutionCommand(words)
        if (evolutionReply != null) {
            status.text = evolutionReply
            speak(evolutionReply)
            return
        }
        val selfMod = GabiSelfMod(applicationContext)
        val selfModReply = selfMod.handleCommand(words)
        if (selfModReply != null) {
            status.text = selfModReply
            speak(selfModReply)
            return
        }
        val lowerEvo = words.lowercase()
        if (listOf("evolua agora", "evoluir agora", "force a evolução", "forçar evolução", "forcar evolucao", "rode a evolução", "rode a evolucao").any { lowerEvo.contains(it) }) {
            status.text = "Executando ciclo de evolução, Senhor…"
            talkButton.isEnabled = false
            networkExecutor.execute {
                val result = try {
                    evolution.evolve(AegisAutonomy(applicationContext), brain, force = true)
                } catch (e: Exception) {
                    e.message ?: "Falha no ciclo de evolução."
                }
                runOnUiThread {
                    talkButton.isEnabled = true
                    status.text = result
                    speak(result)
                }
            }
            return
        }
        val lowerThought = words.lowercase()
        if (lowerThought.startsWith("pense sobre") || lowerThought.startsWith("reflita sobre") || lowerThought.startsWith("pense em")) {
            val topic = words.replace(Regex("(?i)^(pense sobre|reflita sobre|pense em)\\s*"), "").trim().trimStart(':', ' ', ',')
            if (topic.isBlank()) {
                val reply = "Sobre o que o Senhor deseja que eu reflita?"
                status.text = reply; speak(reply); return
            }
            status.text = "Estou refletindo sobre isso, Senhor…"
            talkButton.isEnabled = false
            networkExecutor.execute {
                val result = try {
                    val autonomyLocal = AegisAutonomy(applicationContext)
                    val mems = AegisMemory(applicationContext).all()
                    if (aiClient.hasApiKey()) {
                        try {
                            val prompt = brain.cognitionPrompt(
                                autonomyContext = autonomyLocal.contextForPlanning() + "\nTÓPICO SOLICITADO PELO USUÁRIO: " + topic,
                                memories = mems,
                                previousThoughts = brain.recentThoughts(5),
                                evolutionContext = GabiEvolution(applicationContext).contextForCognition()
                            )
                            val raw = aiClient.ask(prompt, mems, emptyList())
                            val thought = brain.parseCognitionResponse(raw, offline = false)
                            if (thought != null) "Reflexão concluída, Senhor.\n[${thought.type}] ${thought.content}"
                            else raw.take(800).ifBlank { "Não consegui formular um pensamento claro sobre isso no momento." }
                        } catch (_: Exception) {
                            val thought = brain.reflectOfflineOnTopic(topic, autonomyLocal, mems, evolution)
                            "Reflexão offline concluída, Senhor.\n[${thought.type}] ${thought.content}"
                        }
                    } else {
                        val thought = brain.reflectOfflineOnTopic(topic, autonomyLocal, mems, evolution)
                        "Reflexão offline concluída, Senhor.\n[${thought.type}] ${thought.content}"
                    }
                } catch (e: Exception) {
                    e.message ?: "Falha ao refletir."
                }
                runOnUiThread {
                    talkButton.isEnabled = true
                    conversationHistory.add("user" to words)
                    conversationHistory.add("assistant" to result)
                    while (conversationHistory.size > 12) conversationHistory.removeAt(0)
                    status.text = result
                    speak(result)
                }
            }
            return
        }

        val functionInfo = GabiFunctionHub.handleInfoCommand(words)
        if (functionInfo != null) {
            status.text = functionInfo
            speak(functionInfo)
            return
        }
        val functionInvocation = GabiFunctionHub.parseInvocation(words)
        if (functionInvocation != null) {
            if (!aiClient.hasApiKey()) {
                val reply = "A função ‘${functionInvocation.skill.name}’ está na biblioteca, mas precisa da chave Gemini e de conexão para gerar o resultado. Nenhuma ação externa foi executada."
                status.text = reply; speak(reply); return
            }
            status.text = "Gabi está usando a função: ${functionInvocation.skill.name}…"
            talkButton.isEnabled = false
            networkExecutor.execute {
                val result = try {
                    aiClient.ask(GabiFunctionHub.prompt(functionInvocation), AegisMemory(applicationContext).all(), conversationHistory.toList())
                } catch (e: Exception) { e.message ?: "Não consegui executar essa função agora. Verifique a conexão e tente novamente." }
                runOnUiThread {
                    talkButton.isEnabled = true
                    conversationHistory.add("user" to words); conversationHistory.add("assistant" to result)
                    while (conversationHistory.size > 12) conversationHistory.removeAt(0)
                    status.text = "[${functionInvocation.skill.name}]\n$result"
                    speak(result)
                }
            }
            return
        }
        val autonomyReply = autonomy.handleCommand(words)
        if (autonomyReply != null) {
            status.text = autonomyReply
            speak(autonomyReply)
            return
        }
        val planGoal = extractPlanGoal(words)
        if (planGoal != null) {
            if (!aiClient.hasApiKey()) {
                val reply = "Para montar e salvar um plano de várias etapas, configure primeiro a chave Gemini. Seu objetivo ainda não foi transformado em plano."
                status.text = reply; speak(reply); return
            }
            status.text = "Gabi está decompondo o objetivo em etapas…"
            talkButton.isEnabled = false
            networkExecutor.execute {
                val result = try {
                    val prompt = "Crie um plano prático para o objetivo: $planGoal. Considere o contexto de continuidade fornecido. Retorne somente de 4 a 8 etapas concretas, uma por linha, numeradas como 1. etapa, sem introdução nem conclusão. Não afirme que executou as etapas."
                    val raw = aiClient.ask(autonomy.planningPrompt(prompt), AegisMemory(applicationContext).all(), conversationHistory.toList())
                    val steps = raw.lines().map { it.trim().replace(Regex("^([0-9]+[.)]\\s*|[-•]\\s*)"), "").trim() }
                        .filter { it.length >= 4 && !it.endsWith(":") && !it.equals("Plano", true) }.distinct().take(8)
                    if (steps.isEmpty()) "A Gabi gerou uma resposta, mas não consegui identificar etapas para salvar. Nenhum plano foi criado. Resposta: $raw"
                    else autonomy.savePlan(planGoal, steps) + "\n\n" + steps.mapIndexed { i, step -> "${i + 1}. $step" }.joinToString("\n")
                } catch (e: Exception) { e.message ?: "Não consegui criar o plano agora. Nenhuma etapa foi salva." }
                runOnUiThread {
                    talkButton.isEnabled = true
                    conversationHistory.add("user" to words); conversationHistory.add("assistant" to result)
                    while (conversationHistory.size > 12) conversationHistory.removeAt(0)
                    status.text = result; speak(result)
                }
            }
            return
        }
        if (requestsExternalAction(words)) {
            val reply = "Essa solicitação pode alterar algo fora da Gabi. Por segurança, nenhuma ação foi executada. Esta versão ainda não tem integração conectada para agir diretamente em outros aplicativos ou serviços. Posso ajudar a preparar os passos ou o conteúdo, e qualquer futura execução precisará da sua confirmação explícita para aquela ação."
            status.text = reply
            speak(reply)
            return
        }
        if (replyEngine.isMemoryCommand(words)) {
            val reply = replyEngine.respond(words)
            status.text = reply
            speak(reply)
            return
        }
        if (!aiClient.hasApiKey()) {
            val reply = replyEngine.respond(words)
            status.text = "$reply Configure a chave da API Gemini para ativar a conversa inteligente completa."
            speak(status.text.toString())
            return
        }
        status.text = "Gabi está pensando…"
        talkButton.isEnabled = false
        networkExecutor.execute {
            val reply = try {
                aiClient.ask(autonomy.planningPrompt(words), AegisMemory(applicationContext).all(), conversationHistory.toList())
            } catch (e: Exception) {
                e.message ?: "Não consegui acessar a IA agora. Verifique a internet e tente novamente."
            }
            runOnUiThread {
                talkButton.isEnabled = true
                conversationHistory.add("user" to words)
                conversationHistory.add("assistant" to reply)
                while (conversationHistory.size > 12) conversationHistory.removeAt(0)
                status.text = reply
                speak(reply)
            }
        }
    }


    private fun handleRoutineCommand(input: String): String? {
        val text = input.trim()
        val lower = text.lowercase(Locale.ROOT)
        if (listOf("ativar rotina diária", "ativar rotina diaria", "ativar rotinas pessoais", "ligar rotina diária", "ligar rotina diaria").any { lower == it }) {
            if (routineManager.isEnabled()) return "As rotinas pessoais já estão ativadas. A revisão diária está programada para aproximadamente 9h."
            if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 47)
                return "O Android precisa da permissão de notificações. Autorize quando aparecer a solicitação para ativar as rotinas pessoais."
            }
            activatePersonalRoutines()
            return "Rotinas pessoais ativadas. A Gabi vai preparar uma revisão local dos objetivos e da agenda por volta das 9h diariamente."
        }
        if (listOf("desativar rotina diária", "desativar rotina diaria", "desativar rotinas pessoais", "desligar rotina diária", "desligar rotina diaria").any { lower == it }) {
            routineManager.disable()
            if (::routineButton.isInitialized) routineButton.text = "ATIVAR ROTINAS PESSOAIS"
            return "Rotinas pessoais desativadas. Nenhuma nova revisão diária será agendada."
        }
        if (listOf("agenda do dia", "preparar agenda do dia", "revisar objetivos", "revisão diária", "revisao diaria", "minha rotina diária", "minha rotina diaria").any { lower == it }) {
            val goals = autonomy.getGoals()
            val taskList = autonomy.listTasks()
            val priorities = autonomy.prioritizeTasks()
            return buildString {
                append("Revisão de hoje\n\n")
                append(if (goals.isEmpty()) "Objetivos: nenhum registrado." else "Objetivos: " + goals.take(5).joinToString("; "))
                append("\n\n").append(taskList)
                append("\n\n").append(priorities)
                if (!routineManager.isEnabled()) append("\n\nA revisão diária automática está desligada. Diga ‘ativar rotina diária’ para receber uma notificação por volta das 9h.")
            }
        }
        if (listOf("status das rotinas", "rotinas pessoais", "minhas rotinas").any { lower == it }) {
            return if (routineManager.isEnabled()) "As rotinas pessoais estão ativas. A Gabi prepara a revisão diária por volta das 9h, sujeita aos limites de execução em segundo plano do Android." else "As rotinas pessoais estão desligadas. Você pode ativá-las pelo botão na tela principal ou dizendo ‘ativar rotina diária’."
        }
        return null
    }

    private fun handleReminderCommand(input: String): String? {
        val text = input.trim()
        val lower = text.lowercase(Locale.ROOT)
        if (listOf("listar lembretes", "meus lembretes", "lembretes pendentes", "quais são meus lembretes", "quais sao meus lembretes").any { lower.contains(it) }) {
            return reminderManager.listReminders()
        }
        val cancelMatch = Regex("(?i)^cancelar lembrete\\s+([a-z0-9-]+)\\s*$").find(text)
        if (cancelMatch != null) return reminderManager.cancelReminder(cancelMatch.groupValues[1])
        val match = Regex("(?i)^(?:gabi[, ]+)?(?:me lembre de|lembre-me de|crie um lembrete para|crie um lembrete:)\\s*(.+?)\\s+em\\s+(\\d{1,4})\\s*(minutos?|mins?|horas?|hrs?)\\s*[.!]?$", RegexOption.IGNORE_CASE).find(text)
        if (match != null) {
            if (!reminderManager.isEnabled()) return "Os lembretes estão desligados. Ative 'LEMBRETES E NOTIFICAÇÕES' na tela principal primeiro."
            val title = match.groupValues[1].trim().trimEnd('.', '!')
            val amount = match.groupValues[2].toLongOrNull() ?: return "Não consegui entender o tempo do lembrete."
            val unit = match.groupValues[3].lowercase(Locale.ROOT)
            val minutes = if (unit.startsWith("h")) amount * 60 else amount
            if (title.isBlank()) return "Diga o que devo lembrar. Exemplo: me lembre de estudar em 10 minutos."
            if (minutes !in 1..10080) return "Escolha um lembrete entre 1 minuto e 7 dias."
            return reminderManager.scheduleReminder(title, minutes)
        }
        if (lower.startsWith("me lembre de ") || lower.startsWith("lembre-me de ") || lower.startsWith("crie um lembrete")) {
            return "Posso criar lembretes relativos. Exemplo: 'me lembre de estudar em 10 minutos' ou 'crie um lembrete para beber água em 2 horas'. Ative os lembretes na tela principal antes."
        }
        return null
    }

    private fun showAppControlOptions() {
        val enabled = GabiAccessibilityService.isEnabled(this)
        val message = if (enabled) {
            """O controle opcional esta habilitado pelo Android. A Gabi so executa as acoes simples reconhecidas depois de voce confirmar cada uma. Ela nao executa acoes em segundo plano por conta propria.

Comandos: voltar, tela inicial, rolar para baixo, rolar para cima e toque em [texto exato]."""
        } else {
            """Este recurso e opcional e vem desligado. Para permitir acoes simples em outros aplicativos, o Android exige que voce habilite manualmente o Servico de Acessibilidade da Gabi.

A permissao pode permitir que o servico leia textos visiveis e interaja com elementos da tela. Ative somente se confiar no aplicativo. Mesmo habilitado, a Gabi pedira confirmacao antes de cada acao reconhecida."""
        }
        AlertDialog.Builder(this)
            .setTitle(if (enabled) "Controle de aplicativos ativo" else "Ativar controle opcional")
            .setMessage(message)
            .setPositiveButton(if (enabled) "Entendi" else "Abrir permissoes do Android") { _, _ ->
                if (!enabled) {
                    startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }
            .setNeutralButton("Desativar instrucoes") { _, _ ->
                Toast.makeText(this, "Para desligar o acesso, desative Gabi I.A. nas configuracoes de Acessibilidade do Android.", Toast.LENGTH_LONG).show()
                startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun normalizeAccessibilityCommand(text: String): String? {
        val lower = text.trim().lowercase(Locale.ROOT)
        return when {
            lower in listOf("gabi, voltar", "gabi voltar", "voltar", "pressionar voltar", "volte") -> "voltar"
            lower in listOf("gabi, tela inicial", "gabi tela inicial", "ir para a tela inicial", "tela inicial") -> "tela inicial"
            lower in listOf("rolar para baixo", "descer a tela", "gabi, rolar para baixo") -> "rolar para baixo"
            lower in listOf("rolar para cima", "subir a tela", "gabi, rolar para cima") -> "rolar para cima"
            lower.startsWith("toque em ") -> "toque em " + text.trim().substringAfter("toque em ", "")
            lower.startsWith("clicar em ") -> "clicar em " + text.trim().substringAfter("clicar em ", "")
            else -> null
        }
    }

    private fun confirmAndRunAppControl(command: String) {
        if (!GabiAccessibilityService.isEnabled(this)) {
            AlertDialog.Builder(this)
                .setTitle("Controle de aplicativos desligado")
                .setMessage("Voce pediu: \"$command\". Para usar esse recurso, habilite a integracao opcional nas configuracoes de Acessibilidade do Android. Nenhuma acao foi executada.")
                .setPositiveButton("Configurar") { _, _ -> startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                .setNegativeButton("Cancelar", null)
                .show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Confirmar acao fora da Gabi")
            .setMessage("""A Gabi esta prestes a executar esta acao na tela atual:

$command

Confirme apenas se a tela e a acao estiverem corretas. Tocar em um item pode enviar, excluir ou confirmar algo dependendo do aplicativo aberto.""")
            .setPositiveButton("Confirmar e executar") { _, _ ->
                val result = GabiAccessibilityService.runApproved(command)
                val message = result ?: "O servico de acessibilidade nao esta disponivel. Nenhuma acao foi executada."
                status.text = message
                speak(message)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun requestsExternalAction(text: String): Boolean {
        val lower = text.lowercase(Locale.ROOT)
        val actionPhrases = listOf(
            "envie a mensagem", "envia a mensagem", "mande a mensagem", "manda a mensagem",
            "envie um email", "envie um e-mail", "mande um email", "mande um e-mail",
            "publique isso", "publica isso", "poste isso", "posta isso", "compre isso", "faça a compra", "faca a compra",
            "transfira o dinheiro", "faça a transferência", "faca a transferencia", "apague o arquivo", "delete o arquivo",
            "instale o aplicativo", "desinstale o aplicativo", "ligue para", "faça login", "faca login", "acesse minha conta"
        )
        return actionPhrases.any { lower.contains(it) }
    }

    private fun extractPlanGoal(text: String): String? {
        val lower = text.lowercase().trim()
        val prefixes = listOf("crie um plano para", "cria um plano para", "monte um plano para", "monta um plano para", "planeje como alcançar", "planeje como alcancar", "quero um plano para", "organize um plano para")
        val prefix = prefixes.firstOrNull { lower.startsWith(it) } ?: return null
        return text.trim().drop(prefix.length).trim().trimEnd('.', '!', '?', ' ').takeIf { it.isNotBlank() }
    }

    private fun showAiConfiguration() {
        val input = EditText(this).apply {
            hint = "Chave da API Gemini (AIzaSy…)"
            singleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(aiClient.getApiKey().orEmpty())
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 12, 40, 0)
            addView(input, LinearLayout.LayoutParams(-1, -2))
            addView(TextView(this@MainActivity).apply {
                text = "A chave Gemini fica salva neste aparelho e é enviada ao serviço do Google para gerar respostas. Consulte os limites e as condições atuais do Gemini API. Para distribuir o aplicativo a outras pessoas, use um servidor próprio para não expor a chave no APK."
                textSize = 12f
                setPadding(0, 12, 0, 0)
            })
        }
        AlertDialog.Builder(this)
            .setTitle("Configurar IA Gemini")
            .setView(layout)
            .setPositiveButton("Salvar chave") { _, _ ->
                val key = input.text.toString().trim()
                if (key.isBlank()) {
                    Toast.makeText(this, "Informe uma chave de API válida.", Toast.LENGTH_LONG).show()
                } else {
                    aiClient.saveApiKey(key)
                    status.text = "Gemini configurado. Agora você pode conversar com a Gabi."
                    Toast.makeText(this, "Chave Gemini salva neste aparelho.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNeutralButton("Apagar chave") { _, _ ->
                aiClient.clearApiKey()
                status.text = "Chave de IA apagada. A Gabi usará respostas locais."
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun speak(text: String) { if (readyToSpeak) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "gabi_reply") }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if ((requestCode == 42 || requestCode == 43 || requestCode == 44 || requestCode == 45 || requestCode == 46 || requestCode == 47) && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            when (requestCode) {
                42 -> startListening()
                45 -> activateInitiativeMode()
                46 -> activateReminders()
                47 -> activatePersonalRoutines()
                else -> toggleWakeListening()
            }
        } else if (requestCode == 42 || requestCode == 43) Toast.makeText(this, "Permita o microfone para usar a voz da Gabi.", Toast.LENGTH_LONG).show()
        else if (requestCode == 44 || requestCode == 45 || requestCode == 46 || requestCode == 47) Toast.makeText(this, "Sem permissão de notificações, os avisos da Gabi podem não aparecer.", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        networkExecutor.shutdownNow()
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }

    private class OrbView(context: android.content.Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var phase = 0f
        private val cyan = android.graphics.Color.rgb(70, 225, 255)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f; val cy = height / 2f
            val radius = (width.coerceAtMost(height) * 0.29f).coerceAtLeast(60f)
            phase += 0.025f
            paint.shader = RadialGradient(cx, cy, radius * 1.55f, intArrayOf(0x5538dfff, 0x22228cff, 0x00000000), null, Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, radius * 1.55f, paint)
            paint.shader = RadialGradient(cx - radius * .25f, cy - radius * .3f, radius * 1.3f, intArrayOf(0xffb5f7ff.toInt(), 0xff28bce9.toInt(), 0xff07508e.toInt(), 0xff03152e.toInt()), floatArrayOf(0f, .25f, .68f, 1f), Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, radius * (1f + 0.018f * sin(phase.toDouble()).toFloat()), paint)
            paint.shader = null; paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f; paint.color = cyan
            canvas.drawCircle(cx, cy, radius * 1.18f, paint)
            paint.strokeWidth = 1f; paint.alpha = 150
            canvas.save(); canvas.rotate(phase * 35f, cx, cy); canvas.drawOval(cx-radius*1.42f, cy-radius*.38f, cx+radius*1.42f, cy+radius*.38f, paint); canvas.restore()
            paint.style = Paint.Style.FILL; paint.alpha = 255
            postInvalidateDelayed(40)
        }
    }
}
