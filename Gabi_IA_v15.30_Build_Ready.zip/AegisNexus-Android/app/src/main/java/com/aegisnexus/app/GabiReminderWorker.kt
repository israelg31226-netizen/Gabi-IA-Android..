package com.aegisnexus.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters

/** Dispara a notificação local do lembrete. O Android pode atrasar trabalhos em segundo plano. */
class GabiReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val id = inputData.getString(KEY_ID).orEmpty()
        val title = inputData.getString(KEY_TITLE).orEmpty()
        if (id.isBlank() || title.isBlank()) return Result.failure()
        val prefs = applicationContext.getSharedPreferences(GabiReminderManager.PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(GabiReminderManager.KEY_ENABLED, false)) return Result.success()
        return try {
            val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Lembretes da Gabi", NotificationManager.IMPORTANCE_HIGH))
            }
            val openApp = Intent(applicationContext, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pending = PendingIntent.getActivity(applicationContext, id.hashCode(), openApp,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("Gabi I.A. — Lembrete")
                .setContentText(title)
                .setStyle(NotificationCompat.BigTextStyle().bigText(title))
                .setContentIntent(pending)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build()
            manager.notify(id.hashCode(), notification)
            GabiReminderManager(applicationContext).markTriggered(id)
            Result.success()
        } catch (_: SecurityException) {
            // A permissão pode ter sido revogada depois do agendamento.
            Result.failure()
        } catch (_: Exception) {
            Result.retry()
        }
    }

    companion object {
        const val KEY_ID = "reminder_id"
        const val KEY_TITLE = "reminder_title"
        private const val CHANNEL_ID = "gabi_reminders"
    }
}
