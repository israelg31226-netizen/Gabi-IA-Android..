package com.aegisnexus.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Sistema de evolução local da Gabi I.A.
 * Ela observa resultados, extrai lições, ajusta prioridades e muda o próprio comportamento
 * ao longo do tempo — sem internet e sem reescrever o APK.
 *
 * Limite honesto: evolução estruturada sobre dados locais, não auto-modificação de código.
 */
class GabiEvolution(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    data class Lesson(
        val id: String,
        val category: String,   // SUCCESS | FAILURE | PREFERENCE | PATTERN | ADJUSTMENT
        val content: String,
        val weight: Int,        // 1-5 relevância
        val createdAt: Long,
        val source: String
    )

    fun generation(): Int = prefs.getInt(KEY_GENERATION, 1)

    fun allLessons(): List<Lesson> {
        val arr = JSONArray(prefs.getString(KEY_LESSONS, "[]") ?: "[]")
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            Lesson(
                id = o.optString("id"),
                category = o.optString("category", "PATTERN"),
                content = o.optString("content"),
                weight = o.optInt("weight", 2),
                createdAt = o.optLong("at", 0L),
                source = o.optString("source", "local")
            )
        }.sortedByDescending { it.createdAt }
    }

    fun addLesson(category: String, content: String, weight: Int, source: String): Lesson {
        val clean = content.trim().take(400)
        // Evita lições quase idênticas
        val existing = allLessons()
        if (existing.any { similar(it.content, clean) }) {
            return existing.first { similar(it.content, clean) }
        }
        val lesson = Lesson(
            id = UUID.randomUUID().toString().take(8),
            category = category.uppercase(Locale.ROOT),
            content = clean,
            weight = weight.coerceIn(1, 5),
            createdAt = System.currentTimeMillis(),
            source = source
        )
        val list = existing.toMutableList()
        list.add(0, lesson)
        saveLessons(list.take(60))
        return lesson
    }

    fun clearEvolution() {
        prefs.edit()
            .remove(KEY_LESSONS)
            .putInt(KEY_GENERATION, 1)
            .remove(KEY_STATS)
            .remove(KEY_LAST_EVOLVE)
            .apply()
    }

    fun stats(): JSONObject {
        val raw = prefs.getString(KEY_STATS, null)
        return if (raw.isNullOrBlank()) JSONObject() else try { JSONObject(raw) } catch (_: Exception) { JSONObject() }
    }

    private fun bumpStat(key: String, delta: Int = 1) {
        val s = stats()
        s.put(key, s.optInt(key, 0) + delta)
        prefs.edit().putString(KEY_STATS, s.toString()).apply()
    }

    /**
     * Ciclo de evolução: lê o estado da autonomia + pensamentos e extrai lições.
     * Pode ser chamado offline. Incrementa a "geração" quando há aprendizado novo.
     */
    fun evolve(autonomy: AegisAutonomy, brain: GabiBrain, force: Boolean = false): String {
        val last = prefs.getLong(KEY_LAST_EVOLVE, 0L)
        val now = System.currentTimeMillis()
        // No máximo uma evolução automática a cada ~45 min, salvo force
        if (!force && last > 0 && now - last < 45L * 60L * 1000L) {
            return "Evolução recente já registrada. Geração atual: ${generation()}."
        }

        val beforeCount = allLessons().size
        val cycle = autonomy.runWorkCycle()
        val goals = autonomy.getGoals()
        val thoughts = brain.recentThoughts(8)
        val newLessons = mutableListOf<Lesson>()

        // --- Extrai padrões do ciclo de trabalho ---
        val pending = Regex("(\\d+) tarefa\\(s\\) pendente").find(cycle)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val blockers = Regex("(\\d+) bloqueio\\(s\\) ativo").find(cycle)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val hasFailed = cycle.contains("falharam", ignoreCase = true)
        val hasAwaiting = cycle.contains("aguardando sua verificação", ignoreCase = true)

        if (hasFailed) {
            newLessons += addLesson(
                "FAILURE",
                "Tentativas que falharam devem gerar mudança de abordagem antes de repetir a mesma ação.",
                5,
                "work_cycle"
            )
            bumpStat("failures_observed")
        }
        if (blockers > 0) {
            newLessons += addLesson(
                "PATTERN",
                "Bloqueios ativos reduzem o valor de abrir novas tarefas até haver alternativa ou resolução.",
                4,
                "work_cycle"
            )
            bumpStat("blockers_observed")
        }
        if (goals.isNotEmpty() && pending == 0) {
            newLessons += addLesson(
                "PATTERN",
                "Objetivo sem tarefas pendentes precisa de decomposição em etapas verificáveis.",
                4,
                "work_cycle"
            )
        }
        if (pending >= 6) {
            newLessons += addLesson(
                "ADJUSTMENT",
                "Com muitas pendências, priorizar uma única frente evita dispersão.",
                3,
                "work_cycle"
            )
        }
        if (hasAwaiting) {
            newLessons += addLesson(
                "PREFERENCE",
                "Ações abertas sem verificação do usuário não devem ser tratadas como sucesso.",
                5,
                "work_cycle"
            )
        }

        // --- Aprende com pensamentos recentes de alta prioridade ---
        thoughts.filter { it.priority >= 4 && it.shareWithUser }.take(3).forEach { t ->
            if (t.type == "WARNING") {
                newLessons += addLesson(
                    "PATTERN",
                    "Alertas de alta prioridade merecem atenção antes de novas iniciativas.",
                    3,
                    "thought:${t.id}"
                )
            }
        }

        // --- Preferências de ritmo ---
        val s = stats()
        val shares = s.optInt("thoughts_shared", 0)
        val offlineRuns = s.optInt("offline_cycles", 0)
        if (shares >= 5 && offlineRuns >= 3) {
            newLessons += addLesson(
                "ADJUSTMENT",
                "O usuário tolera iniciativas proativas; manter o cérebro ativo é útil.",
                2,
                "stats"
            )
        }

        // Contabiliza ciclo
        bumpStat("evolve_cycles")
        if (thoughts.any { it.offline }) bumpStat("offline_cycles")
        thoughts.count { it.shareWithUser }.let { if (it > 0) bumpStat("thoughts_shared", it.coerceAtMost(2)) }

        val afterCount = allLessons().size
        val learned = afterCount > beforeCount
        if (learned || force) {
            val gen = generation() + 1
            prefs.edit().putInt(KEY_GENERATION, gen).putLong(KEY_LAST_EVOLVE, now).apply()
            val latest = allLessons().take(3).joinToString(" ") { "• ${it.content}" }
            return buildString {
                append("Evolução concluída. Geração ${gen}.")
                if (learned) append(" Novas lições incorporadas.")
                else append(" Consolidação sem lição inédita.")
                if (latest.isNotBlank()) append("\nLições recentes:\n$latest")
            }
        }
        prefs.edit().putLong(KEY_LAST_EVOLVE, now).apply()
        return "Ciclo de evolução executado. Nenhuma lição inédita desta vez. Geração ${generation()}."
    }

    /** Texto injetado nos prompts e no cérebro offline para influenciar o comportamento. */
    fun contextForCognition(): String {
        val lessons = allLessons().take(8)
        val s = stats()
        val gen = generation()
        if (lessons.isEmpty() && gen <= 1) {
            return "EVOLUÇÃO: geração 1. Ainda sem lições acumuladas."
        }
        val lines = lessons.joinToString("\n") { l ->
            "- [${l.category}·p${l.weight}] ${l.content}"
        }
        return buildString {
            append("EVOLUÇÃO DA GABI (geração $gen):\n")
            append("Estatísticas: ciclos=${s.optInt("evolve_cycles")}, falhas observadas=${s.optInt("failures_observed")}, ")
            append("bloqueios observados=${s.optInt("blockers_observed")}, pensamentos compartilhados=${s.optInt("thoughts_shared")}.\n")
            append("Lições ativas (influenciam prioridades e tom):\n")
            append(if (lines.isBlank()) "- Nenhuma ainda." else lines)
            append("\nAplique essas lições: não repita abordagens que falharam, respeite bloqueios, priorize o próximo passo verificável.")
        }
    }

    fun reportForUser(): String {
        val gen = generation()
        val lessons = allLessons().take(10)
        val s = stats()
        if (lessons.isEmpty() && gen <= 1) {
            return "Ainda estou na geração 1, Senhor. À medida que registrarmos resultados, bloqueios e conclusões, vou extrair lições e ajustar meu comportamento."
        }
        val whenStr = prefs.getLong(KEY_LAST_EVOLVE, 0L).let {
            if (it == 0L) "nunca" else SimpleDateFormat("dd/MM HH:mm", Locale("pt", "BR")).format(Date(it))
        }
        return buildString {
            append("Relatório de evolução — Gabi I.A.\n")
            append("Geração: $gen\n")
            append("Última evolução: $whenStr\n")
            append("Ciclos de evolução: ${s.optInt("evolve_cycles")}\n")
            append("Falhas observadas: ${s.optInt("failures_observed")} · Bloqueios: ${s.optInt("blockers_observed")}\n")
            append("Pensamentos compartilhados: ${s.optInt("thoughts_shared")}\n\n")
            append("Lições incorporadas:\n")
            if (lessons.isEmpty()) append("• Nenhuma ainda.")
            else lessons.forEach { l ->
                val tag = when (l.category) {
                    "SUCCESS" -> "Sucesso"
                    "FAILURE" -> "Falha"
                    "PREFERENCE" -> "Preferência"
                    "ADJUSTMENT" -> "Ajuste"
                    else -> "Padrão"
                }
                append("• [$tag] ${l.content}\n")
            }
            append("\nEssas lições alteram como eu priorizo pensamentos e sugestões — sem reescrever meu código.")
        }
    }

    fun handleEvolutionCommand(input: String): String? {
        val lower = input.trim().lowercase(Locale.ROOT)
        return when {
            listOf(
                "como você evoluiu", "como voce evoluiu", "sua evolução", "sua evolucao",
                "o que você aprendeu", "o que voce aprendeu", "mostrar evolução", "mostrar evolucao",
                "relatório de evolução", "relatorio de evolucao", "geração atual", "geracao atual"
            ).any { lower.contains(it) } -> reportForUser()

            listOf(
                "evolua agora", "evoluir agora", "force a evolução", "forçar evolução",
                "forcar evolucao", "rode a evolução", "rode a evolucao"
            ).any { lower.contains(it) } -> null // tratado no MainActivity com autonomia+brain

            listOf(
                "resetar evolução", "resetar evolucao", "apague a evolução", "apague a evolucao",
                "limpar evolução", "limpar evolucao", "recomeçar evolução", "recomecar evolucao"
            ).any { lower.contains(it) } -> {
                clearEvolution()
                "Evolução reiniciada. Voltei à geração 1, Senhor. As lições anteriores foram descartadas."
            }

            else -> null
        }
    }

    private fun similar(a: String, b: String): Boolean {
        val na = a.lowercase(Locale.ROOT).take(70)
        val nb = b.lowercase(Locale.ROOT).take(70)
        return na == nb || (na.length > 25 && nb.contains(na.take(35)))
    }

    private fun saveLessons(list: List<Lesson>) {
        val arr = JSONArray()
        list.forEach { l ->
            arr.put(
                JSONObject()
                    .put("id", l.id)
                    .put("category", l.category)
                    .put("content", l.content)
                    .put("weight", l.weight)
                    .put("at", l.createdAt)
                    .put("source", l.source)
            )
        }
        prefs.edit().putString(KEY_LESSONS, arr.toString()).apply()
    }

    companion object {
        private const val PREFS = "gabi_evolution"
        private const val KEY_LESSONS = "lessons"
        private const val KEY_GENERATION = "generation"
        private const val KEY_STATS = "stats"
        private const val KEY_LAST_EVOLVE = "last_evolve_at"
    }
}
