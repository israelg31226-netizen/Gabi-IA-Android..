package com.aegisnexus.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

/** Protótipo experimental: escuta por sessões de reconhecimento enquanto o serviço está ativo. */
class WakeWordService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private var stopping = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val openApp = PendingIntent.getActivity(this, 10, Intent(this, MainActivity::class.java).putExtra(EXTRA_WAKE, true).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification: Notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Gabi I.A. — Escuta ativa")
            .setContentText("Diga: Hey Gabi")
            .setContentIntent(openApp)
            .setOngoing(true)
            .build()
        startForeground(NOTIFICATION_ID, notification)
        listenAgain(500L)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Escuta do Gabi I.A.", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun listenAgain(delay: Long) {
        if (stopping) return
        android.os.Handler(mainLooper).postDelayed({
            if (stopping) return@postDelayed
            if (!SpeechRecognizer.isRecognitionAvailable(this)) { stopSelf(); return@postDelayed }
            try {
                recognizer?.destroy()
                recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
                    sr.setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {}
                        override fun onBeginningOfSpeech() {}
                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}
                        override fun onEndOfSpeech() {}
                        override fun onError(error: Int) { listenAgain(700L) }
                        override fun onResults(results: Bundle?) {
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                            val phrase = matches.firstOrNull().orEmpty().lowercase(Locale("pt", "BR"))
                                .replace(Regex("[^a-záàâãéêíóôõúç ]"), " ").replace(Regex("\\s+"), " ").trim()
                            val wake = phrase.contains("hey gabi") || phrase.contains("ei gabi") || phrase == "gabi" || phrase.startsWith("hey gabi") || phrase.startsWith("oi gabi")
                            if (wake) {
                                val open = Intent(this@WakeWordService, MainActivity::class.java).putExtra(EXTRA_WAKE, true)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                                val pending = PendingIntent.getActivity(this@WakeWordService, 11, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                                val manager = getSystemService(NotificationManager::class.java)
                                manager.notify(NOTIFICATION_ID + 1, Notification.Builder(this@WakeWordService, CHANNEL_ID)
                                    .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("Nexus foi chamado")
                                    .setContentText("Toque para conversar com a Aegis.").setContentIntent(pending).setAutoCancel(true).build())
                                stopping = true
                                recognizer?.destroy()
                                stopForeground(STOP_FOREGROUND_REMOVE)
                                stopSelf()
                            } else {
                                listenAgain(350L)
                            }
                        }
                        override fun onPartialResults(partialResults: Bundle?) {}
                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-BR")
                        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                    }
                    sr.startListening(intent)
                }
            } catch (_: Exception) { listenAgain(1500L) }
        }, delay)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopping = true; recognizer?.destroy(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
        return START_STICKY
    }

    override fun onDestroy() { stopping = true; recognizer?.destroy(); recognizer = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val EXTRA_WAKE = "aegis_wake_detected"
        const val ACTION_STOP = "com.aegisnexus.app.STOP_WAKE"
        private const val CHANNEL_ID = "aegis_wake_channel"
        private const val NOTIFICATION_ID = 6701
    }
}
