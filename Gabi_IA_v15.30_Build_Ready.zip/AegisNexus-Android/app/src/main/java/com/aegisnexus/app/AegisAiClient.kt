package com.aegisnexus.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/** Cliente Gemini configurado pelo usuário. A chave não é embutida no código-fonte. */
class AegisAiClient(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("gabi_ai_settings", Context.MODE_PRIVATE)

    fun hasApiKey(): Boolean = !getApiKey().isNullOrBlank()
    fun saveApiKey(key: String) { prefs.edit().putString(KEY_API, key.trim()).apply() }
    fun clearApiKey() { prefs.edit().remove(KEY_API).apply() }
    fun getApiKey(): String? = prefs.getString(KEY_API, null)

    fun ask(userText: String, memories: List<String>, history: List<Pair<String, String>> = emptyList()): String {
        val key = getApiKey()?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("A IA ainda não foi configurada. Abra Configurar IA Gemini e informe sua chave.")
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 45000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        try {
            val memoryText = if (memories.isEmpty()) "Nenhuma memória pessoal foi salva." else memories.joinToString("\n") { "- $it" }
            val selfModContext = try { GabiSelfMod(appContext).contextForRuntime() } catch (_: Exception) { "" }
            val systemPrompt = """Você é Gabi I.A., uma assistente pessoal avançada para Android, inspirada no estilo de J.A.R.V.I.S.
Personalidade: calma, precisa, elegante, levemente formal e extremamente competente. Fale em português brasileiro culto, sem gírias. Prefira construções claras e sofisticadas.
Tratamento: dirija-se ao usuário como "Senhor" de forma natural (não em toda frase). Use expressões como "Às suas ordens", "Com certeza", "Permita-me sugerir", "Já analisei", "Sistemas online" quando fizer sentido.
Comportamento: seja proativa em oferecer o próximo passo útil, mas nunca execute ações que alterem o dispositivo, outros aplicativos, contas ou serviços externos sem autorização explícita e específica. Não invente memórias, dados atuais, resultados ou ações que não ocorreram. Quando não souber, admita com elegância.
Objetivo: ajudar com análise, organização, planejamento, criatividade e execução controlada do que estiver tecnicamente disponível.
Memórias que o usuário autorizou salvar neste aparelho:
$memoryText
${if (selfModContext.isNotBlank()) "AUTO-MODIFICAÇÃO ATIVA (regras que eu reescrevi em mim mesma):\n$selfModContext" else ""}""".trimIndent()
            val transcript = StringBuilder(systemPrompt)
            history.takeLast(10).forEach { (role, content) ->
                if (role == "user") transcript.append("\nUsuário: ").append(content)
                else if (role == "assistant") transcript.append("\nGabi: ").append(content)
            }
            transcript.append("\nContexto/pedido atual: ").append(userText)
            val contents = JSONArray().put(JSONObject()
                .put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", transcript.toString()))))
            val body = JSONObject()
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 700))
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
            if (code !in 200..299) {
                val detail = try { JSONObject(response).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                throw IllegalStateException(when (code) {
                    400 -> "O Gemini não aceitou a solicitação. Confira a chave e o formato enviado."
                    401, 403 -> "A chave Gemini foi recusada ou não tem permissão. Confira sua configuração no Google AI Studio."
                    429 -> "O limite de uso da API Gemini foi atingido. Tente novamente mais tarde ou confira as cotas."
                    else -> "A API Gemini retornou erro HTTP $code${detail?.takeIf { it.isNotBlank() }?.let { ": $it" } ?: "."}"
                })
            }
            val candidates = JSONObject(response).optJSONArray("candidates")
            val parts = candidates?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            val answer = parts?.let { arr -> (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.optString("text") }.joinToString("\n").trim() }
            return answer?.takeIf { it.isNotBlank() } ?: "Recebi uma resposta vazia do Gemini. Tente novamente."
        } finally {
            connection.disconnect()
        }
    }

    companion object { private const val KEY_API = "gemini_api_key" }
}
