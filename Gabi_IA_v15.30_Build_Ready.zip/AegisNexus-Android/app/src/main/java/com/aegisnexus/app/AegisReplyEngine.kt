package com.aegisnexus.app

import android.content.Context

/** Liga comandos de memória à personalidade sem alterar a interface original. */
class AegisReplyEngine(context: Context) {
    private val memory = AegisMemory(context.applicationContext)

    fun isMemoryCommand(input: String): Boolean {
        val lower = input.trim().lowercase()
        return listOf("lembre que", "lembre de", "guarde que", "guarde isto:", "memorize que").any { lower.startsWith(it) } ||
            lower.contains("o que você lembra") || lower.contains("o que voce lembra") ||
            lower.contains("listar minhas memórias") || lower.contains("listar minhas memorias") ||
            lower.contains("esqueça todas as memórias") || lower.contains("esqueca todas as memorias") ||
            lower.contains("apague minhas memórias") || lower.contains("apague minhas memorias")
    }

    fun respond(input: String): String {
        val text = input.trim()
        val lower = text.lowercase()
        val prefix = listOf("lembre que", "lembre de", "guarde que", "guarde isto:", "memorize que")
            .firstOrNull { lower.startsWith(it) }
        if (prefix != null) {
            val note = text.drop(prefix.length).trim().trimStart(':', ',', ' ')
            return if (note.isBlank()) "Diga ‘lembre que’ seguido da informação que deseja guardar." else {
                memory.remember(note)
                "Informação guardada neste aparelho. Você pode pedir para eu listar ou apagar as memórias quando quiser."
            }
        }
        if (lower.contains("o que você lembra") || lower.contains("o que voce lembra") || lower.contains("listar minhas memórias") || lower.contains("listar minhas memorias")) {
            val items = memory.all()
            return if (items.isEmpty()) "Ainda não há memórias pessoais guardadas. Você pode dizer ‘lembre que…’ para salvar uma informação neste aparelho."
            else "Estas são as informações que você pediu para guardar: " + items.mapIndexed { index, item -> "${index + 1}. $item" }.joinToString(". ")
        }
        if (lower.contains("esqueça todas as memórias") || lower.contains("esqueca todas as memorias") || lower.contains("apague minhas memórias") || lower.contains("apague minhas memorias")) {
            memory.clear()
            return "As memórias pessoais guardadas localmente foram apagadas."
        }
        return AegisPersonality.reply(text, memory.all())
    }
}
