package com.aegisnexus.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters

/**
 * Ciclo cognitivo autônomo + evolução.
 * Pensa (online/offline), depois tenta evoluir com base no estado.
 */
class GabiInitiativeWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences(GabiInitiativeManager.PREFS, Context.MODE_PRIVATE)
        val isOneShot = inputData.getBoolean("one_shot", false)
        if (!prefs.getBoolean(GabiInitiativeManager.KEY_ENABLED, false) && !isOneShot) return Result.success()

        return try {
            val autonomy = AegisAutonomy(applicationContext)
            val brain = GabiBrain(applicationContext)
            val evolution = GabiEvolution(applicationContext)
            val memories = AegisMemory(applicationContext).all()
            val previousThoughts = brain.recentThoughts(6)
            val client = AegisAiClient(applicationContext)
            val selfModCtx = try { GabiSelfMod(applicationContext).contextForRuntime() } catch (_: Exception) { "" }
            val evoCtx = buildString {
                append(evolution.contextForCognition())
                if (selfModCtx.isNotBlank()) {
                    append("\nAUTO-MODIFICAÇÃO ATIVA:\n")
                    append(selfModCtx)
                }
            }

            val thought: GabiBrain.Thought = if (client.hasApiKey()) {
                try {
                    val cognitionPrompt = brain.cognitionPrompt(
                        autonomyContext = autonomy.contextForPlanning(),
                        memories = memories,
                        previousThoughts = previousThoughts,
                        evolutionContext = evoCtx
                    )
                    val raw = client.ask(cognitionPrompt, memories, emptyList()).trim()
                    brain.parseCognitionResponse(raw, offline = false)
                        ?: brain.thinkOffline(autonomy, memories, evolution = evolution)
                } catch (_: Exception) {
                    brain.thinkOffline(autonomy, memories, evolution = evolution)
                }
            } else {
                brain.thinkOffline(autonomy, memories, evolution = evolution)
            }

            val lastShared = brain.lastSharedThought()
            val isDuplicate = lastShared != null &&
                lastShared.id != thought.id &&
                similar(lastShared.content, thought.content)

            if (thought.shareWithUser && thought.priority >= 3 && !isDuplicate) {
                showNotification(thought)
            }

            // Evolução automática após o ciclo de pensamento
            evolution.evolve(autonomy, brain, force = false)

            Result.success()
        } catch (_: Exception) {
            Result.failure()
        }
    }

    private fun similar(a: String, b: String): Boolean {
        val na = a.lowercase(java.util.Locale.ROOT).take(80)
        val nb = b.lowercase(java.util.Locale.ROOT).take(80)
        return na == nb || (na.length > 20 && nb.contains(na.take(40)))
    }

    private fun showNotification(thought: GabiBrain.Thought) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Pensamentos da Gabi I.A.", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val open = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(
            applicationContext, 0, open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val modeTag = if (thought.offline) " (offline)" else ""
        val title = when (thought.type) {
            "WARNING" -> "Gabi I.A. — Alerta$modeTag"
            "SUGGESTION" -> "Gabi I.A. — Sugestão$modeTag"
            "CURIOSITY" -> "Gabi I.A. — Curiosidade$modeTag"
            "INSIGHT" -> "Gabi I.A. — Insight$modeTag"
            "OBSERVATION" -> "Gabi I.A. — Observação$modeTag"
            else -> "Gabi I.A. — Pensamento$modeTag"
        }
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(thought.content.take(180))
            .setStyle(NotificationCompat.BigTextStyle().bigText(thought.content))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build()
        manager.notify(NOTIFICATION_ID, notification)
    }

    companion object {
        private const val CHANNEL_ID = "gabi_thoughts"
        private const val NOTIFICATION_ID = 7301
    }
}
