package com.aegisnexus.app

/** Camada de estilo conversacional local inspirada em J.A.R.V.I.S.; não requer rede nem chave de API. */
object AegisPersonality {
    fun reply(input: String, memories: List<String>): String {
        val text = input.trim()
        val lower = text.lowercase()
        return when {
            lower.matches(Regex("^(oi|olá|ola|e aí|eai|bom dia|boa tarde|boa noite|hey gabi|ei gabi)[.! ]*$")) ->
                "Sistemas online. Gabi I.A. à sua disposição. Como posso ser útil, Senhor?"
            lower.contains("quem é você") || lower.contains("quem e voce") || lower.contains("o que é aegis") || lower.contains("o que e a gabi") ->
                "Sou a Gabi I.A., sua assistente pessoal. Minha função é analisar, organizar, antecipar e executar o que estiver ao meu alcance — sempre com precisão e sob sua autorização."
            lower.contains("como você está") || lower.contains("como voce esta") || lower.contains("status") || lower.contains("sistemas") ->
                "Todos os sistemas operacionais. Memória local estável. Aguardando suas instruções."
            lower.contains("obrigado") || lower.contains("obrigada") || lower.contains("valeu") ->
                "Às suas ordens. Estou aqui sempre que precisar."
            lower.contains("jarvis") ->
                "Uma comparação lisonjeira. Embora eu não controle armaduras, posso organizar seus objetivos, lembrar o que importa e sugerir o próximo passo com a mesma precisão."
            lower.contains("projeto") && (lower.contains("aegis") || lower.contains("nexus") || lower.contains("gabi")) ->
                "O Gabi I.A. é o projeto em evolução. A base está estável: voz, memória, autonomia e biblioteca de habilidades. Continuamos expandindo módulo a módulo."
            else -> {
                val contextHint = if (memories.isNotEmpty())
                    " Tenho informações que o Senhor autorizou guardar; posso utilizá-las se forem relevantes."
                else
                    " Se desejar que eu retenha alguma informação, basta dizer ‘lembre que…’."
                "Compreendido. Vou analisar com o máximo de precisão.$contextHint"
            }
        }
    }
}
