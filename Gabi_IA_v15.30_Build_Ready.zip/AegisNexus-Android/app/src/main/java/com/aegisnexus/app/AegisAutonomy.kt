package com.aegisnexus.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/** Memória de trabalho persistente: objetivos, tarefas, planos por etapas e histórico de tentativas. */
class AegisAutonomy(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("gabi_autonomy", Context.MODE_PRIVATE)

    @Synchronized fun addGoal(goal: String): String {
        val clean = goal.trim().take(240)
        if (clean.isBlank()) return "Diga qual objetivo você quer registrar."
        val goals = getGoals().toMutableList()
        if (goals.none { it.equals(clean, ignoreCase = true) }) goals.add(clean)
        prefs.edit().putString(KEY_GOALS, JSONArray(goals.takeLast(50)).toString()).apply()
        recordEvent("Objetivo registrado", clean)
        return "Objetivo registrado: $clean. Vou manter esse objetivo e relacionar tarefas, planos e tentativas a ele."
    }

    @Synchronized fun getGoals(): List<String> {
        val raw = prefs.getString(KEY_GOALS, "[]") ?: "[]"
        return try { val arr = JSONArray(raw); (0 until arr.length()).mapNotNull { arr.optString(it).takeIf(String::isNotBlank) } } catch (_: Exception) { emptyList() }
    }

    @Synchronized fun clearGoals() { prefs.edit().remove(KEY_GOALS).apply(); recordEvent("Objetivos apagados", "O usuário limpou a lista de objetivos.") }

    @Synchronized fun addTask(title: String, goal: String = ""): String {
        val clean = title.trim().take(240)
        if (clean.isBlank()) return "Diga qual tarefa você quer adicionar."
        val tasks = readObjects(KEY_TASKS)
        if (tasks.any { it.optString("title").equals(clean, true) && it.optString("status") == "pending" }) return "Essa tarefa já está na lista de pendências: $clean"
        tasks.add(JSONObject().put("id", UUID.randomUUID().toString().take(8)).put("title", clean).put("goal", goal.trim().take(240)).put("status", "pending").put("created_at", now()).put("updated_at", now()).put("attempts", JSONArray()))
        saveObjects(KEY_TASKS, tasks.takeLast(100))
        recordEvent("Tarefa adicionada", clean + if (goal.isNotBlank()) " | Objetivo: $goal" else "")
        return "Tarefa adicionada às pendências: $clean${if (goal.isNotBlank()) " (objetivo: $goal)" else ""}. Ainda não foi executada."
    }

    /** Prioriza pendências localmente com critérios transparentes, sem fingir conhecer prazos não informados. */
    @Synchronized fun prioritizeTasks(): String {
        val pending = readObjects(KEY_TASKS).filter { it.optString("status", "pending") == "pending" }
        if (pending.isEmpty()) return "Não há tarefas pendentes para priorizar. Se quiser, podemos definir um objetivo e criar um plano."
        val scored = pending.map { task ->
            val title = task.optString("title")
            val lower = title.lowercase(Locale.ROOT)
            var score = 0
            val reasons = mutableListOf<String>()
            if (listOf("urgente", "prazo", "vence", "hoje", "atrasad", "agora").any { lower.contains(it) }) {
                score += 5; reasons.add("possível urgência indicada no título")
            }
            if (listOf("bloqueio", "desbloquear", "resolver erro", "corrigir", "impedindo").any { lower.contains(it) }) {
                score += 4; reasons.add("pode desbloquear outras etapas")
            }
            if (listOf("pagar", "conta", "documento", "enviar", "responder", "marcar", "agendar").any { lower.contains(it) }) {
                score += 2; reasons.add("ação prática que pode depender de terceiros ou prazo")
            }
            if (task.optString("goal").isNotBlank()) {
                score += 1; reasons.add("vinculada a um objetivo registrado")
            }
            val created = task.optString("created_at")
            val ageDays = try {
                val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).parse(created)
                if (date == null) 0L else ((System.currentTimeMillis() - date.time).coerceAtLeast(0L) / 86_400_000L)
            } catch (_: Exception) { 0L }
            if (ageDays >= 7) { score += 1; reasons.add("está pendente há pelo menos uma semana") }
            Triple(task, score, reasons)
        }.sortedWith(compareByDescending<Triple<JSONObject, Int, List<String>>> { it.second }
            .thenBy { it.first.optString("created_at") })
        val lines = scored.take(8).mapIndexed { i, entry ->
            val task = entry.first
            val why = entry.third.takeIf { it.isNotEmpty() }?.joinToString(", ") ?: "sem urgência identificada; ordem sugerida por antiguidade"
            "${i + 1}. ${task.optString("title")} [prioridade ${when { entry.second >= 5 -> "alta"; entry.second >= 2 -> "média"; else -> "normal" }}] · $why"
        }
        recordEvent("Pendências priorizadas", "${pending.size} tarefa(s) avaliadas")
        return "Sugestão de prioridade para suas ${pending.size} tarefa(s) pendente(s):\n" + lines.joinToString("\n") + "\n\nEsta é uma estimativa baseada no texto e na data de registro, não em prazos reais que você não informou. Você pode me dizer os prazos para eu refinar a ordem."
    }

    @Synchronized fun nextStep(): String {
        val priorities = prioritizeTasks()
        if (readObjects(KEY_TASKS).none { it.optString("status", "pending") == "pending" }) {
            val goal = getGoals().firstOrNull()
            return if (goal == null) "Ainda não tenho objetivo ou tarefa pendente. Diga: 'Meu objetivo é [objetivo]' para começarmos." else "Seu objetivo registrado é '$goal', mas não há tarefas pendentes. Posso ajudar a criar um plano para avançar."
        }
        return "Meu próximo passo sugerido é começar pela primeira tarefa desta lista.\n" + priorities
    }

    @Synchronized fun listTasks(): String {
        val tasks = readObjects(KEY_TASKS)
        val pending = tasks.filter { it.optString("status", "pending") == "pending" }
        val done = tasks.count { it.optString("status") == "done" }
        return if (pending.isEmpty()) "Você não tem tarefas pendentes registradas. Há $done tarefa(s) concluída(s)." else "Tarefas pendentes (${pending.size}): " + pending.take(20).mapIndexed { i, t -> "${i + 1}. ${t.optString("title")}${t.optString("goal").takeIf { it.isNotBlank() }?.let { " [objetivo: $it]" } ?: ""}" }.joinToString("; ") + ". Concluídas: $done."
    }

    @Synchronized fun completeTask(query: String): String {
        val tasks = readObjects(KEY_TASKS)
        val q = query.trim().lowercase()
        if (q.isBlank()) return "Diga o nome ou o número da tarefa que você concluiu."
        val pending = tasks.filter { it.optString("status", "pending") == "pending" }
        val index = q.toIntOrNull()?.minus(1)
        val task = if (index != null && index in pending.indices) pending[index] else pending.firstOrNull { it.optString("title").lowercase().contains(q) }
        if (task == null) return "Não encontrei uma tarefa pendente correspondente a '$query'. Peça para listar as tarefas e tente novamente."
        task.put("status", "done").put("updated_at", now()).put("completed_at", now())
        saveObjects(KEY_TASKS, tasks)
        val completedTitle = task.optString("title")
        val plans = readObjects(KEY_PLANS)
        plans.forEach { plan ->
            val steps = plan.optJSONArray("steps") ?: JSONArray()
            for (i in 0 until steps.length()) {
                val step = steps.optJSONObject(i) ?: continue
                if (step.optString("title").equals(completedTitle, true)) step.put("status", "done")
            }
            if (steps.length() > 0 && (0 until steps.length()).all { steps.optJSONObject(it)?.optString("status") == "done" }) plan.put("status", "completed")
            plan.put("updated_at", now())
        }
        saveObjects(KEY_PLANS, plans)
        recordEvent("Tarefa concluída", completedTitle)
        return "Marquei como concluída: $completedTitle. O histórico e a etapa correspondente do plano foram atualizados."
    }

    @Synchronized fun addAttempt(description: String, goal: String = ""): String {
        val clean = description.trim().take(500)
        if (clean.isBlank()) return "Conte qual tentativa você quer registrar."
        recordEvent("Tentativa registrada", clean + if (goal.isNotBlank()) " | Objetivo: $goal" else "")
        val tasks = readObjects(KEY_TASKS)
        val related = tasks.firstOrNull { it.optString("status") == "pending" && goal.isNotBlank() && it.optString("goal").contains(goal, true) }
        if (related != null) {
            val attempts = related.optJSONArray("attempts") ?: JSONArray()
            attempts.put(JSONObject().put("at", now()).put("description", clean))
            related.put("attempts", attempts).put("updated_at", now())
            saveObjects(KEY_TASKS, tasks)
        }
        return "Registrei essa tentativa no histórico. Vou considerar o que já foi tentado ao ajudar a decidir o próximo passo."
    }


    /** Registra um bloqueio declarado pelo usuário; não presume que a Gabi detectou algo no telefone. */
    @Synchronized fun reportBlocker(description: String, taskQuery: String = ""): String {
        val clean = description.trim().take(500)
        if (clean.isBlank()) return "Conte o que está impedindo o avanço."
        val blockers = readObjects(KEY_BLOCKERS)
        val task = readObjects(KEY_TASKS).firstOrNull { t ->
            t.optString("status", "pending") == "pending" && taskQuery.isNotBlank() &&
                (t.optString("title").contains(taskQuery, true) || taskQuery.contains(t.optString("title"), true))
        }
        blockers.add(JSONObject().put("id", UUID.randomUUID().toString().take(8))
            .put("description", clean).put("task", task?.optString("title") ?: taskQuery.trim().take(240))
            .put("status", "active").put("created_at", now()).put("updated_at", now()))
        saveObjects(KEY_BLOCKERS, blockers.takeLast(50))
        task?.put("blocked", true)?.put("blocker_note", clean)?.put("updated_at", now())
        if (task != null) saveObjects(KEY_TASKS, readObjects(KEY_TASKS).map { if (it.optString("id") == task.optString("id")) task else it })
        recordEvent("Bloqueio registrado", (task?.optString("title")?.let { "$it | " } ?: "") + clean)
        return "Bloqueio registrado${task?.optString("title")?.takeIf { it.isNotBlank() }?.let { " na tarefa '$it'" } ?: ""}. Ainda não alterei nada fora da Gabi. Posso ajudar a encontrar alternativas; se quiser, diga 'sugira alternativas para esse bloqueio'."
    }

    @Synchronized fun listBlockers(): String {
        val active = readObjects(KEY_BLOCKERS).filter { it.optString("status", "active") == "active" }
        if (active.isEmpty()) return "Não há bloqueios ativos registrados. Só registro bloqueios informados por você ou identificados em dados que você fornecer."
        return "Bloqueios ativos:\n" + active.takeLast(12).mapIndexed { i, b ->
            "${i + 1}. ${b.optString("task").takeIf { it.isNotBlank() }?.let { "[$it] " } ?: ""}${b.optString("description")}"
        }.joinToString("\n")
    }

    @Synchronized fun resolveBlocker(query: String): String {
        val clean = query.trim()
        if (clean.isBlank()) return "Diga qual bloqueio foi resolvido."
        val blockers = readObjects(KEY_BLOCKERS)
        val blocker = blockers.lastOrNull { it.optString("status", "active") == "active" &&
            (it.optString("description").contains(clean, true) || it.optString("task").contains(clean, true) || clean.equals("todos", true)) }
        if (blocker == null) return "Não encontrei um bloqueio ativo correspondente a '$clean'. Peça para listar os bloqueios."
        if (clean.equals("todos", true)) blockers.filter { it.optString("status", "active") == "active" }.forEach { it.put("status", "resolved").put("updated_at", now()) }
        else blocker.put("status", "resolved").put("updated_at", now())
        saveObjects(KEY_BLOCKERS, blockers)
        val taskName = blocker.optString("task")
        if (taskName.isNotBlank()) {
            val tasks = readObjects(KEY_TASKS)
            tasks.filter { it.optString("title").equals(taskName, true) }.forEach { it.put("blocked", false).put("updated_at", now()) }
            saveObjects(KEY_TASKS, tasks)
        }
        recordEvent("Bloqueio resolvido", blocker.optString("description"))
        return "Registrei o bloqueio como resolvido. Confira o próximo passo antes de retomar a tarefa."
    }

    @Synchronized fun recordOutcome(description: String): String {
        val clean = description.trim().take(500)
        if (clean.isBlank()) return "Conte qual foi o resultado."
        recordEvent("Resultado registrado", clean)
        return "Resultado registrado no histórico. Vou considerar esse resultado e as tentativas anteriores para evitar repetir uma abordagem sem motivo."
    }

    @Synchronized fun savePlan(goal: String, steps: List<String>): String {
        val cleanGoal = goal.trim().take(240)
        val cleanSteps = steps.map { it.trim().take(240) }.filter { it.isNotBlank() }.take(20)
        if (cleanGoal.isBlank() || cleanSteps.isEmpty()) return "Não consegui salvar o plano. Informe o objetivo e pelo menos uma etapa."
        val goals = getGoals().toMutableList()
        if (goals.none { it.equals(cleanGoal, true) }) prefs.edit().putString(KEY_GOALS, JSONArray((goals + cleanGoal).takeLast(50)).toString()).apply()
        val plans = readObjects(KEY_PLANS)
        val existing = plans.firstOrNull { it.optString("goal").equals(cleanGoal, true) }
        val stepsJson = JSONArray()
        cleanSteps.forEachIndexed { i, step -> stepsJson.put(JSONObject().put("number", i + 1).put("title", step).put("status", "pending")) }
        val plan = (existing ?: JSONObject().put("id", UUID.randomUUID().toString().take(8)).also { plans.add(it) })
        plan.put("goal", cleanGoal).put("steps", stepsJson).put("updated_at", now()).put("status", "active")
        saveObjects(KEY_PLANS, plans.takeLast(50))
        cleanSteps.forEach { addTask(it, cleanGoal) }
        recordEvent("Plano salvo", "$cleanGoal | ${cleanSteps.size} etapas")
        return "Plano salvo para '$cleanGoal' com ${cleanSteps.size} etapas. Transformei as etapas em tarefas pendentes para acompanharmos o progresso."
    }

    @Synchronized fun listPlans(): String {
        val plans = readObjects(KEY_PLANS)
        if (plans.isEmpty()) return "Ainda não há planos de longo prazo salvos. Peça: 'crie um plano para [objetivo]'."
        return plans.takeLast(10).joinToString("\n") { p ->
            val steps = p.optJSONArray("steps") ?: JSONArray()
            val lines = (0 until steps.length()).map { i -> val s = steps.optJSONObject(i) ?: JSONObject(); "${i + 1}. [${if (s.optString("status") == "done") "x" else " "}] ${s.optString("title")}" }
            "Objetivo: ${p.optString("goal")} (${p.optString("status")})\n" + lines.joinToString("\n")
        }
    }

    /** Executa uma passagem local do ciclo de trabalho: estado -> bloqueios -> prioridade -> próximo passo. */
    @Synchronized fun runWorkCycle(): String {
        val tasks = readObjects(KEY_TASKS)
        val pending = tasks.filter { it.optString("status", "pending") == "pending" }
        val blocked = pending.filter { it.optBoolean("blocked", false) }
        val activeBlockers = readObjects(KEY_BLOCKERS).filter { it.optString("status", "active") == "active" }
        val done = tasks.count { it.optString("status") == "done" }
        val goals = getGoals()
        val followUps = readObjects(KEY_PROPOSALS).filter { it.optString("status") in listOf("execution_failed", "launched_waiting_user_verification", "approved_pending_integration", "approved_pending_permission") }.takeLast(8)
        val failedFollowUps = followUps.filter { it.optString("status") == "execution_failed" }
        val awaitingVerification = followUps.filter { it.optString("status") == "launched_waiting_user_verification" }
        val priorityText = prioritizeTasks()
        val firstTask = pending.filterNot { it.optBoolean("blocked", false) }
            .maxByOrNull { task ->
                val title = task.optString("title").lowercase(Locale.ROOT)
                (if (listOf("urgente", "prazo", "hoje", "agora").any { title.contains(it) }) 5 else 0) +
                (if (task.optString("goal").isNotBlank()) 1 else 0)
            }
        val next = when {
            failedFollowUps.isNotEmpty() -> "Há ${failedFollowUps.size} tentativa(s) que falharam. Revise o resultado registrado e escolha uma rota alternativa antes de repetir a ação."
            awaitingVerification.isNotEmpty() -> "Há ${awaitingVerification.size} integração(ões) aberta(s) aguardando sua verificação. Confirme o resultado antes de marcar qualquer etapa como concluída."
            goals.isEmpty() && pending.isEmpty() -> "Próximo passo: definir um objetivo de longo prazo."
            activeBlockers.isNotEmpty() -> "Próximo passo: escolher um bloqueio ativo e decidir qual alternativa verificar primeiro."
            firstTask != null -> "Próximo passo sugerido: ${firstTask.optString("title")}. Confirme se essa tarefa continua relevante antes de agir."
            pending.isNotEmpty() && blocked.size == pending.size -> "Todas as tarefas pendentes parecem bloqueadas. Precisamos esclarecer um bloqueio ou escolher uma rota alternativa."
            pending.isEmpty() && goals.isNotEmpty() -> "Não há tarefas pendentes. Escolha um objetivo e peça um novo plano para continuar avançando."
            else -> "Revise os objetivos e registre a próxima tarefa verificável."
        }
        recordEvent("Ciclo de trabalho revisado", "${goals.size} objetivo(s), ${pending.size} pendente(s), $done concluída(s), ${activeBlockers.size} bloqueio(s) ativo(s)")
        return buildString {
            append("CICLO DE TRABALHO DA GABI\n")
            append("1. Estado: ${goals.size} objetivo(s), ${pending.size} tarefa(s) pendente(s), $done concluída(s).\n")
            append("2. Obstáculos: ")
            append(if (activeBlockers.isEmpty()) "nenhum bloqueio ativo registrado." else "${activeBlockers.size} bloqueio(s) ativo(s) registrado(s).")
            append("\n3. Prioridade atual:\n$priorityText\n")
            append("4. $next\n")
            append("5. Acompanhamento: ")
            append(when {
                failedFollowUps.isNotEmpty() -> "existem tentativas falhas a revisar; não vou repeti-las cegamente."
                awaitingVerification.isNotEmpty() -> "existem ações aguardando sua verificação; ainda não contam como concluídas."
                followUps.isNotEmpty() -> "existem ações aguardando permissão ou integração compatível."
                else -> "nenhuma ação precisa de verificação adicional no momento."
            })
            append("\n6. Autorização: nenhuma ação externa nova foi executada nesta revisão. Para cada ação compatível, apresentarei uma proposta específica e pedirei sua confirmação.")
        }
    }

    /** Guarda uma proposta de ação aguardando decisão; proposta não equivale a execução. */
    @Synchronized fun proposeAction(description: String): String {
        val clean = description.trim().take(500)
        if (clean.isBlank()) return "Descreva a ação que você quer avaliar."
        val proposals = readObjects(KEY_PROPOSALS)
        val id = UUID.randomUUID().toString().take(8)
        proposals.add(JSONObject().put("id", id).put("description", clean).put("status", "awaiting_confirmation").put("created_at", now()).put("updated_at", now()))
        saveObjects(KEY_PROPOSALS, proposals.takeLast(50))
        recordEvent("Ação proposta", "$id | $clean")
        return "Proposta registrada, ainda sem execução. ID: $id. Ação: $clean. Para autorizar o registro da intenção, diga 'autorizar proposta $id'; para cancelar, diga 'cancelar proposta $id'. A autorização não executa ações externas automaticamente: isso depende de uma integração implementada e de uma confirmação específica no momento da execução."
    }

    @Synchronized fun decideProposal(query: String, approve: Boolean): String {
        val clean = query.trim()
        if (clean.isBlank()) return "Informe o ID da proposta."
        val proposals = readObjects(KEY_PROPOSALS)
        val proposal = proposals.lastOrNull { it.optString("status") == "awaiting_confirmation" && it.optString("id").equals(clean, true) }
            ?: return "Não encontrei uma proposta aguardando confirmação com o ID '$clean'."
        if (!approve) {
            proposal.put("status", "cancelled").put("updated_at", now())
            saveObjects(KEY_PROPOSALS, proposals)
            recordEvent("Proposta cancelada", "${proposal.optString("id")} | ${proposal.optString("description")}")
            return "Proposta cancelada: ${proposal.optString("description")}. Nenhuma ação foi executada."
        }

        // Integrações explícitas, pequenas e limitadas: abrir um site ou uma tela de configurações.
        // A aprovação é específica por ID. Abrir a tela não significa que a ação no destino foi concluída.
        val description = proposal.optString("description").trim()
        val integrationResult = runRegisteredIntegration(description)
        if (integrationResult != null) {
            val launched = integrationResult.first
            val resultText = integrationResult.second
            proposal.put("status", if (launched) "launched_waiting_user_verification" else "execution_failed")
                .put("execution_result", resultText).put("updated_at", now())
            saveObjects(KEY_PROPOSALS, proposals)
            recordEvent(if (launched) "Integração aberta, aguardando verificação" else "Integração falhou", "${proposal.optString("id")} | $description | $resultText")
            return if (launched) "$resultText\nConfira a tela aberta e diga 'registre o resultado: ...' para eu atualizar o plano. Abrir a tela não confirma que algo foi concluído." else "$resultText\nNão marquei a tarefa como concluída. Podemos tentar outra rota; diga 'sugira alternativas para esse bloqueio' ou 'inicie o ciclo de trabalho'."
        }

        // Só executa comandos locais de navegação, conhecidos e de baixo risco, após aprovação explícita por ID.
        // Ações genéricas, cliques em conteúdo, mensagens, compras, exclusões e serviços externos não entram nessa lista.
        val safeCommand = canonicalSafeDeviceCommand(description)
        if (safeCommand == null) {
            proposal.put("status", "approved_pending_integration").put("updated_at", now())
            saveObjects(KEY_PROPOSALS, proposals)
            recordEvent("Proposta autorizada, sem executor compatível", "${proposal.optString("id")} | $description")
            return "Você autorizou '$description', mas não executei a ação: ela não corresponde a um comando local seguro disponível. Posso preparar os passos ou será necessária uma integração específica."
        }
        if (!GabiAccessibilityService.isEnabled(appContext)) {
            proposal.put("status", "approved_pending_permission").put("updated_at", now())
            saveObjects(KEY_PROPOSALS, proposals)
            recordEvent("Ação aguardando Acessibilidade", "${proposal.optString("id")} | $safeCommand")
            return "Autorização registrada para '$safeCommand', mas o controle de aplicativos está desligado. Ative-o manualmente nas configurações de Acessibilidade do Android e crie uma nova proposta quando quiser tentar novamente. Não executei a ação."
        }
        val executionResult = GabiAccessibilityService.runApproved(safeCommand)
        if (executionResult == null) {
            proposal.put("status", "approved_pending_permission").put("updated_at", now())
            saveObjects(KEY_PROPOSALS, proposals)
            recordEvent("Ação não iniciada", "${proposal.optString("id")} | Serviço de Acessibilidade não conectado")
            return "O serviço de Acessibilidade não está conectado neste momento. Não executei '$safeCommand'. Abra a Gabi, confira a permissão e crie uma nova proposta para tentar novamente."
        }
        val success = executionResult.startsWith("Ação confirmada:")
        proposal.put("status", if (success) "executed" else "execution_failed")
            .put("execution_result", executionResult).put("updated_at", now())
        saveObjects(KEY_PROPOSALS, proposals)
        recordEvent(if (success) "Ação executada" else "Execução não confirmada", "${proposal.optString("id")} | $safeCommand | $executionResult")
        return if (success) "$executionResult\nRegistrei o resultado no histórico. Confira a tela para confirmar que o resultado corresponde ao que você queria." else "A tentativa não foi confirmada: $executionResult\nRegistrei o resultado e não vou marcar a ação como concluída."
    }


    /**
     * Lista fechada de integrações externas básicas. Nunca envia dados nem executa ações dentro do site.
     * Retorna null quando a proposta não corresponde a uma integração conhecida.
     */
    private fun runRegisteredIntegration(description: String): Pair<Boolean, String>? {
        val clean = description.trim()
        val lower = clean.lowercase(Locale.ROOT)
        if (lower.startsWith("criar evento no calendário:") || lower.startsWith("criar evento no calendario:")) {
            return runCalendarDraftIntegration(clean)
        }
        val intent: Intent = when {
            lower.startsWith("abrir site ") || lower.startsWith("abrir url ") || lower.startsWith("abrir link ") -> {
                val rawUrl = clean.substringAfter(' ').substringAfter(' ').trim().removeSurrounding("\"").removeSurrounding("'")
                val normalizedUrl = if (rawUrl.startsWith("https://", true) || rawUrl.startsWith("http://", true)) rawUrl else "https://$rawUrl"
                val uri = try { Uri.parse(normalizedUrl) } catch (_: Exception) { return false to "URL inválida. Nenhum site foi aberto." }
                if (uri.scheme !in listOf("http", "https") || uri.host.isNullOrBlank()) return false to "Só posso abrir links HTTP ou HTTPS válidos. Nenhum site foi aberto."
                Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            lower in listOf("abrir configurações de wi-fi", "abrir configuracoes de wi-fi", "abrir wi-fi", "abrir configurações de wifi", "abrir configuracoes de wifi") ->
                Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            lower in listOf("abrir configurações de bluetooth", "abrir configuracoes de bluetooth", "abrir bluetooth") ->
                Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            lower in listOf("abrir configurações da gabi", "abrir configurações do aplicativo", "abrir configuracoes da gabi", "abrir configuracoes do aplicativo") ->
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${appContext.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            else -> return null
        }
        return try {
            // Tenta abrir diretamente para evitar falsos negativos de visibilidade de pacotes no Android 11+.
            appContext.startActivity(intent)
            true to "Integração aberta: $clean. O Android aceitou a abertura da tela, mas o resultado dentro dela ainda precisa ser verificado por você."
        } catch (e: Exception) {
            false to "Não consegui abrir a integração: ${e.message ?: "erro do Android"}. Nenhuma conclusão foi registrada."
        }
    }


    /**
     * Integração de calendário com confirmação final do usuário no app de calendário.
     * Formato: criar evento no calendário: Título | yyyy-MM-dd HH:mm | yyyy-MM-dd HH:mm
     * Não solicita permissão de calendário nem grava o evento diretamente.
     */
    private fun runCalendarDraftIntegration(description: String): Pair<Boolean, String> {
        val payload = description.substringAfter(':', "").trim()
        val parts = payload.split('|').map { it.trim() }
        if (parts.size != 3 || parts[0].isBlank()) {
            return false to "Formato do evento inválido. Use: criar evento no calendário: Título | AAAA-MM-DD HH:mm | AAAA-MM-DD HH:mm. Nenhum evento foi criado."
        }
        val formatter = java.time.format.DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm", Locale.ROOT)
        val begin: java.time.LocalDateTime
        val end: java.time.LocalDateTime
        try {
            begin = java.time.LocalDateTime.parse(parts[1], formatter)
            end = java.time.LocalDateTime.parse(parts[2], formatter)
        } catch (_: Exception) {
            return false to "Não consegui interpretar as datas. Use AAAA-MM-DD HH:mm, por exemplo 2026-10-20 15:00. Nenhum evento foi criado."
        }
        if (!end.isAfter(begin)) return false to "O horário final precisa ser posterior ao inicial. Nenhum evento foi criado."
        val beginMillis = begin.atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        val endMillis = end.atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        val intent = Intent(Intent.ACTION_INSERT).apply {
            data = android.provider.CalendarContract.Events.CONTENT_URI
            putExtra(android.provider.CalendarContract.Events.TITLE, parts[0].take(160))
            putExtra(android.provider.CalendarContract.EXTRA_EVENT_BEGIN_TIME, beginMillis)
            putExtra(android.provider.CalendarContract.EXTRA_EVENT_END_TIME, endMillis)
            putExtra(android.provider.CalendarContract.Events.EVENT_TIMEZONE, java.util.TimeZone.getDefault().id)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            appContext.startActivity(intent)
            true to "Abri o formulário de novo evento no calendário para '${parts[0]}'. Confira o título e os horários e toque em Salvar no aplicativo de calendário. A Gabi não gravou o evento diretamente; ele só existirá se você confirmar lá."
        } catch (e: Exception) {
            false to "Não consegui abrir um aplicativo de calendário compatível: ${e.message ?: "erro do Android"}. Nenhum evento foi criado."
        }
    }

    /** Converte somente comandos de navegação de baixo risco para uma lista fechada. */
    private fun canonicalSafeDeviceCommand(description: String): String? {
        val normalized = description.trim().lowercase(Locale.ROOT)
            .replace(Regex("\\s+"), " ")
            .trim('.', '!', '?', ' ')
        return when (normalized) {
            "voltar", "pressionar voltar", "volte" -> "voltar"
            "ir para a tela inicial", "tela inicial", "abrir tela inicial" -> "ir para a tela inicial"
            "rolar para baixo", "descer a tela" -> "rolar para baixo"
            "rolar para cima", "subir a tela" -> "rolar para cima"
            else -> null
        }
    }

    @Synchronized fun listProposals(): String {
        val proposals = readObjects(KEY_PROPOSALS).takeLast(15)
        if (proposals.isEmpty()) return "Não há propostas de ação registradas."
        return "Propostas recentes:\n" + proposals.joinToString("\n") { p -> "${p.optString("id")} [${p.optString("status")}]: ${p.optString("description")}" + p.optString("execution_result").takeIf { it.isNotBlank() }?.let { " | resultado: $it" }.orEmpty() }
    }

    @Synchronized fun progressSummary(): String {
        val tasks = readObjects(KEY_TASKS)
        val pending = tasks.count { it.optString("status", "pending") == "pending" }
        val done = tasks.count { it.optString("status") == "done" }
        val plans = readObjects(KEY_PLANS).count { it.optString("status") == "active" }
        val events = readObjects(KEY_EVENTS).takeLast(5)
        val recent = if (events.isEmpty()) "nenhuma atividade registrada" else events.joinToString("; ") { "${it.optString("type")}: ${it.optString("detail")}" }
        return "Resumo de progresso: ${getGoals().size} objetivo(s), $plans plano(s) ativo(s), $pending tarefa(s) pendente(s) e $done concluída(s). Atividades recentes: $recent."
    }

    @Synchronized fun contextForPlanning(): String {
        val goals = getGoals()
        val pending = readObjects(KEY_TASKS).filter { it.optString("status", "pending") == "pending" }.takeLast(25)
        val done = readObjects(KEY_TASKS).filter { it.optString("status") == "done" }.takeLast(15)
        val plans = readObjects(KEY_PLANS).takeLast(10)
        val events = readObjects(KEY_EVENTS).takeLast(12)
        val blockers = readObjects(KEY_BLOCKERS).filter { it.optString("status", "active") == "active" }.takeLast(12)
        val proposalsNeedingFollowUp = readObjects(KEY_PROPOSALS).filter { it.optString("status") in listOf("execution_failed", "launched_waiting_user_verification", "approved_pending_integration", "approved_pending_permission") }.takeLast(8)
        return buildString {
            append("OBJETIVOS DE LONGO PRAZO:\n"); append(if (goals.isEmpty()) "Nenhum cadastrado" else goals.joinToString("\n") { "- $it" })
            append("\nTAREFAS PENDENTES:\n"); append(if (pending.isEmpty()) "Nenhuma" else pending.joinToString("\n") { "- ${it.optString("title")} [objetivo: ${it.optString("goal")}]" })
            append("\nTAREFAS CONCLUÍDAS (não sugerir de novo sem motivo):\n"); append(if (done.isEmpty()) "Nenhuma" else done.joinToString("\n") { "- ${it.optString("title")}" })
            append("\nPLANOS E ETAPAS:\n"); append(if (plans.isEmpty()) "Nenhum plano salvo" else plans.joinToString("\n") { p -> val a = p.optJSONArray("steps") ?: JSONArray(); "${p.optString("goal")}: " + (0 until a.length()).joinToString("; ") { i -> val s = a.optJSONObject(i) ?: JSONObject(); "${s.optString("title")} (${s.optString("status")})" } })
            append("\nBLOQUEIOS ATIVOS (declarados pelo usuário):\n"); append(if (blockers.isEmpty()) "Nenhum" else blockers.joinToString("\n") { "- tarefa: ${it.optString("task").ifBlank { "não vinculada" }} | ${it.optString("description")}" })
            append("\nAÇÕES QUE PRECISAM DE ACOMPANHAMENTO:\n"); append(if (proposalsNeedingFollowUp.isEmpty()) "Nenhuma" else proposalsNeedingFollowUp.joinToString("\n") { "- ${it.optString("id")} [${it.optString("status")}] ${it.optString("description")}: ${it.optString("execution_result")}" })
            append("\nHISTÓRICO RECENTE DE TENTATIVAS/RESULTADOS/ALTERAÇÕES:\n"); append(if (events.isEmpty()) "Nenhum evento" else events.joinToString("\n") { "- ${it.optString("at")} | ${it.optString("type")}: ${it.optString("detail")}" })
        }
    }

    @Synchronized fun handleCommand(input: String): String? {
        val text = input.trim(); val lower = text.lowercase()
        if (listOf("inicie o ciclo de trabalho", "iniciar ciclo de trabalho", "revise o ciclo de trabalho", "revisar meu plano de trabalho", "faça uma revisão completa", "faca uma revisao completa", "execute o ciclo de trabalho").any { lower.contains(it) }) return runWorkCycle()
        if (listOf("listar propostas", "minhas propostas de ação", "minhas propostas de acao", "propostas aguardando autorização", "propostas aguardando autorizacao").any { lower.contains(it) }) return listProposals()
        val approvePrefix = listOf("autorizar proposta", "aprovar proposta").firstOrNull { lower.startsWith(it) }
        if (approvePrefix != null) return decideProposal(text.drop(approvePrefix.length).trim().trimStart(':', ',', ' '), true)
        val cancelPrefix = listOf("cancelar proposta", "rejeitar proposta", "recusar proposta").firstOrNull { lower.startsWith(it) }
        if (cancelPrefix != null) return decideProposal(text.drop(cancelPrefix.length).trim().trimStart(':', ',', ' '), false)
        val proposalPrefix = listOf("proponha uma ação", "proponha uma acao", "prepare uma proposta de ação", "prepare uma proposta de acao").firstOrNull { lower.startsWith(it) }
        if (proposalPrefix != null) return proposeAction(text.drop(proposalPrefix.length).trim().trimStart(':', ',', ' '))
        val goalPrefixes = listOf("meu objetivo é", "meu objetivo e", "registre o objetivo", "registre como objetivo", "adicione o objetivo", "quero alcançar", "quero alcancar")
        val goalPrefix = goalPrefixes.firstOrNull { lower.startsWith(it) }
        if (goalPrefix != null) return addGoal(text.drop(goalPrefix.length).trim().trimStart(':', ',', ' '))
        if (listOf("quais são meus objetivos", "quais sao meus objetivos", "listar objetivos", "meus objetivos").any { lower.contains(it) }) return if (getGoals().isEmpty()) "Ainda não há objetivos registrados. Você pode dizer: meu objetivo é melhorar o Gabi I.A.." else "Seus objetivos registrados são: " + getGoals().mapIndexed { i, g -> "${i + 1}: $g" }.joinToString(". ")
        if (listOf("apague meus objetivos", "limpe meus objetivos", "esqueça meus objetivos", "esqueca meus objetivos").any { lower.contains(it) }) { clearGoals(); return "A lista de objetivos foi apagada." }
        if (listOf("quais tarefas estão pendentes", "quais tarefas estao pendentes", "listar tarefas", "minhas tarefas", "tarefas pendentes", "o que falta fazer").any { lower.contains(it) }) return listTasks()
        if (listOf("priorize minhas tarefas", "prioriza minhas tarefas", "priorizar tarefas", "organize minhas prioridades", "quais são minhas prioridades", "quais sao minhas prioridades").any { lower.contains(it) }) return prioritizeTasks()
        if (listOf("qual o próximo passo", "qual o proximo passo", "o que devo fazer agora", "por onde começo", "por onde comeco", "decida a próxima tarefa", "decida a proxima tarefa").any { lower.contains(it) }) return nextStep()
        if (listOf("meu progresso", "resumo do progresso", "como estamos", "como está meu progresso", "como esta meu progresso").any { lower.contains(it) }) return progressSummary()
        if (listOf("listar planos", "meus planos", "mostrar planos", "planos salvos").any { lower.contains(it) }) return listPlans()
        if (listOf("quais são os bloqueios", "quais sao os bloqueios", "listar bloqueios", "bloqueios ativos", "o que está bloqueando", "o que esta bloqueando").any { lower.contains(it) }) return listBlockers()
        val resolvePrefixes = listOf("resolvi o bloqueio", "bloqueio resolvido", "desbloqueei", "marque o bloqueio como resolvido")
        val resolvePrefix = resolvePrefixes.firstOrNull { lower.startsWith(it) }
        if (resolvePrefix != null) return resolveBlocker(text.drop(resolvePrefix.length).trim().trimStart(':', ',', ' ').ifBlank { "todos" })
        val blockerPrefixes = listOf("registre um bloqueio", "registra um bloqueio", "o plano está bloqueado porque", "o plano esta bloqueado porque", "estou bloqueado porque", "estou bloqueada porque", "não consigo avançar porque", "nao consigo avancar porque", "fiquei travado porque", "fiquei travada porque")
        val blockerPrefix = blockerPrefixes.firstOrNull { lower.startsWith(it) }
        if (blockerPrefix != null) return reportBlocker(text.drop(blockerPrefix.length).trim().trimStart(':', ',', ' '))
        val outcomePrefixes = listOf("registre o resultado", "registra o resultado", "o resultado foi", "a tentativa falhou porque", "não funcionou porque", "nao funcionou porque")
        val outcomePrefix = outcomePrefixes.firstOrNull { lower.startsWith(it) }
        if (outcomePrefix != null) return recordOutcome(text.drop(outcomePrefix.length).trim().trimStart(':', ',', ' ').let { if (it.isBlank()) text else it })
        val taskPrefixes = listOf("adicione uma tarefa", "adiciona uma tarefa", "crie uma tarefa", "anote uma tarefa", "lembre que preciso", "preciso fazer", "tenho que fazer")
        val taskPrefix = taskPrefixes.firstOrNull { lower.startsWith(it) }
        if (taskPrefix != null) return addTask(text.drop(taskPrefix.length).trim().trimStart(':', ',', ' '))
        val donePrefixes = listOf("concluí a tarefa", "conclui a tarefa", "terminei a tarefa", "completei a tarefa", "marque a tarefa como concluída", "marque a tarefa como concluida")
        val donePrefix = donePrefixes.firstOrNull { lower.startsWith(it) }
        if (donePrefix != null) return completeTask(text.drop(donePrefix.length).trim().trimStart(':', ',', ' '))
        val attemptPrefixes = listOf("registre uma tentativa", "registra uma tentativa", "já tentei", "ja tentei", "anote que tentei", "registra que tentei")
        val attemptPrefix = attemptPrefixes.firstOrNull { lower.startsWith(it) }
        if (attemptPrefix != null) return addAttempt(text.drop(attemptPrefix.length).trim().trimStart(':', ',', ' '))
        return null
    }

    fun proactiveOpening(): String {
        val goals = getGoals(); val pending = readObjects(KEY_TASKS).count { it.optString("status", "pending") == "pending" }
        return if (goals.isEmpty() && pending == 0)
            "Sistemas online. Gabi I.A. à sua disposição. Memória de trabalho pronta. Podemos definir um objetivo de longo prazo e decompô-lo em etapas, Senhor."
        else
            "Gabi I.A. operacional. Tenho ${goals.size} objetivo(s) e ${pending} tarefa(s) pendente(s) registrados. Posso retomar de onde paramos e organizar o próximo passo."
    }

    fun planningPrompt(userInput: String): String = """
        Você é Gabi I.A., assistente pessoal avançada inspirada no estilo de J.A.R.V.I.S.: calma, precisa, elegante e extremamente competente.
        Fale em português brasileiro culto. Dirija-se ao usuário como "Senhor" de forma natural. Seja proativa em sugerir o próximo passo útil, mas nunca invente execução.
        Use o estado persistente abaixo como contexto de continuidade. Priorize o próximo passo útil, considere tentativas anteriores, não sugira como nova uma tarefa já concluída.
        Se o usuário pedir um plano, proponha etapas pequenas, ordenadas, verificáveis e priorizadas por impacto, urgência informada, dependências e esforço. Separe fatos registrados de suposições e explique por que uma tarefa vem primeiro. Nunca invente prazos, bloqueios ou progresso. Ao analisar resultado, compare com tentativas registradas e recomende uma verificação concreta. Se houver bloqueio ativo ou o usuário pedir alternativas, proponha 2 a 4 caminhos alternativos com custo/esforço, riscos e primeiro passo; indique qual dado falta e peça ao usuário para escolher, sem afirmar que testou alternativas. Considere tarefas marcadas como bloqueadas e não as trate como progresso normal.
        REGRA DE AUTORIZAÇÃO: nunca execute, dispare ou confirme uma ação que altere o dispositivo, outro aplicativo, uma conta, um arquivo externo ou um serviço externo sem pedir autorização explícita para aquela ação específica e receber confirmação inequívoca. Permissão genérica ou contexto anterior não contam como autorização. Antes de ações irreversíveis, financeiras, públicas ou que enviem dados, explique o que será enviado/alterado e peça confirmação específica. Se não existir integração técnica disponível, diga isso claramente e não alegue que executou. Para comandos de navegação local de baixo risco, só use a integração quando houver uma proposta específica autorizada pelo usuário; a camada de execução aplica uma lista fechada de comandos permitidos. Nunca converta texto gerado pela IA em comando executável sem validação e autorização explícita.
        Não alegue acesso a sensores, arquivos, notificações lidas ou dados que não foram fornecidos.
        ESTADO PERSISTENTE DA GABI:
        ${contextForPlanning()}
        PEDIDO ATUAL: $userInput
        Responda em português brasileiro, com elegância e precisão. Diferencie claramente sugestão, tarefa registrada e ação efetivamente realizada.
    """.trimIndent()

    private fun recordEvent(type: String, detail: String) {
        val events = readObjects(KEY_EVENTS)
        events.add(JSONObject().put("at", now()).put("type", type).put("detail", detail.take(500)))
        saveObjects(KEY_EVENTS, events.takeLast(100))
    }
    private fun readObjects(key: String): MutableList<JSONObject> = try {
        val arr = JSONArray(prefs.getString(key, "[]") ?: "[]")
        (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.toMutableList()
    } catch (_: Exception) { mutableListOf() }
    private fun saveObjects(key: String, objects: List<JSONObject>) { prefs.edit().putString(key, JSONArray(objects).toString()).apply() }
    private fun now(): String = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())

    companion object {
        private const val KEY_GOALS = "goals_json"
        private const val KEY_TASKS = "gabi_tasks_json"
        private const val KEY_PLANS = "gabi_plans_json"
        private const val KEY_EVENTS = "gabi_events_json"
        private const val KEY_BLOCKERS = "gabi_blockers_json"
        private const val KEY_PROPOSALS = "gabi_action_proposals_json"
    }
}
