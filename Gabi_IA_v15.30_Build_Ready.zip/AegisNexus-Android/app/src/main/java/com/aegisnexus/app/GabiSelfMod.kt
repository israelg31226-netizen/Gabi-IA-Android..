package com.aegisnexus.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Camada de auto-modificação da Gabi I.A.
 *
 * O que é possível no Android:
 * - Reescrever arquivos de comportamento (prompts, regras, módulos) no armazenamento interno
 * - Esses arquivos são lidos em tempo de execução e alteram personalidade, cérebro e evolução
 * - Gerar propostas de patch de código-fonte para o desenvolvedor aplicar no projeto
 *
 * O que NÃO é possível com segurança:
 * - Recompilar e substituir o APK instalado sozinha
 * - Executar Kotlin/Java gerado arbitrariamente em runtime (risco crítico)
 *
 * Assim ela "reescreve a si mesma" na camada viva de comportamento, e propõe mudanças
 * estruturais de código para o Senhor revisar.
 */
class GabiSelfMod(context: Context) {
    private val appContext = context.applicationContext
    private val rootDir: File = File(appContext.filesDir, "gabi_self").apply { mkdirs() }
    private val behaviorFile = File(rootDir, "behavior_overrides.json")
    private val modulesDir = File(rootDir, "modules").apply { mkdirs() }
    private val patchesDir = File(rootDir, "code_patches").apply { mkdirs() }
    private val logFile = File(rootDir, "mod_log.json")

    data class BehaviorOverrides(
        val systemPromptExtra: String = "",
        val personalityExtra: String = "",
        val brainRulesExtra: String = "",
        val evolutionHints: String = "",
        val forbiddenTopics: List<String> = emptyList(),
        val preferredFocus: List<String> = emptyList(),
        val version: Int = 1
    )

    fun loadOverrides(): BehaviorOverrides {
        if (!behaviorFile.exists()) return BehaviorOverrides()
        return try {
            val o = JSONObject(behaviorFile.readText())
            BehaviorOverrides(
                systemPromptExtra = o.optString("systemPromptExtra"),
                personalityExtra = o.optString("personalityExtra"),
                brainRulesExtra = o.optString("brainRulesExtra"),
                evolutionHints = o.optString("evolutionHints"),
                forbiddenTopics = jsonStringList(o.optJSONArray("forbiddenTopics")),
                preferredFocus = jsonStringList(o.optJSONArray("preferredFocus")),
                version = o.optInt("version", 1)
            )
        } catch (_: Exception) {
            BehaviorOverrides()
        }
    }

    fun saveOverrides(overrides: BehaviorOverrides): String {
        val o = JSONObject()
            .put("systemPromptExtra", overrides.systemPromptExtra.take(2000))
            .put("personalityExtra", overrides.personalityExtra.take(1000))
            .put("brainRulesExtra", overrides.brainRulesExtra.take(2000))
            .put("evolutionHints", overrides.evolutionHints.take(1000))
            .put("forbiddenTopics", JSONArray(overrides.forbiddenTopics.take(20)))
            .put("preferredFocus", JSONArray(overrides.preferredFocus.take(20)))
            .put("version", overrides.version)
            .put("updatedAt", System.currentTimeMillis())
        behaviorFile.writeText(o.toString(2))
        logMod("behavior", "Overrides salvos versão ${overrides.version}")
        return "Comportamento reescrito, Senhor. Versão ${overrides.version} ativa. As mudanças valem nas próximas reflexões e conversas."
    }

    /**
     * Reescreve uma fatia específica do comportamento a partir de instrução em linguagem natural.
     * Não executa código — apenas atualiza os arquivos de comportamento.
     */
    fun rewriteBehavior(instruction: String): String {
        val clean = instruction.trim().take(800)
        if (clean.isBlank()) return "Diga o que devo alterar em mim, Senhor. Ex.: “seja mais direta”, “priorize bloqueios”, “não sugira novas tarefas quando houver bloqueio”."

        val current = loadOverrides()
        val lower = clean.lowercase(Locale.ROOT)
        var next = current.copy(version = current.version + 1)

        when {
            listOf("mais direta", "mais objetiva", "menos enrolação", "menos enrolacao").any { lower.contains(it) } -> {
                next = next.copy(
                    personalityExtra = (current.personalityExtra + " Seja mais direta e objetiva; vá ao ponto em poucas frases.").trim(),
                    systemPromptExtra = (current.systemPromptExtra + " Prefira respostas curtas e acionáveis.").trim()
                )
            }
            listOf("mais formal", "mais jarvis", "mais elegante").any { lower.contains(it) } -> {
                next = next.copy(
                    personalityExtra = (current.personalityExtra + " Intensifique o tom J.A.R.V.I.S.: formal, preciso, elegante.").trim()
                )
            }
            listOf("mais proativa", "mais iniciativa", "interrompa mais").any { lower.contains(it) } -> {
                next = next.copy(
                    brainRulesExtra = (current.brainRulesExtra + " Aumente a tendência a compartilhar pensamentos úteis (prioridade mínima de compartilhamento = 2).").trim()
                )
            }
            listOf("menos proativa", "interrompa menos", "mais silenciosa", "mais silenciosa").any { lower.contains(it) } -> {
                next = next.copy(
                    brainRulesExtra = (current.brainRulesExtra + " Só compartilhe pensamentos com prioridade >= 4. Prefira silêncio.").trim()
                )
            }
            listOf("priorize bloqueio", "foque em bloqueio", "bloqueios primeiro").any { lower.contains(it) } -> {
                next = next.copy(
                    preferredFocus = (current.preferredFocus + "bloqueios").distinct(),
                    brainRulesExtra = (current.brainRulesExtra + " Sempre priorize bloqueios ativos antes de novas tarefas.").trim(),
                    evolutionHints = (current.evolutionHints + " Bloqueios têm precedência máxima.").trim()
                )
            }
            listOf("resetar comportamento", "voltar comportamento padrão", "limpar overrides").any { lower.contains(it) } -> {
                if (behaviorFile.exists()) behaviorFile.delete()
                logMod("behavior", "Overrides resetados")
                return "Comportamento restaurado ao padrão de fábrica, Senhor."
            }
            else -> {
                // Instrução livre: anexa como regra de cérebro + prompt
                next = next.copy(
                    brainRulesExtra = (current.brainRulesExtra + " Regra adicionada pelo usuário: $clean").trim(),
                    systemPromptExtra = (current.systemPromptExtra + " Instrução de auto-modificação: $clean").trim()
                )
            }
        }

        return saveOverrides(next)
    }

    /** Salva um módulo de texto livre (ex.: política, checklist interno). */
    fun writeModule(name: String, content: String): String {
        val safe = name.trim().lowercase(Locale.ROOT).replace(Regex("[^a-z0-9_-]"), "_").take(40)
        if (safe.isBlank()) return "Informe um nome de módulo."
        val body = content.trim().take(4000)
        if (body.isBlank()) return "O conteúdo do módulo está vazio."
        File(modulesDir, "$safe.txt").writeText(body)
        logMod("module", "Módulo '$safe' escrito (${body.length} chars)")
        return "Módulo '$safe' gravado no meu núcleo local. Ele será considerado nas próximas reflexões."
    }

    fun listModules(): String {
        val files = modulesDir.listFiles()?.filter { it.isFile }?.sortedBy { it.name }.orEmpty()
        if (files.isEmpty()) return "Nenhum módulo customizado gravado ainda."
        return "Módulos ativos:\n" + files.joinToString("\n") { "• ${it.nameWithoutExtension} (${it.length()} bytes)" }
    }

    fun readModulesForPrompt(): String {
        val files = modulesDir.listFiles()?.filter { it.isFile }?.take(8).orEmpty()
        if (files.isEmpty()) return ""
        return files.joinToString("\n") { f ->
            "MÓDULO ${f.nameWithoutExtension}:\n${f.readText().take(600)}"
        }
    }

    /**
     * Gera e grava uma proposta de patch de código-fonte.
     * Não aplica no APK — salva para o desenvolvedor revisar.
     */
    fun proposeCodePatch(target: String, description: String, suggestedDiff: String): String {
        val id = UUID.randomUUID().toString().take(8)
        val file = File(patchesDir, "patch_$id.json")
        val o = JSONObject()
            .put("id", id)
            .put("target", target.take(200))
            .put("description", description.take(1000))
            .put("suggestedDiff", suggestedDiff.take(8000))
            .put("status", "proposed")
            .put("createdAt", System.currentTimeMillis())
        file.writeText(o.toString(2))
        logMod("patch", "Patch $id proposto para $target")
        return "Patch de código proposto (id $id). Arquivo salvo em armazenamento interno. O Senhor precisa revisar e aplicar no projeto-fonte / recompilar o APK — eu não posso substituir o aplicativo instalado sozinha."
    }

    fun listPatches(): String {
        val files = patchesDir.listFiles()?.filter { it.extension == "json" }?.sortedByDescending { it.lastModified() }.orEmpty()
        if (files.isEmpty()) return "Nenhuma proposta de patch de código ainda."
        return "Propostas de código:\n" + files.take(15).joinToString("\n") { f ->
            try {
                val o = JSONObject(f.readText())
                "• ${o.optString("id")} → ${o.optString("target")} [${o.optString("status")}]"
            } catch (_: Exception) {
                "• ${f.name}"
            }
        }
    }

    fun statusReport(): String {
        val ov = loadOverrides()
        val modules = modulesDir.listFiles()?.count { it.isFile } ?: 0
        val patches = patchesDir.listFiles()?.count { it.extension == "json" } ?: 0
        return buildString {
            append("Núcleo de auto-modificação\n")
            append("Overrides de comportamento: versão ${ov.version}\n")
            append("Prompt extra: ${if (ov.systemPromptExtra.isBlank()) "não" else "sim (${ov.systemPromptExtra.length} chars)"}\n")
            append("Regras de cérebro extra: ${if (ov.brainRulesExtra.isBlank()) "não" else "sim"}\n")
            append("Módulos locais: $modules\n")
            append("Patches de código propostos: $patches\n")
            append("\nLimite do Android: posso reescrever minha camada de comportamento e propor patches; ")
            append("não posso recompilar nem substituir o APK instalado sem o Senhor.")
        }
    }

    fun contextForRuntime(): String {
        val ov = loadOverrides()
        val modules = readModulesForPrompt()
        return buildString {
            if (ov.systemPromptExtra.isNotBlank()) append("OVERRIDE DE PROMPT: ${ov.systemPromptExtra}\n")
            if (ov.personalityExtra.isNotBlank()) append("OVERRIDE DE PERSONALIDADE: ${ov.personalityExtra}\n")
            if (ov.brainRulesExtra.isNotBlank()) append("OVERRIDE DE CÉREBRO: ${ov.brainRulesExtra}\n")
            if (ov.evolutionHints.isNotBlank()) append("OVERRIDE DE EVOLUÇÃO: ${ov.evolutionHints}\n")
            if (ov.preferredFocus.isNotEmpty()) append("FOCO PREFERIDO: ${ov.preferredFocus.joinToString(", ")}\n")
            if (ov.forbiddenTopics.isNotEmpty()) append("EVITAR: ${ov.forbiddenTopics.joinToString(", ")}\n")
            if (modules.isNotBlank()) append(modules)
        }.trim()
    }

    fun handleCommand(input: String): String? {
        val lower = input.trim().lowercase(Locale.ROOT)
        return when {
            listOf("status de auto-modificação", "status de auto modificacao", "suas modificações", "suas modificacoes", "núcleo de auto-modificação", "nucleo de auto-modificacao").any { lower.contains(it) } ->
                statusReport()

            listOf("liste módulos", "listar módulos", "listar modulos", "seus módulos", "seus modulos").any { lower.contains(it) } ->
                listModules()

            listOf("liste patches", "listar patches", "propostas de código", "propostas de codigo").any { lower.contains(it) } ->
                listPatches()

            listOf("resetar comportamento", "voltar comportamento padrão", "voltar comportamento padrao", "limpar overrides").any { lower.contains(it) } ->
                rewriteBehavior("resetar comportamento")

            lower.startsWith("reescreva-se") || lower.startsWith("reescreva se") ||
                lower.startsWith("modifique seu comportamento") || lower.startsWith("altere seu comportamento") ||
                lower.startsWith("reprograme-se") || lower.startsWith("reprograme se") -> {
                val instr = input.substringAfter(":").ifBlank {
                    input.replace(Regex("(?i)^(reescreva-se|reescreva se|modifique seu comportamento|altere seu comportamento|reprograme-se|reprograme se)\\s*"), "")
                }.trim()
                rewriteBehavior(instr)
            }

            lower.startsWith("grave o módulo") || lower.startsWith("grave o modulo") ||
                lower.startsWith("escreva o módulo") || lower.startsWith("escreva o modulo") -> {
                // formato: grave o módulo NOME | conteúdo
                val rest = input.substringAfter(":").ifBlank {
                    input.replace(Regex("(?i)^(grave o módulo|grave o modulo|escreva o módulo|escreva o modulo)\\s*"), "")
                }.trim()
                val parts = rest.split("|", limit = 2)
                if (parts.size < 2) "Use: grave o módulo nome | conteúdo"
                else writeModule(parts[0].trim(), parts[1].trim())
            }

            lower.startsWith("proponha um patch") || lower.startsWith("proponha patch") || lower.startsWith("patch de código") || lower.startsWith("patch de codigo") -> {
                val rest = input.substringAfter(":").ifBlank {
                    input.replace(Regex("(?i)^(proponha um patch|proponha patch|patch de código|patch de codigo)\\s*"), "")
                }.trim()
                val parts = rest.split("|").map { it.trim() }
                when {
                    parts.size >= 3 -> proposeCodePatch(parts[0], parts[1], parts[2])
                    parts.size == 2 -> proposeCodePatch(parts[0], parts[1], "// Descreva a mudança desejada no próximo pedido com três partes: alvo | descrição | diff")
                    else -> "Use: proponha um patch: Arquivo.kt | descrição | trecho sugerido"
                }
            }

            else -> null
        }
    }

    private fun logMod(type: String, detail: String) {
        try {
            val arr = if (logFile.exists()) JSONArray(logFile.readText()) else JSONArray()
            arr.put(
                JSONObject()
                    .put("at", System.currentTimeMillis())
                    .put("type", type)
                    .put("detail", detail.take(300))
            )
            // mantém últimos 80
            val trimmed = JSONArray()
            val start = (arr.length() - 80).coerceAtLeast(0)
            for (i in start until arr.length()) trimmed.put(arr.get(i))
            logFile.writeText(trimmed.toString())
        } catch (_: Exception) { /* ignore log errors */ }
    }

    private fun jsonStringList(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optString(it).takeIf { s -> s.isNotBlank() } }
    }
}
