package com.aegisnexus.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/**
 * Integração opcional. O Android exige que o usuário a habilite manualmente em Acessibilidade.
 * Este serviço não age por conta própria: MainActivity só chama executeApprovedCommand depois
 * de mostrar uma confirmação explícita para a ação solicitada.
 */
class GabiAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* Eventos não iniciam ações. */ }
    override fun onInterrupt() { }

    override fun onServiceConnected() {
        super.onServiceConnected()
        activeService = this
    }

    override fun onDestroy() {
        if (activeService === this) activeService = null
        super.onDestroy()
    }

    fun executeApprovedCommand(raw: String): String {
        val command = raw.trim()
        val lower = command.lowercase(Locale.ROOT)
        return when {
            lower == "voltar" || lower == "pressionar voltar" || lower == "volte" -> {
                if (performGlobalAction(GLOBAL_ACTION_BACK)) "Ação confirmada: voltei uma tela." else "O Android não permitiu voltar nesta tela."
            }
            lower == "ir para a tela inicial" || lower == "tela inicial" -> {
                if (performGlobalAction(GLOBAL_ACTION_HOME)) "Ação confirmada: tela inicial aberta." else "Não consegui abrir a tela inicial."
            }
            lower == "rolar para baixo" || lower == "descer a tela" -> scrollActiveWindow(forward = true)
            lower == "rolar para cima" || lower == "subir a tela" -> scrollActiveWindow(forward = false)
            lower.startsWith("toque em ") || lower.startsWith("clicar em ") -> {
                val target = command.substringAfter(' ').substringAfter(' ').trim().trim('"', '\'')
                if (target.isBlank()) "Diga o texto exato do botão ou item que deseja tocar." else clickVisibleText(target)
            }
            else -> "Ainda não reconheço essa ação de controle. Posso voltar, ir à tela inicial, rolar a tela ou tocar em um texto visível."
        }
    }

    private fun scrollActiveWindow(forward: Boolean): String {
        val root = rootInActiveWindow ?: return "Não consegui acessar a tela ativa. Abra o aplicativo desejado e tente novamente."
        val scrollable = findScrollable(root)
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        val ok = scrollable?.performAction(action) == true
        root.recycle()
        return if (ok) "Ação confirmada: tela rolada ${if (forward) "para baixo" else "para cima"}." else "Não encontrei uma área rolável nesta tela."
    }

    private fun findScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return AccessibilityNodeInfo.obtain(node)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findScrollable(child)
            child.recycle()
            if (found != null) return found
        }
        return null
    }

    private fun clickVisibleText(target: String): String {
        val root = rootInActiveWindow ?: return "Não consegui acessar a tela ativa."
        val matches = root.findAccessibilityNodeInfosByText(target)
        var clicked = false
        for (node in matches) {
            var candidate: AccessibilityNodeInfo? = node
            while (candidate != null) {
                if (candidate.isClickable) {
                    clicked = candidate.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    break
                }
                val parent = candidate.parent
                if (candidate !== node) candidate.recycle()
                candidate = parent
            }
            if (clicked) break
        }
        matches.forEach { it.recycle() }
        root.recycle()
        return if (clicked) "Toque enviado ao item visível '$target'. Verifique o resultado na tela." else "Não encontrei um item clicável com o texto '$target'."
    }

    companion object {
        @Volatile private var activeService: GabiAccessibilityService? = null

        fun isEnabled(context: android.content.Context): Boolean {
            val expected = android.content.ComponentName(context, GabiAccessibilityService::class.java).flattenToString()
            val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
        }

        fun runApproved(command: String): String? = activeService?.executeApprovedCommand(command)
    }
}
