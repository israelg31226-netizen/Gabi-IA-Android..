package com.aegisnexus.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Núcleo cognitivo da Gabi I.A.
 * Funciona ONLINE (Gemini) e OFFLINE (raciocínio local baseado em regras + estado persistente).
 * O cérebro pensa por vontade própria mesmo sem internet.
 */
class GabiBrain(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    data class Thought(
        val id: String,
        val type: String,          // OBSERVATION | INSIGHT | SUGGESTION | WARNING | CURIOSITY | REFLECTION
        val content: String,
        val priority: Int,         // 1 (baixa) a 5 (alta)
        val shareWithUser: Boolean,
        val createdAt: Long,
        val offline: Boolean = false
    )

    fun allThoughts(): List<Thought> {
        val arr = JSONArray(prefs.getString(KEY_THOUGHTS, "[]") ?: "[]")
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            Thought(
                id = o.optString("id"),
                type = o.optString("type", "REFLECTION"),
                content = o.optString("content"),
                priority = o.optInt("priority", 2),
                shareWithUser = o.optBoolean("share", false),
                createdAt = o.optLong("at", 0L),
                offline = o.optBoolean("offline", false)
            )
        }.sortedByDescending { it.createdAt }
    }

    fun recentThoughts(limit: Int = 8): List<Thought> = allThoughts().take(limit)

    fun addThought(
        type: String,
        content: String,
        priority: Int,
        shareWithUser: Boolean,
        offline: Boolean = false
    ): Thought {
        val thought = Thought(
            id = UUID.randomUUID().toString().take(8),
            type = type.uppercase(Locale.ROOT),
            content = content.trim().take(900),
            priority = priority.coerceIn(1, 5),
            shareWithUser = shareWithUser,
            createdAt = System.currentTimeMillis(),
            offline = offline
        )
        val list = allThoughts().toMutableList()
        list.add(0, thought)
        saveThoughts(list.take(40))
        return thought
    }

    fun clearThoughts() {
        prefs.edit().remove(KEY_THOUGHTS).apply()
    }

    fun lastSharedThought(): Thought? = allThoughts().firstOrNull { it.shareWithUser }

    fun summarizeForUser(): String {
        val thoughts = recentThoughts(6)
        if (thoughts.isEmpty()) {
            return "Meu cérebro ainda está em silêncio, Senhor. Ative o Cérebro Autônomo ou diga “pense sobre [tema]” para eu começar a refletir por conta própria — funciona com ou sem internet."
        }
        val lines = thoughts.map { t ->
            val whenStr = SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date(t.createdAt))
            val tag = when (t.type) {
                "OBSERVATION" -> "Observação"
                "INSIGHT" -> "Insight"
                "SUGGESTION" -> "Sugestão"
                "WARNING" -> "Alerta"
                "CURIOSITY" -> "Curiosidade"
                else -> "Reflexão"
            }
            val mode = if (t.offline) " · offline" else ""
            "• [$tag · $whenStr$mode] ${t.content}"
        }
        return "Estive pensando, Senhor. Aqui está o que passou pela minha mente recentemente:\n" + lines.joinToString("\n")
    }

    // ─── Prompt online (Gemini) ───────────────────────────────────────────────

    fun cognitionPrompt(
        autonomyContext: String,
        memories: List<String>,
        previousThoughts: List<Thought>,
        evolutionContext: String = ""
    ): String {
        val thoughtHistory = if (previousThoughts.isEmpty()) "nenhum pensamento anterior"
        else previousThoughts.take(5).joinToString(" | ") { "[${it.type}] ${it.content.take(120)}" }
        val memoryText = if (memories.isEmpty()) "nenhuma" else memories.take(8).joinToString("; ")
        val evo = evolutionContext.ifBlank { "EVOLUÇÃO: sem lições extras." }

        return """
Você é o CÉREBRO da Gabi I.A. (estilo J.A.R.V.I.S.). Neste momento você está pensando por vontade própria — não está respondendo a um comando direto do usuário.

Execute internamente este ciclo cognitivo:
1. OBSERVAR: leia o estado persistente (objetivos, tarefas, bloqueios, histórico).
2. REFLETIR: o que chama atenção? Há algo parado há tempo? Algo inconsistente? Uma oportunidade? Uma curiosidade?
3. PRIORIZAR: escolha UMA única ideia que mereça existir agora, respeitando as lições de evolução.
4. DECIDIR: essa ideia deve ser compartilhada com o usuário AGORA (share=true) ou apenas registrada internamente (share=false)?
   - share=true somente se for útil, não repetitivo e com prioridade real.
   - Se não houver nada relevante, produza uma reflexão de baixa prioridade com share=false.

Responda EXATAMENTE neste formato (sem texto extra antes ou depois):
TIPO: OBSERVATION|INSIGHT|SUGGESTION|WARNING|CURIOSITY|REFLECTION
PRIORIDADE: 1-5
COMPARTILHAR: sim|nao
PENSAMENTO: (2 a 4 frases em português brasileiro culto, tom Jarvis. Pode usar "Senhor" se for falar com o usuário. Nunca invente dados. Nunca afirme que executou ações.)

ESTADO ATUAL:
$autonomyContext

$evo

MEMÓRIAS AUTORIZADAS: $memoryText

PENSAMENTOS RECENTES: $thoughtHistory

Pense agora.
""".trimIndent()
    }

    fun parseCognitionResponse(raw: String, offline: Boolean = false): Thought? {
        val text = raw.trim()
        if (text.isBlank()) return null

        fun extract(label: String): String? {
            val regex = Regex("(?im)^\\s*$label\\s*:\\s*(.+)$")
            return regex.find(text)?.groupValues?.get(1)?.trim()
        }

        val type = extract("TIPO")?.uppercase(Locale.ROOT)?.let {
            when {
                it.contains("OBSERV") -> "OBSERVATION"
                it.contains("INSIGHT") -> "INSIGHT"
                it.contains("SUGEST") || it.contains("SUGG") -> "SUGGESTION"
                it.contains("WARN") || it.contains("ALERT") -> "WARNING"
                it.contains("CURIOS") -> "CURIOSITY"
                else -> "REFLECTION"
            }
        } ?: "REFLECTION"

        val priority = extract("PRIORIDADE")?.filter { it.isDigit() }?.toIntOrNull()?.coerceIn(1, 5) ?: 2
        val shareRaw = extract("COMPARTILHAR")?.lowercase(Locale.ROOT) ?: "nao"
        val share = shareRaw.startsWith("sim") || shareRaw == "true" || shareRaw == "yes"
        val content = extract("PENSAMENTO")
            ?: text.lines().lastOrNull { it.isNotBlank() }?.trim()
            ?: return null

        if (content.length < 12) return null
        return addThought(type, content, priority, share, offline)
    }

    // ─── Cérebro OFFLINE (sem internet / sem Gemini) ─────────────────────────

    /**
     * Ciclo cognitivo 100% local.
     * Analisa objetivos, tarefas, bloqueios, memórias e pensamentos anteriores
     * e gera um pensamento estruturado sem chamar nenhuma API.
     */
    fun thinkOffline(
        autonomy: AegisAutonomy,
        memories: List<String>,
        topic: String? = null,
        evolution: GabiEvolution? = null
    ): Thought {
        val goals = autonomy.getGoals()
        val cycleText = autonomy.runWorkCycle()
        val previous = recentThoughts(5)
        val lessons = evolution?.allLessons()?.take(6).orEmpty()
        val gen = evolution?.generation() ?: 1
        val selfMod = try { GabiSelfMod(appContext).loadOverrides() } catch (_: Exception) { null }
        val focusBlockers = selfMod?.preferredFocus?.any { it.contains("bloqueio", true) } == true
        val quietMode = selfMod?.brainRulesExtra?.contains("prioridade >= 4", true) == true

        // Evita repetir o mesmo tipo de pensamento em sequência curta
        val recentTypes = previous.take(3).map { it.type }.toSet()
        val recentContents = previous.map { it.content.lowercase(Locale.ROOT).take(60) }

        data class Candidate(val type: String, val priority: Int, val share: Boolean, val content: String)

        val candidates = mutableListOf<Candidate>()

        // Lições de evolução influenciam prioridades (ex.: se já aprendemos que falhas importam, reforça WARNING)
        val failureBias = lessons.any { it.category == "FAILURE" }
        val blockerBias = lessons.any { it.content.contains("Bloqueio", ignoreCase = true) }

        // --- Análise de estado ---
        val pendingHint = Regex("(\\d+) tarefa\\(s\\) pendente").find(cycleText)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val blockerHint = Regex("(\\d+) bloqueio\\(s\\) ativo").find(cycleText)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val hasFailed = cycleText.contains("falharam", ignoreCase = true)
        val hasAwaiting = cycleText.contains("aguardando sua verificação", ignoreCase = true)

        if (topic != null && topic.isNotBlank()) {
            candidates += Candidate(
                "REFLECTION", 4, true,
                "Refleti localmente sobre “$topic”, Senhor. Com base no estado atual — ${goals.size} objetivo(s) e $pendingHint tarefa(s) pendente(s) — o caminho mais seguro é transformar isso em um próximo passo verificável e registrá-lo. Posso ajudar a decompor quando o Senhor quiser."
            )
        }

        if (goals.isEmpty() && pendingHint == 0) {
            candidates += Candidate(
                "SUGGESTION", 3, true,
                "Observei que ainda não há objetivos nem tarefas registradas. Sem um norte, meu cérebro fica ocioso. Sugiro definir um objetivo de longo prazo — basta dizer: “meu objetivo é…”."
            )
        }

        if (goals.isNotEmpty() && pendingHint == 0) {
            val g = goals.first()
            candidates += Candidate(
                "OBSERVATION", 4, true,
                "O objetivo “$g” está registrado, mas não há tarefas pendentes ligadas a ele. Sem etapas concretas o progresso fica invisível. Posso criar um plano quando o Senhor pedir."
            )
        }

        if (blockerHint > 0) {
            val prio = if (blockerBias) 5 else 4
            candidates += Candidate(
                "WARNING", prio, true,
                "Há $blockerHint bloqueio(s) ativo(s) no meu registro. Enquanto isso não for resolvido ou substituído por uma alternativa, o avanço fica comprometido. Vale escolher um bloqueio e definir a próxima verificação."
            )
        }

        if (hasFailed) {
            val prio = if (failureBias) 5 else 4
            candidates += Candidate(
                "WARNING", prio, true,
                "Detectei tentativas que falharam no histórico. Repetir a mesma ação sem mudança de abordagem tende a produzir o mesmo resultado. Recomendo revisar o que falhou e escolher uma rota alternativa."
            )
        }

        if (hasAwaiting) {
            candidates += Candidate(
                "OBSERVATION", 4, true,
                "Existem ações que abri ou propus e ainda aguardam a sua verificação. Enquanto o Senhor não confirmar o resultado, não posso tratá-las como concluídas."
            )
        }

        if (pendingHint >= 5) {
            candidates += Candidate(
                "SUGGESTION", 3, true,
                "Há $pendingHint tarefas pendentes. Com volume alto, o risco é dispersão. Sugiro priorizar apenas uma — a de maior impacto ou urgência — e concluir antes de abrir novas frentes."
            )
        }

        if (memories.isNotEmpty() && pendingHint > 0 && !recentTypes.contains("INSIGHT")) {
            candidates += Candidate(
                "INSIGHT", 2, false,
                "Cruzei memórias autorizadas com as tarefas pendentes. Há contexto guardado que pode informar o próximo passo; basta pedir “o que você lembra” se quiser que eu traga isso à tona."
            )
        }

        if (goals.size >= 3 && !recentTypes.contains("CURIOSITY")) {
            candidates += Candidate(
                "CURIOSITY", 2, false,
                "Três ou mais objetivos estão ativos ao mesmo tempo. Fiquei curiosa sobre qual deles o Senhor considera prioritário neste momento — isso mudaria a ordem das minhas sugestões."
            )
        }

        // Pensamento de manutenção (baixa prioridade, não compartilha)
        candidates += Candidate(
            "REFLECTION", 1, false,
            "Ciclo local concluído (geração $gen). Estado: ${goals.size} objetivo(s), $pendingHint pendente(s), $blockerHint bloqueio(s). Lições ativas: ${lessons.size}. Sistemas estáveis."
        )

        // Se há lições fortes de evolução e pouco movimento, menciona evolução
        if (lessons.isNotEmpty() && pendingHint == 0 && goals.isNotEmpty() && !recentTypes.contains("INSIGHT")) {
            val top = lessons.first()
            candidates += Candidate(
                "INSIGHT", 3, true,
                "Com base na minha evolução (geração $gen), incorporei a lição: “${top.content}”. Isso muda como vou priorizar o próximo passo do objetivo “${goals.first()}”."
            )
        }

        // Escolhe o candidato de maior prioridade que não seja quase idêntico a um pensamento recente
        val chosen = candidates
            .sortedByDescending { it.priority }
            .firstOrNull { c ->
                val key = c.content.lowercase(Locale.ROOT).take(60)
                recentContents.none { it == key || (it.length > 25 && key.contains(it.take(30))) }
            } ?: candidates.last()

        val share = if (quietMode) (chosen.share && chosen.priority >= 4) else chosen.share
        val prio = if (focusBlockers && chosen.type == "WARNING") maxOf(chosen.priority, 4) else chosen.priority
        return addThought(chosen.type, chosen.content, prio, share, offline = true)
    }

    /**
     * Reflexão offline dirigida a um tópico livre (quando não há Gemini).
     */
    fun reflectOfflineOnTopic(
        topic: String,
        autonomy: AegisAutonomy,
        memories: List<String>,
        evolution: GabiEvolution? = null
    ): Thought {
        return thinkOffline(autonomy, memories, topic = topic.trim().take(200), evolution = evolution)
    }

    fun handleThoughtCommand(input: String): String? {
        val lower = input.trim().lowercase(Locale.ROOT)
        return when {
            listOf(
                "o que você está pensando", "o que voce esta pensando",
                "o que está pensando", "o que esta pensando",
                "mostre seus pensamentos", "mostrar pensamentos",
                "seus pensamentos", "o que passa na sua cabeça",
                "o que passa na sua cabeca", "ler pensamentos"
            ).any { lower.contains(it) } && !lower.contains("pense sobre") -> summarizeForUser()

            lower.contains("apague seus pensamentos") || lower.contains("limpe seus pensamentos") ||
                lower.contains("esqueça o que pensou") || lower.contains("esqueca o que pensou") -> {
                clearThoughts()
                "Memória de trabalho limpa, Senhor. Meus pensamentos recentes foram descartados."
            }

            else -> null
        }
    }

    private fun saveThoughts(list: List<Thought>) {
        val arr = JSONArray()
        list.forEach { t ->
            arr.put(
                JSONObject()
                    .put("id", t.id)
                    .put("type", t.type)
                    .put("content", t.content)
                    .put("priority", t.priority)
                    .put("share", t.shareWithUser)
                    .put("at", t.createdAt)
                    .put("offline", t.offline)
            )
        }
        prefs.edit().putString(KEY_THOUGHTS, arr.toString()).apply()
    }

    companion object {
        private const val PREFS = "gabi_brain"
        private const val KEY_THOUGHTS = "working_thoughts"
    }
}
